﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormAddCity : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        public FormAddCity(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
        }

        private void FormAddCity_Load(object sender, EventArgs e)
        {
            this.tblCitiesTableAdapter.Fill(this.dataSetCities.tblCities);
            dataGridView1.AllowUserToAddRows = false;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Validations.ValidName(cityName.Text))
                {
                    MessageBox.Show("השם שנבחר לא חוקי", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (Validations.Exist(dataConnection,"tblCities","cityName",cityName.Text)) { 
                    MessageBox.Show("שם העיר קיים כבר במסד הנתונים","שם עיר קיים כבר",
                        MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return; 
                }                               
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = string.Format(
                    "INSERT INTO tblCities " +
                    "(cityName) " +
                    "VALUES (\"{0}\")",
                    cityName.Text);
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblCities ended successfully", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblCities failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM tblCities ";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddCity_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
