﻿namespace Submarines
{
    partial class FormUpdateOrganization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormUpdateOrganization));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOpenSite = new System.Windows.Forms.Button();
            this.siteAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.wmp = new AxWMPLib.AxWindowsMediaPlayer();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnShowVid = new System.Windows.Forms.Button();
            this.btnShowDir = new System.Windows.Forms.Button();
            this.btnShowPic = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.directorId = new System.Windows.Forms.ComboBox();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.vidButton = new System.Windows.Forms.Button();
            this.folderButton = new System.Windows.Forms.Button();
            this.vidLocation = new System.Windows.Forms.TextBox();
            this.folderLocation = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.orgNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgCityIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgDirectorIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPictureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPicturesFolderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgClipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblOrganizationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetOrganization = new Submarines.DataSetOrganization();
            this.picButton = new System.Windows.Forms.Button();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.pictureLocation = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.orgName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboCity = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.addressBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tblOrganizationTableAdapter = new Submarines.DataSetOrganizationTableAdapters.tblOrganizationTableAdapter();
            this.picFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.folderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.vidFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnOpenSite);
            this.panel1.Controls.Add(this.siteAddress);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.wmp);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnShowVid);
            this.panel1.Controls.Add(this.btnShowDir);
            this.panel1.Controls.Add(this.btnShowPic);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.directorId);
            this.panel1.Controls.Add(this.buttonPrev);
            this.panel1.Controls.Add(this.buttonLast);
            this.panel1.Controls.Add(this.buttonNext);
            this.panel1.Controls.Add(this.buttonFirst);
            this.panel1.Controls.Add(this.vidButton);
            this.panel1.Controls.Add(this.folderButton);
            this.panel1.Controls.Add(this.vidLocation);
            this.panel1.Controls.Add(this.folderLocation);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.picButton);
            this.panel1.Controls.Add(this.buttonUpdate);
            this.panel1.Controls.Add(this.pictureLocation);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.orgName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.comboCity);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.addressBox);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(25, 33);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 931);
            this.panel1.TabIndex = 32;
            // 
            // btnOpenSite
            // 
            this.btnOpenSite.Location = new System.Drawing.Point(348, 440);
            this.btnOpenSite.Name = "btnOpenSite";
            this.btnOpenSite.Size = new System.Drawing.Size(84, 29);
            this.btnOpenSite.TabIndex = 65;
            this.btnOpenSite.Text = "פתח";
            this.btnOpenSite.UseVisualStyleBackColor = true;
            this.btnOpenSite.Click += new System.EventHandler(this.btnOpenSite_Click);
            // 
            // siteAddress
            // 
            this.siteAddress.Location = new System.Drawing.Point(450, 441);
            this.siteAddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.siteAddress.Name = "siteAddress";
            this.siteAddress.Size = new System.Drawing.Size(346, 26);
            this.siteAddress.TabIndex = 64;
            this.siteAddress.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(830, 444);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 20);
            this.label8.TabIndex = 63;
            this.label8.Text = "אתר ארגון";
            // 
            // wmp
            // 
            this.wmp.Enabled = true;
            this.wmp.Location = new System.Drawing.Point(896, 83);
            this.wmp.Name = "wmp";
            this.wmp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wmp.OcxState")));
            this.wmp.Size = new System.Drawing.Size(266, 266);
            this.wmp.TabIndex = 62;
            this.wmp.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(1344, 125);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 400);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 61;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // btnShowVid
            // 
            this.btnShowVid.Location = new System.Drawing.Point(258, 395);
            this.btnShowVid.Name = "btnShowVid";
            this.btnShowVid.Size = new System.Drawing.Size(84, 29);
            this.btnShowVid.TabIndex = 9;
            this.btnShowVid.Text = "הצג";
            this.btnShowVid.UseVisualStyleBackColor = true;
            this.btnShowVid.Click += new System.EventHandler(this.btnShowVid_Click);
            // 
            // btnShowDir
            // 
            this.btnShowDir.Location = new System.Drawing.Point(258, 349);
            this.btnShowDir.Name = "btnShowDir";
            this.btnShowDir.Size = new System.Drawing.Size(84, 29);
            this.btnShowDir.TabIndex = 7;
            this.btnShowDir.Text = "הצג";
            this.btnShowDir.UseVisualStyleBackColor = true;
            this.btnShowDir.Click += new System.EventHandler(this.btnShowDir_Click);
            // 
            // btnShowPic
            // 
            this.btnShowPic.Location = new System.Drawing.Point(258, 299);
            this.btnShowPic.Name = "btnShowPic";
            this.btnShowPic.Size = new System.Drawing.Size(84, 29);
            this.btnShowPic.TabIndex = 5;
            this.btnShowPic.Text = "הצג";
            this.btnShowPic.UseVisualStyleBackColor = true;
            this.btnShowPic.Click += new System.EventHandler(this.btnShowPic_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label16.Location = new System.Drawing.Point(1655, 563);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 25);
            this.label16.TabIndex = 57;
            this.label16.Text = "טבלת ארגון";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(894, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(160, 37);
            this.label11.TabIndex = 33;
            this.label11.Text = "עדכון ארגון";
            // 
            // directorId
            // 
            this.directorId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.directorId.FormattingEnabled = true;
            this.directorId.Location = new System.Drawing.Point(945, 397);
            this.directorId.Name = "directorId";
            this.directorId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.directorId.Size = new System.Drawing.Size(229, 28);
            this.directorId.TabIndex = 2;
            // 
            // buttonPrev
            // 
            this.buttonPrev.Enabled = false;
            this.buttonPrev.Location = new System.Drawing.Point(733, 498);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(93, 51);
            this.buttonPrev.TabIndex = 13;
            this.buttonPrev.Text = "הקודם";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(602, 498);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(92, 51);
            this.buttonLast.TabIndex = 14;
            this.buttonLast.Text = "אחרון";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Enabled = false;
            this.buttonNext.Location = new System.Drawing.Point(867, 498);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(93, 51);
            this.buttonNext.TabIndex = 12;
            this.buttonNext.Text = "הבא";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(1005, 498);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(90, 51);
            this.buttonFirst.TabIndex = 11;
            this.buttonFirst.Text = "ראשון";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // vidButton
            // 
            this.vidButton.Location = new System.Drawing.Point(348, 395);
            this.vidButton.Name = "vidButton";
            this.vidButton.Size = new System.Drawing.Size(84, 29);
            this.vidButton.TabIndex = 8;
            this.vidButton.Text = ". . .עיון";
            this.vidButton.UseVisualStyleBackColor = true;
            this.vidButton.Click += new System.EventHandler(this.vidButton_Click);
            // 
            // folderButton
            // 
            this.folderButton.Location = new System.Drawing.Point(348, 349);
            this.folderButton.Name = "folderButton";
            this.folderButton.Size = new System.Drawing.Size(84, 29);
            this.folderButton.TabIndex = 6;
            this.folderButton.Text = ". . .עיון";
            this.folderButton.UseVisualStyleBackColor = true;
            this.folderButton.Click += new System.EventHandler(this.folderButton_Click);
            // 
            // vidLocation
            // 
            this.vidLocation.Enabled = false;
            this.vidLocation.Location = new System.Drawing.Point(450, 397);
            this.vidLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.vidLocation.Name = "vidLocation";
            this.vidLocation.Size = new System.Drawing.Size(346, 26);
            this.vidLocation.TabIndex = 29;
            this.vidLocation.TabStop = false;
            // 
            // folderLocation
            // 
            this.folderLocation.Enabled = false;
            this.folderLocation.Location = new System.Drawing.Point(450, 350);
            this.folderLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.folderLocation.Name = "folderLocation";
            this.folderLocation.Size = new System.Drawing.Size(346, 26);
            this.folderLocation.TabIndex = 28;
            this.folderLocation.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(819, 400);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 27;
            this.label5.Text = "סרטון ארגון";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(807, 353);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 20);
            this.label4.TabIndex = 26;
            this.label4.Text = "תיקיית תמונות";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orgNameDataGridViewTextBoxColumn,
            this.orgAddressDataGridViewTextBoxColumn,
            this.orgCityIDDataGridViewTextBoxColumn,
            this.orgDirectorIDDataGridViewTextBoxColumn,
            this.orgPictureDataGridViewTextBoxColumn,
            this.orgPicturesFolderDataGridViewTextBoxColumn,
            this.orgClipDataGridViewTextBoxColumn,
            this.orgSite});
            this.dataGridView1.DataSource = this.tblOrganizationBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(29, 591);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1726, 312);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // orgNameDataGridViewTextBoxColumn
            // 
            this.orgNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgNameDataGridViewTextBoxColumn.DataPropertyName = "orgName";
            this.orgNameDataGridViewTextBoxColumn.HeaderText = "שם ארגון";
            this.orgNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgNameDataGridViewTextBoxColumn.Name = "orgNameDataGridViewTextBoxColumn";
            this.orgNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgNameDataGridViewTextBoxColumn.Width = 170;
            // 
            // orgAddressDataGridViewTextBoxColumn
            // 
            this.orgAddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgAddressDataGridViewTextBoxColumn.DataPropertyName = "orgAddress";
            this.orgAddressDataGridViewTextBoxColumn.HeaderText = "כתובת";
            this.orgAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgAddressDataGridViewTextBoxColumn.Name = "orgAddressDataGridViewTextBoxColumn";
            this.orgAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgAddressDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgCityIDDataGridViewTextBoxColumn
            // 
            this.orgCityIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgCityIDDataGridViewTextBoxColumn.DataPropertyName = "orgCityID";
            this.orgCityIDDataGridViewTextBoxColumn.HeaderText = "קוד עיר";
            this.orgCityIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgCityIDDataGridViewTextBoxColumn.Name = "orgCityIDDataGridViewTextBoxColumn";
            this.orgCityIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgCityIDDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgDirectorIDDataGridViewTextBoxColumn
            // 
            this.orgDirectorIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgDirectorIDDataGridViewTextBoxColumn.DataPropertyName = "orgDirectorID";
            this.orgDirectorIDDataGridViewTextBoxColumn.HeaderText = "תז מנהל";
            this.orgDirectorIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgDirectorIDDataGridViewTextBoxColumn.Name = "orgDirectorIDDataGridViewTextBoxColumn";
            this.orgDirectorIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgDirectorIDDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgPictureDataGridViewTextBoxColumn
            // 
            this.orgPictureDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPictureDataGridViewTextBoxColumn.DataPropertyName = "orgPicture";
            this.orgPictureDataGridViewTextBoxColumn.HeaderText = "מיקום תמונה";
            this.orgPictureDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPictureDataGridViewTextBoxColumn.Name = "orgPictureDataGridViewTextBoxColumn";
            this.orgPictureDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgPictureDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgPicturesFolderDataGridViewTextBoxColumn
            // 
            this.orgPicturesFolderDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPicturesFolderDataGridViewTextBoxColumn.DataPropertyName = "orgPicturesFolder";
            this.orgPicturesFolderDataGridViewTextBoxColumn.HeaderText = "מיקום תיקיית תמונות";
            this.orgPicturesFolderDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Name = "orgPicturesFolderDataGridViewTextBoxColumn";
            this.orgPicturesFolderDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgClipDataGridViewTextBoxColumn
            // 
            this.orgClipDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgClipDataGridViewTextBoxColumn.DataPropertyName = "orgClip";
            this.orgClipDataGridViewTextBoxColumn.HeaderText = "מיקום סרטון";
            this.orgClipDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgClipDataGridViewTextBoxColumn.Name = "orgClipDataGridViewTextBoxColumn";
            this.orgClipDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgClipDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgSite
            // 
            this.orgSite.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.orgSite.DataPropertyName = "orgSite";
            this.orgSite.HeaderText = "כתובת אתר";
            this.orgSite.MinimumWidth = 8;
            this.orgSite.Name = "orgSite";
            this.orgSite.ReadOnly = true;
            // 
            // tblOrganizationBindingSource
            // 
            this.tblOrganizationBindingSource.DataMember = "tblOrganization";
            this.tblOrganizationBindingSource.DataSource = this.dataSetOrganization;
            // 
            // dataSetOrganization
            // 
            this.dataSetOrganization.DataSetName = "DataSetOrganization";
            this.dataSetOrganization.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // picButton
            // 
            this.picButton.Location = new System.Drawing.Point(348, 299);
            this.picButton.Name = "picButton";
            this.picButton.Size = new System.Drawing.Size(84, 29);
            this.picButton.TabIndex = 4;
            this.picButton.Text = ". . .עיון";
            this.picButton.UseVisualStyleBackColor = true;
            this.picButton.Click += new System.EventHandler(this.picButton_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonUpdate.Location = new System.Drawing.Point(71, 356);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(120, 52);
            this.buttonUpdate.TabIndex = 15;
            this.buttonUpdate.Text = "עדכן";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // pictureLocation
            // 
            this.pictureLocation.Enabled = false;
            this.pictureLocation.Location = new System.Drawing.Point(450, 300);
            this.pictureLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureLocation.Name = "pictureLocation";
            this.pictureLocation.Size = new System.Drawing.Size(346, 26);
            this.pictureLocation.TabIndex = 1;
            this.pictureLocation.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1203, 303);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "שם ארגון";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(818, 303);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 20);
            this.label10.TabIndex = 23;
            this.label10.Text = "תמונת ארגון";
            // 
            // orgName
            // 
            this.orgName.Location = new System.Drawing.Point(945, 297);
            this.orgName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.orgName.Name = "orgName";
            this.orgName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.orgName.Size = new System.Drawing.Size(229, 26);
            this.orgName.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1211, 400);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "תז מנהל";
            // 
            // comboCity
            // 
            this.comboCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCity.FormattingEnabled = true;
            this.comboCity.Location = new System.Drawing.Point(945, 441);
            this.comboCity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboCity.Name = "comboCity";
            this.comboCity.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboCity.Size = new System.Drawing.Size(229, 28);
            this.comboCity.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1223, 353);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "כתובת";
            // 
            // addressBox
            // 
            this.addressBox.Location = new System.Drawing.Point(945, 350);
            this.addressBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addressBox.Name = "addressBox";
            this.addressBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addressBox.Size = new System.Drawing.Size(229, 26);
            this.addressBox.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1241, 444);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "עיר";
            // 
            // tblOrganizationTableAdapter
            // 
            this.tblOrganizationTableAdapter.ClearBeforeFill = true;
            // 
            // FormUpdateOrganization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormUpdateOrganization";
            this.Text = "FormUpdateOrganization";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormUpdateOrganization_FormClosed);
            this.Load += new System.EventHandler(this.FormUpdateOrganization_Load);
            this.SizeChanged += new System.EventHandler(this.FormUpdateOrganization_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button vidButton;
        private System.Windows.Forms.Button folderButton;
        private System.Windows.Forms.TextBox vidLocation;
        private System.Windows.Forms.TextBox folderLocation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button picButton;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.TextBox pictureLocation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox orgName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboCity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox addressBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private DataSetOrganization dataSetOrganization;
        private System.Windows.Forms.BindingSource tblOrganizationBindingSource;
        private DataSetOrganizationTableAdapters.tblOrganizationTableAdapter tblOrganizationTableAdapter;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.OpenFileDialog picFileDialog;
        private System.Windows.Forms.FolderBrowserDialog folderDialog;
        private System.Windows.Forms.OpenFileDialog vidFileDialog;
        private System.Windows.Forms.ComboBox directorId;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnShowVid;
        private System.Windows.Forms.Button btnShowDir;
        private System.Windows.Forms.Button btnShowPic;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AxWMPLib.AxWindowsMediaPlayer wmp;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgCityIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgDirectorIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPictureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPicturesFolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgClipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgSite;
        private System.Windows.Forms.Button btnOpenSite;
        private System.Windows.Forms.TextBox siteAddress;
        private System.Windows.Forms.Label label8;
    }
}
