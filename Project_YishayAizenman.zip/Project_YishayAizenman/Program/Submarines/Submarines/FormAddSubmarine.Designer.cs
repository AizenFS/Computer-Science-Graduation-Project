﻿namespace Submarines
{
    partial class FormAddSubmarine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.title = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.sinkPercent = new System.Windows.Forms.TextBox();
            this.subName = new System.Windows.Forms.TextBox();
            this.cols = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.subIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subRowsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subColsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subSinkPercentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblSubmarinesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetSubmarines = new Submarines.DataSetSubmarines();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.rows = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tblSubmarinesTableAdapter = new Submarines.DataSetSubmarinesTableAdapters.tblSubmarinesTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSubmarinesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSubmarines)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(899, 21);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(183, 37);
            this.title.TabIndex = 32;
            this.title.Text = "הוספת צוללת";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.title);
            this.panel1.Controls.Add(this.sinkPercent);
            this.panel1.Controls.Add(this.subName);
            this.panel1.Controls.Add(this.cols);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonAdd);
            this.panel1.Controls.Add(this.rows);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(36, 95);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 861);
            this.panel1.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(817, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "מספר שורות";
            // 
            // sinkPercent
            // 
            this.sinkPercent.Location = new System.Drawing.Point(1071, 297);
            this.sinkPercent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sinkPercent.Name = "sinkPercent";
            this.sinkPercent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sinkPercent.Size = new System.Drawing.Size(110, 26);
            this.sinkPercent.TabIndex = 2;
            // 
            // subName
            // 
            this.subName.Location = new System.Drawing.Point(1071, 230);
            this.subName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.subName.Name = "subName";
            this.subName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.subName.Size = new System.Drawing.Size(110, 26);
            this.subName.TabIndex = 1;
            // 
            // cols
            // 
            this.cols.Location = new System.Drawing.Point(665, 297);
            this.cols.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cols.Name = "cols";
            this.cols.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cols.Size = new System.Drawing.Size(110, 26);
            this.cols.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(808, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "מספר עמודות";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.subIDDataGridViewTextBoxColumn,
            this.subRowsDataGridViewTextBoxColumn,
            this.subColsDataGridViewTextBoxColumn,
            this.subNameDataGridViewTextBoxColumn,
            this.subSinkPercentDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblSubmarinesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(599, 450);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(809, 312);
            this.dataGridView1.TabIndex = 16;
            // 
            // subIDDataGridViewTextBoxColumn
            // 
            this.subIDDataGridViewTextBoxColumn.DataPropertyName = "subID";
            this.subIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.subIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subIDDataGridViewTextBoxColumn.Name = "subIDDataGridViewTextBoxColumn";
            this.subIDDataGridViewTextBoxColumn.Width = 106;
            // 
            // subRowsDataGridViewTextBoxColumn
            // 
            this.subRowsDataGridViewTextBoxColumn.DataPropertyName = "subRows";
            this.subRowsDataGridViewTextBoxColumn.HeaderText = "מספר שורות צוללת";
            this.subRowsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subRowsDataGridViewTextBoxColumn.Name = "subRowsDataGridViewTextBoxColumn";
            this.subRowsDataGridViewTextBoxColumn.Width = 157;
            // 
            // subColsDataGridViewTextBoxColumn
            // 
            this.subColsDataGridViewTextBoxColumn.DataPropertyName = "subCols";
            this.subColsDataGridViewTextBoxColumn.HeaderText = "מספר עמודות צוללת";
            this.subColsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subColsDataGridViewTextBoxColumn.Name = "subColsDataGridViewTextBoxColumn";
            this.subColsDataGridViewTextBoxColumn.Width = 165;
            // 
            // subNameDataGridViewTextBoxColumn
            // 
            this.subNameDataGridViewTextBoxColumn.DataPropertyName = "subName";
            this.subNameDataGridViewTextBoxColumn.HeaderText = "שם צוללת";
            this.subNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subNameDataGridViewTextBoxColumn.Name = "subNameDataGridViewTextBoxColumn";
            this.subNameDataGridViewTextBoxColumn.Width = 103;
            // 
            // subSinkPercentDataGridViewTextBoxColumn
            // 
            this.subSinkPercentDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.subSinkPercentDataGridViewTextBoxColumn.DataPropertyName = "subSinkPercent";
            this.subSinkPercentDataGridViewTextBoxColumn.HeaderText = "אחוז משבצות להטבעה";
            this.subSinkPercentDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subSinkPercentDataGridViewTextBoxColumn.Name = "subSinkPercentDataGridViewTextBoxColumn";
            // 
            // tblSubmarinesBindingSource
            // 
            this.tblSubmarinesBindingSource.DataMember = "tblSubmarines";
            this.tblSubmarinesBindingSource.DataSource = this.dataSetSubmarines;
            // 
            // dataSetSubmarines
            // 
            this.dataSetSubmarines.DataSetName = "DataSetSubmarines";
            this.dataSetSubmarines.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonAdd.Location = new System.Drawing.Point(906, 358);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(188, 52);
            this.buttonAdd.TabIndex = 5;
            this.buttonAdd.Text = "הוסף";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // rows
            // 
            this.rows.Location = new System.Drawing.Point(665, 230);
            this.rows.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rows.Name = "rows";
            this.rows.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rows.Size = new System.Drawing.Size(110, 26);
            this.rows.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1303, 236);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "שם צוללת";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1220, 300);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "אחוז משבצות להטבעה";
            // 
            // tblSubmarinesTableAdapter
            // 
            this.tblSubmarinesTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(1297, 422);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 25);
            this.label3.TabIndex = 35;
            this.label3.Text = "טבלת צוללות";
            // 
            // FormAddSubmarine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormAddSubmarine";
            this.Text = "FormAddSubmarine";
            this.Load += new System.EventHandler(this.FormAddSubmarine_Load);
            this.SizeChanged += new System.EventHandler(this.FormAddSubmarine_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSubmarinesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSubmarines)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox cols;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.TextBox rows;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private DataSetSubmarines dataSetSubmarines;
        private System.Windows.Forms.BindingSource tblSubmarinesBindingSource;
        private DataSetSubmarinesTableAdapters.tblSubmarinesTableAdapter tblSubmarinesTableAdapter;
        private System.Windows.Forms.TextBox subName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sinkPercent;
        private System.Windows.Forms.DataGridViewTextBoxColumn subIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subRowsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subColsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subSinkPercentDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
    }
}
