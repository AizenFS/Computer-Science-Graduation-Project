﻿namespace Submarines
{
    partial class FormSearchOrganizations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tblOrganizationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetOrganization = new Submarines.DataSetOrganization();
            this.refreshButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.searchStr = new System.Windows.Forms.TextBox();
            this.tblOrganizationTableAdapter = new Submarines.DataSetOrganizationTableAdapters.tblOrganizationTableAdapter();
            this.orgNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgCityIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgDirectorIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPictureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPicturesFolderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgClipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.refreshButton);
            this.panel1.Controls.Add(this.searchButton);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.searchStr);
            this.panel1.Location = new System.Drawing.Point(97, 66);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1778, 900);
            this.panel1.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(1629, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 36;
            this.label4.Text = "טבלת ארגון";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(712, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(303, 38);
            this.label2.TabIndex = 18;
            this.label2.Text = "חיפוש בטבלת ארגון";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orgNameDataGridViewTextBoxColumn,
            this.orgAddressDataGridViewTextBoxColumn,
            this.orgCityIDDataGridViewTextBoxColumn,
            this.orgDirectorIDDataGridViewTextBoxColumn,
            this.orgPictureDataGridViewTextBoxColumn,
            this.orgPicturesFolderDataGridViewTextBoxColumn,
            this.orgClipDataGridViewTextBoxColumn,
            this.orgSite});
            this.dataGridView1.DataSource = this.tblOrganizationBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(3, 340);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(1772, 520);
            this.dataGridView1.TabIndex = 15;
            // 
            // tblOrganizationBindingSource
            // 
            this.tblOrganizationBindingSource.DataMember = "tblOrganization";
            this.tblOrganizationBindingSource.DataSource = this.dataSetOrganization;
            // 
            // dataSetOrganization
            // 
            this.dataSetOrganization.DataSetName = "DataSetOrganization";
            this.dataSetOrganization.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // refreshButton
            // 
            this.refreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Location = new System.Drawing.Point(556, 254);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(133, 53);
            this.refreshButton.TabIndex = 3;
            this.refreshButton.Text = "רענן";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Location = new System.Drawing.Point(719, 254);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(133, 53);
            this.searchButton.TabIndex = 2;
            this.searchButton.Text = "חפש";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1075, 274);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "טקסט לחיפוש:";
            // 
            // searchStr
            // 
            this.searchStr.Location = new System.Drawing.Point(906, 271);
            this.searchStr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.searchStr.Name = "searchStr";
            this.searchStr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchStr.Size = new System.Drawing.Size(148, 26);
            this.searchStr.TabIndex = 1;
            // 
            // tblOrganizationTableAdapter
            // 
            this.tblOrganizationTableAdapter.ClearBeforeFill = true;
            // 
            // orgNameDataGridViewTextBoxColumn
            // 
            this.orgNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgNameDataGridViewTextBoxColumn.DataPropertyName = "orgName";
            this.orgNameDataGridViewTextBoxColumn.HeaderText = "שם ארגון";
            this.orgNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgNameDataGridViewTextBoxColumn.Name = "orgNameDataGridViewTextBoxColumn";
            this.orgNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgNameDataGridViewTextBoxColumn.Width = 170;
            // 
            // orgAddressDataGridViewTextBoxColumn
            // 
            this.orgAddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgAddressDataGridViewTextBoxColumn.DataPropertyName = "orgAddress";
            this.orgAddressDataGridViewTextBoxColumn.HeaderText = "כתובת";
            this.orgAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgAddressDataGridViewTextBoxColumn.Name = "orgAddressDataGridViewTextBoxColumn";
            this.orgAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgAddressDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgCityIDDataGridViewTextBoxColumn
            // 
            this.orgCityIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgCityIDDataGridViewTextBoxColumn.DataPropertyName = "orgCityID";
            this.orgCityIDDataGridViewTextBoxColumn.HeaderText = "קוד עיר";
            this.orgCityIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgCityIDDataGridViewTextBoxColumn.Name = "orgCityIDDataGridViewTextBoxColumn";
            this.orgCityIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgCityIDDataGridViewTextBoxColumn.Width = 60;
            // 
            // orgDirectorIDDataGridViewTextBoxColumn
            // 
            this.orgDirectorIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgDirectorIDDataGridViewTextBoxColumn.DataPropertyName = "orgDirectorID";
            this.orgDirectorIDDataGridViewTextBoxColumn.HeaderText = "תז מנהל";
            this.orgDirectorIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgDirectorIDDataGridViewTextBoxColumn.Name = "orgDirectorIDDataGridViewTextBoxColumn";
            this.orgDirectorIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgDirectorIDDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgPictureDataGridViewTextBoxColumn
            // 
            this.orgPictureDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPictureDataGridViewTextBoxColumn.DataPropertyName = "orgPicture";
            this.orgPictureDataGridViewTextBoxColumn.HeaderText = "מיקום תמונה";
            this.orgPictureDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPictureDataGridViewTextBoxColumn.Name = "orgPictureDataGridViewTextBoxColumn";
            this.orgPictureDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgPictureDataGridViewTextBoxColumn.Width = 180;
            // 
            // orgPicturesFolderDataGridViewTextBoxColumn
            // 
            this.orgPicturesFolderDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPicturesFolderDataGridViewTextBoxColumn.DataPropertyName = "orgPicturesFolder";
            this.orgPicturesFolderDataGridViewTextBoxColumn.HeaderText = "מיקום תיקיית תמונות";
            this.orgPicturesFolderDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Name = "orgPicturesFolderDataGridViewTextBoxColumn";
            this.orgPicturesFolderDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Width = 180;
            // 
            // orgClipDataGridViewTextBoxColumn
            // 
            this.orgClipDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgClipDataGridViewTextBoxColumn.DataPropertyName = "orgClip";
            this.orgClipDataGridViewTextBoxColumn.HeaderText = "מיקום סרטון";
            this.orgClipDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgClipDataGridViewTextBoxColumn.Name = "orgClipDataGridViewTextBoxColumn";
            this.orgClipDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgClipDataGridViewTextBoxColumn.Width = 180;
            // 
            // orgSite
            // 
            this.orgSite.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.orgSite.DataPropertyName = "orgSite";
            this.orgSite.HeaderText = "כתובת אתר";
            this.orgSite.MinimumWidth = 8;
            this.orgSite.Name = "orgSite";
            this.orgSite.ReadOnly = true;
            // 
            // FormSearchOrganizations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormSearchOrganizations";
            this.Text = "FormSearchOrganizations";
            this.Load += new System.EventHandler(this.FormSearchOrganizations_Load);
            this.SizeChanged += new System.EventHandler(this.FormSearchOrganizations_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox searchStr;
        private System.Windows.Forms.Label label2;
        private DataSetOrganization dataSetOrganization;
        private System.Windows.Forms.BindingSource tblOrganizationBindingSource;
        private DataSetOrganizationTableAdapters.tblOrganizationTableAdapter tblOrganizationTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgCityIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgDirectorIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPictureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPicturesFolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgClipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgSite;
    }
}
