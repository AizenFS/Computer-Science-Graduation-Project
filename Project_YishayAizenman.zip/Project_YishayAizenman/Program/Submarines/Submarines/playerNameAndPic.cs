﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Submarines
{
    public partial class playerNameAndPic : UserControl
    {
        public string id { get => idBox.Text; set => idBox.Text = value; }
        public string firstName { get => nameBox.Text; set => nameBox.Text = value; }
        public string lastName { get => surnameBox.Text; set => surnameBox.Text = value; }
        public string picLocation { get => pic.ImageLocation ?? ""; set => pic.ImageLocation = value; }

        public playerNameAndPic()
        {
            InitializeComponent();
        }

        public void UpdateProperties(string id, string firstName, string lastName, string picLocation)
        {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.picLocation = picLocation;
        }

        public void UpdateProperties(SubmarinesDataStructures.Player player, OleDbConnection dataConnection)
        {
            id = player.playerId.ToString();
            firstName = player.firstName.ToString();
            lastName = player.lastName.ToString();
            picLocation = player.GetPlayerPicLocation(dataConnection);
        }


    }
}
