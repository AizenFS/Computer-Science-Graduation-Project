﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormSearchSteps : Submarines.FormBaseSearch
    {
        private OleDbConnection dataConnection;
        public FormSearchSteps(OleDbConnection dataConnection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.dataConnection = dataConnection;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM  tblSteps WHERE " +
                                           "stepGameID    LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "stepOrderNum  LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "stepPlayer    LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "stepRow       LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "stepCol       LIKE \"%" + searchStr.Text + "%\"     " +
                                     "ORDER BY stepGameID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                if (tbl.Rows.Count == 0)
                {
                    MessageBox.Show("לא נמצאו התאמות", "לא נמצא",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    dataGridView1.DataSource = tbl;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Search tblSteps failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblSteps " +
                                     "ORDER BY stepGameID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh tblSteps table failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormSearchSteps_Load(object sender, EventArgs e)
        {
            this.tblStepsTableAdapter.Fill(this.dataSetSteps.tblSteps);

        }

        private void FormSearchSteps_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
