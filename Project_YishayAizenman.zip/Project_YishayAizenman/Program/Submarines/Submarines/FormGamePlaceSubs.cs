﻿using Submarines.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormGamePlaceSubs : Submarines.FormBaseGame
    {
        private enum ButtonChecks
        {
            isPreviewInsideBoard = 0, isInPreview = 1, IsSurroundingPreview = 2
        }

        private SubmarinesUtils.GameBoardCreator gameBoardCreator;

        private OleDbConnection dataConnection;
        private Game game;

        private bool IsPlacingSubmarines = false;
        private List<SubmarineLocation> subLocations;

        private int[,] boardLocations1, boardLocations2;

        private int computerPlayer;
        bool computerChoosing;
        private Random random;
        
        private Panel currentBoard;
        private ListBox currentSubsList;
        private Button curretResetBtn;

        public FormGamePlaceSubs(OleDbConnection dataConnection, Game game)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.dataConnection = dataConnection;
            this.game = game;

            gameBoardCreator = new SubmarinesUtils.GameBoardCreator(game, ButtonEventsAssigner, true, 0);

            subLocations = new List<SubmarineLocation>();
            boardLocations1 = new int[game.boardRows, game.boardCols];
            boardLocations2 = new int[game.boardRows, game.boardCols];

            computerPlayer = 0;
            computerChoosing = false;
            random = new Random();            
        }

        private int AssignControlVariables(int playerNum, Button fromButton = null)
        {
            if (fromButton != null)
            {
                playerNum = fromButton.Name.Split('_')[1].Last() == '1' ? 1 : 2;
            }
            currentBoard = playerNum == 1 ? board1 : board2;
            currentSubsList = playerNum == 1 ? listSubs1 : listSubs2;
            curretResetBtn = playerNum == 1 ? reset1 : reset2;
            return playerNum;
        }

        #region Initiallization

        private void FormGamePlaceSubs_Load(object sender, EventArgs e)
        {
            FillPlayerDetails();
            gameBoardCreator.CreateBoard(board1);
            gameBoardCreator.CreateBoard(board2);

            FillSubList(listSubs1);
            FillSubList(listSubs2);
        }

        private void FillPlayerDetails()
        {
            Player p1 = game.player1;
            Player p2 = game.player2;
            NP1.UpdateProperties(p1, dataConnection);
            NP2.UpdateProperties(p2, dataConnection);
            if (p1.isComputer) { computerPlayer = 1; }
            if (p2.isComputer) { computerPlayer = 2; }
        }

        private void FillSubList(ListBox list)
        {
            foreach (Submarine sub in game.submarines)
            {
                list.Items.Add(sub);
            }
            list.SelectedIndex = 0;
        }

        private void ButtonEventsAssigner(Button button)
        {
            button.MouseEnter += button_MouseEnter;
            button.MouseLeave += button_MouseLeave;
            button.Click += button_Click;
        }

        private void FormGamePlaceSubs_Shown(object sender, EventArgs e)
        {
            if (computerPlayer != 0)
            {
                MessageBox.Show(".המחשב בוחר מקומות ראשון", "בחירת המחשב",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ComputerSelect();
            }
            else
            {
                MessageBox.Show(".בחרו שחקן שיציב צוללות ראשון. השחקן השני לא יסתכל על המסך", "תחילת ההצבה",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }        
        #endregion

        #region Computer Selection
        private void ComputerSelect()
        {
            computerChoosing = true;
            AssignControlVariables(computerPlayer);

            curretResetBtn.Enabled = false;
            bool restartProcess = false;
            do
            {
                restartProcess = false;
                bool stop = false;
                int randCount = 0;
                for (int i = 0; i < game.submarines.Count; i++)
                {
                    currentSubsList.SelectedItem = currentSubsList.Items[0];
                    do
                    {
                        stop = false;
                        Button b = GetRandomButton(currentBoard);
                        button_MouseEnter(b, EventArgs.Empty);
                        if ((int)b.Tag != -1)
                        {
                            button_Click(b, EventArgs.Empty);
                            stop = true;
                        }
                        else
                        {
                            randCount++;
                            if (randCount >= 40)
                            {
                                DialogResult res = MessageBox.Show(".המחשב מתעכב בבחירת מיקום חוקי לצוללת\n" +
                                    ".זה כנראה קרה בעקבות יחס משבצות לוח למשבצות צוללות קטן מדי\n" +
                                    "?האם לחזור למסך הקודם כדי לעדכן את הערכים\n" +
                                    ".בחירת לא תתחיל את תהליך הבחירה של המחשב מחדש\n" +
                                    ".אם תבחר לא, ההודעה הזו עלולה להופיע שוב" ,
                                  "אלגוריתם המחשב תקוע", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                                if (res == DialogResult.Yes)
                                {
                                    this.Close();
                                    this.Dispose();
                                    return;
                                }
                                if (res == DialogResult.No)
                                {
                                    if (computerPlayer == 1) { reset1_Click(null, EventArgs.Empty); }
                                    else { reset2_Click(null, EventArgs.Empty); }
                                    restartProcess = true;
                                }
                                break;
                            }
                        }
                    } while (!stop);
                }
            } while (restartProcess);

            computerChoosing = false;
        }

        private Button GetRandomButton(Control board)
        {
            List<Button> enabledBtns = new List<Button>();
            foreach (Button b in board.Controls)
            {
                if (b.Enabled)
                {
                    enabledBtns.Add(b);
                }
            }
            int i = random.Next(0, enabledBtns.Count);
            return enabledBtns[i];
        }

        #endregion

        #region ListBox Choices and Resets
        private void listSubs1_SelectedIndexChanged(object sender, EventArgs e)
        {

            foreach (Control c in board1.Controls)
            {
                if ((int)c.Tag != 1)
                {
                    c.Enabled = true;
                    c.BackColor = SystemColors.Control;
                }
            }
            
            if (listSubs1.SelectedItem == null) { return; }
            int id = SubmarinesUtils.GetIdFromDetails(listSubs1.SelectedItem.ToString());
            Submarine selectedSub = game.submarines.FirstOrDefault(sub => sub.subId == id);
            if (selectedSub == null) { return; }
            foreach (Control c in board1.Controls)
            {
                if (c is Button button)
                {
                    int[] indicies = SubmarinesUtils.GetButtonIndices(button);
                    int bRow = indicies[0];
                    int bCol = indicies[1];
                    int sRow = selectedSub.subRows;
                    int sCol = selectedSub.subCols;
                    if (CheckButton(0,0,sRow,sCol,bRow,bCol,ButtonChecks.isPreviewInsideBoard) &&
                        (int)button.Tag != 1)
                    {
                        button.Enabled = false;
                        button.BackColor = Color.LightGray;
                    }
                }
            }
            IsPlacingSubmarines = true;
        }

        private void listSubs2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            foreach (Control c in board2.Controls)
            {
                if ((int)c.Tag != 1)
                {
                    c.Enabled = true;
                    c.BackColor = SystemColors.Control;
                }
            }
            if (listSubs2.SelectedItem == null) { return; }
            int id = SubmarinesUtils.GetIdFromDetails(listSubs2.SelectedItem.ToString());
            Submarine selectedSub = game.submarines.FirstOrDefault(sub => sub.subId == id);
            if (selectedSub == null) { return; }
            foreach (Control c in board2.Controls)
            {
                if (c is Button button)
                {
                    int[] indicies = SubmarinesUtils.GetButtonIndices(button);
                    int bRow = indicies[0];
                    int bCol = indicies[1];
                    int sRow = selectedSub.subRows;
                    int sCol = selectedSub.subCols;

                    if (CheckButton(0, 0, sRow, sCol, bRow, bCol, ButtonChecks.isPreviewInsideBoard) &&
                        (int)button.Tag != 1)
                    {
                        button.Enabled = false;
                        button.BackColor = Color.LightGray;
                    }
                }
            }
            IsPlacingSubmarines = true;
        }

        private void reset1_Click(object sender, EventArgs e)
        {
            subLocations.RemoveAll(location => location.player == 1);
            listSubs1.Items.Clear();
            ResetButtons(board1);
            FillSubList(listSubs1);
            boardLocations1 = new int[game.boardRows,game.boardCols];
        }

        private void reset2_Click(object sender, EventArgs e)
        {
            subLocations.RemoveAll(location => location.player == 2);
            listSubs2.Items.Clear();
            ResetButtons(board2);
            FillSubList(listSubs2);
            boardLocations2 = new int[game.boardRows, game.boardCols];
        }

        private void ResetButtons(Panel board)
        {
            if (board.Controls.Count == 0)
            {
                gameBoardCreator.CreateBoard(board);
                board.BackgroundImage = null;
            }
            else
            {
                foreach (Button b in board.Controls)
                {
                    b.Tag = 0;
                    b.BackColor = SystemColors.Control;
                }
            }
        }
        #endregion

        #region Previewing and Placing submarines
        private void button_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            AssignControlVariables(0,btn);
            if (currentSubsList.SelectedItem == null) { return; }

            int id = SubmarinesUtils.GetIdFromDetails(currentSubsList.SelectedItem.ToString());
            Submarine selectedSub = game.submarines.FirstOrDefault(sub => sub.subId == id);
            if (selectedSub == null) { return; }

            int[] indicies = SubmarinesUtils.GetButtonIndices(btn);
            int bRow = indicies[0];
            int bCol = indicies[1];
            int sRow = selectedSub.subRows;
            int sCol = selectedSub.subCols;
            bool invalid = false;

            foreach (Button b in currentBoard.Controls)
            {
                indicies = SubmarinesUtils.GetButtonIndices(b);
                int r = indicies[0];
                int c = indicies[1];
                bool isInOtherSub = (int)b.Tag == 1;
                if (CheckButton(r, c, sRow, sCol, bRow, bCol, ButtonChecks.isInPreview))
                {
                    if (!isInOtherSub)
                    {
                        b.BackColor = !computerChoosing ? Color.LightGreen : SystemColors.Control;
                    }
                    else
                    {
                        invalid = true;
                    }
                }
                if (CheckButton(r, c, sRow, sCol, bRow, bCol, ButtonChecks.IsSurroundingPreview))
                {
                    if (isInOtherSub) { invalid = true; } 
                }                
            }

            if (invalid)
            {
                btn.BackColor = !computerChoosing ? Color.Red : SystemColors.Control;
                btn.Tag = -1;
            }
        }

        private void button_MouseLeave(object sender, EventArgs e)
        {            
            if (!IsPlacingSubmarines) { return; }
            Button b = sender as Button;
            if (b.Name.Contains("board" + computerPlayer)) { return; }
            foreach (Control c in b.Parent.Controls)
            {
                if ((int)c.Tag != 1)   
                {
                    c.BackColor = c.Enabled ? SystemColors.Control : Color.LightGray;
                }
            }
        }

        private void button_Click(object sender, EventArgs e)
        {            
            Button button = sender as Button;
            if ((int)button.Tag == -1) { return; }
            
            int playerNum = AssignControlVariables(0, button);

            int id = SubmarinesUtils.GetIdFromDetails(currentSubsList.SelectedItem.ToString());
            Submarine selectedSub = game.submarines.FirstOrDefault(sub => sub.subId == id);
            if (selectedSub == null) { return; }

            int[] indicies = SubmarinesUtils.GetButtonIndices(button);
            int bRow = indicies[0];
            int bCol = indicies[1];
            int sRow = selectedSub.subRows;
            int sCol = selectedSub.subCols;
            subLocations.Add(new SubmarineLocation(playerNum, id, bRow, bCol));

            int[,] msArray = selectedSub.GetMarkedSquaresArray(dataConnection);
            foreach (Button b in currentBoard.Controls)
            {               
                indicies = SubmarinesUtils.GetButtonIndices(b);
                int r = indicies[0];
                int c = indicies[1];
                    
                if (CheckButton(r, c, sRow, sCol, bRow, bCol, ButtonChecks.isInPreview) &&
                     msArray[r - bRow, c - bCol] == 1)
                {
                    b.Tag = 1;
                    b.BackColor = computerChoosing ? SystemColors.Control :  Color.Green;
                    b.Enabled = false;
                    if(playerNum == 1) { boardLocations1[r, c] = id; };
                    if(playerNum == 2) { boardLocations2[r, c] = id; };
                }
            }
            currentSubsList.Items.Remove(currentSubsList.SelectedItem);
            if (currentSubsList.Items.Count == 0)
            {
                HideBoard(currentBoard);
            }
            else
            {
                currentSubsList.SelectedIndex = currentSubsList.TopIndex;
            }
        }

        private bool CheckButton(int row, int col, int subRows, int subCols,
            int subOriginRow, int subOriginCol, ButtonChecks check)
        {
            switch (check)
            {
                case ButtonChecks.isPreviewInsideBoard:
                    return subOriginCol + subCols > game.boardCols ||
                        subOriginRow + subRows > game.boardRows;
                case ButtonChecks.isInPreview:
                    return (row >= subOriginRow && row < subOriginRow + subRows) &&
                           (col >= subOriginCol && col < subOriginCol + subCols);
                case ButtonChecks.IsSurroundingPreview:
                    int minRow = subOriginRow - 1;
                    int maxRow = subOriginRow + subRows;
                    int minCol = subOriginCol - 1;
                    int maxCol = subOriginCol + subCols;

                    bool topRow = row == minRow && col >= minCol && col <= maxCol;
                    bool botRow = row == maxRow && col >= minCol && col <= maxCol;
                    bool rightCol = col == maxCol && row >= minRow && row <= maxRow;
                    bool leftCol = col == minCol && row >= minRow && row <= maxRow;

                    return leftCol || rightCol || topRow || botRow;

                default: return false;
            }
        }
        #endregion

        #region Hiding the board and continuing        
        private void HideBoard(Control board)
        {
            if (!board.Name.Contains("" + computerPlayer))
            {
                MessageBox.Show(".שחקן סיים להציב את הצוללות שלו. הלוח שלו יוסתר", "הסתרת לוח",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            foreach (Control control in board.Controls)
            {
                control.Dispose();
            }
            board.Controls.Clear();
            board.BackgroundImage = Properties.Resources.GameBackround;
            board.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (listSubs1.Items.Count > 0 || listSubs2.Items.Count > 0)
            {                
                MessageBox.Show(".לא כל הצוללות מוקמו", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;                                
            }

            FormGamePlay formGamePlay = new FormGamePlay(dataConnection, false, game, subLocations,
                boardLocations1, boardLocations2, new int[] { 1,1});
            SubmarinesUtils.mainGameFormOpen = true;
            FormGameStart openedGameStart = Application.OpenForms.OfType<FormGameStart>().FirstOrDefault();
            openedGameStart.Dispose();
            this.Dispose();            
            formGamePlay.Show();
        }

        #endregion

        private void FormGamePlaceSubs_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
                
        private void FormGamePlaceSubs_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!computerChoosing)
            {
                DialogResult res = MessageBox.Show(".האם אתה בטוח שברצונך לצאת? כל מיקומי הצוללות הנוכחים יאבדו",
                "?אתה בטוח שברצונך לצאת", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.No) { e.Cancel = true; }
            }
            
        }

        private void helpButton_Click(object sender, EventArgs e)
        {
            FormHelpGamePlcSbs helpGamePlcSbs = new FormHelpGamePlcSbs();
            helpGamePlcSbs.Height = panel1.Height;
            helpGamePlcSbs.Show();
        }
    }
}
