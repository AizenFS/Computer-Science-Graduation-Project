﻿namespace Submarines
{
    partial class FormAddMarkedSquare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.title = new System.Windows.Forms.Label();
            this.col = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.msSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msRowNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msColNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblMarkedSquaresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetMarkedSquares = new Submarines.DataSetMarkedSquares();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.row = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.submarines = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tblMarkedSquaresTableAdapter = new Submarines.DataSetMarkedSquaresTableAdapters.tblMarkedSquaresTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMarkedSquaresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetMarkedSquares)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.title);
            this.panel1.Controls.Add(this.col);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonAdd);
            this.panel1.Controls.Add(this.row);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.submarines);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(36, 81);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 875);
            this.panel1.TabIndex = 32;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(771, 39);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(401, 37);
            this.title.TabIndex = 32;
            this.title.Text = "הוספת משבצת מסומנת בצוללת";
            // 
            // col
            // 
            this.col.Location = new System.Drawing.Point(563, 232);
            this.col.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.col.Name = "col";
            this.col.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.col.Size = new System.Drawing.Size(110, 26);
            this.col.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(724, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "עמודה";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.msSubIDDataGridViewTextBoxColumn,
            this.msRowNumDataGridViewTextBoxColumn,
            this.msColNumDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblMarkedSquaresBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(714, 483);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(557, 312);
            this.dataGridView1.TabIndex = 16;
            // 
            // msSubIDDataGridViewTextBoxColumn
            // 
            this.msSubIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.msSubIDDataGridViewTextBoxColumn.DataPropertyName = "msSubID";
            this.msSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.msSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msSubIDDataGridViewTextBoxColumn.Name = "msSubIDDataGridViewTextBoxColumn";
            this.msSubIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // msRowNumDataGridViewTextBoxColumn
            // 
            this.msRowNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.msRowNumDataGridViewTextBoxColumn.DataPropertyName = "msRowNum";
            this.msRowNumDataGridViewTextBoxColumn.HeaderText = "שורה";
            this.msRowNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msRowNumDataGridViewTextBoxColumn.Name = "msRowNumDataGridViewTextBoxColumn";
            this.msRowNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // msColNumDataGridViewTextBoxColumn
            // 
            this.msColNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.msColNumDataGridViewTextBoxColumn.DataPropertyName = "msColNum";
            this.msColNumDataGridViewTextBoxColumn.HeaderText = "עמודה";
            this.msColNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msColNumDataGridViewTextBoxColumn.Name = "msColNumDataGridViewTextBoxColumn";
            // 
            // tblMarkedSquaresBindingSource
            // 
            this.tblMarkedSquaresBindingSource.DataMember = "tblMarkedSquares";
            this.tblMarkedSquaresBindingSource.DataSource = this.dataSetMarkedSquares;
            // 
            // dataSetMarkedSquares
            // 
            this.dataSetMarkedSquares.DataSetName = "DataSetMarkedSquares";
            this.dataSetMarkedSquares.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonAdd.Location = new System.Drawing.Point(895, 377);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(188, 52);
            this.buttonAdd.TabIndex = 4;
            this.buttonAdd.Text = "הוסף";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // row
            // 
            this.row.Location = new System.Drawing.Point(895, 232);
            this.row.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.row.Name = "row";
            this.row.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.row.Size = new System.Drawing.Size(110, 26);
            this.row.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1408, 235);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "צוללת";
            // 
            // submarines
            // 
            this.submarines.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.submarines.FormattingEnabled = true;
            this.submarines.Location = new System.Drawing.Point(1239, 232);
            this.submarines.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.submarines.Name = "submarines";
            this.submarines.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.submarines.Size = new System.Drawing.Size(137, 28);
            this.submarines.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1040, 235);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "שורה";
            // 
            // tblMarkedSquaresTableAdapter
            // 
            this.tblMarkedSquaresTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(1083, 455);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 25);
            this.label2.TabIndex = 35;
            this.label2.Text = "טבלת משבצות מסומנות";
            // 
            // FormAddMarkedSquare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormAddMarkedSquare";
            this.Text = "FormAddMarkedSquare";
            this.Load += new System.EventHandler(this.FormAddMarkedSquare_Load);
            this.SizeChanged += new System.EventHandler(this.FormAddMarkedSquare_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMarkedSquaresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetMarkedSquares)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox col;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.TextBox row;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox submarines;
        private System.Windows.Forms.Label label7;
        private DataSetMarkedSquares dataSetMarkedSquares;
        private System.Windows.Forms.BindingSource tblMarkedSquaresBindingSource;
        private DataSetMarkedSquaresTableAdapters.tblMarkedSquaresTableAdapter tblMarkedSquaresTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn msSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn msRowNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn msColNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label label2;
    }
}
