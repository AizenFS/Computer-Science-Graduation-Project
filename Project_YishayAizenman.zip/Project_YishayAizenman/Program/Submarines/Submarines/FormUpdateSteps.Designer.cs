﻿namespace Submarines
{
    partial class FormUpdateSteps
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.gameId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.orderNum = new System.Windows.Forms.TextBox();
            this.playerNum = new System.Windows.Forms.TextBox();
            this.col = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.stepGameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepOrderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepPlayerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepRowDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepColDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStepsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetSteps = new Submarines.DataSetSteps();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.row = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tblStepsTableAdapter = new Submarines.DataSetStepsTableAdapters.tblStepsTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStepsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSteps)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.buttonPrev);
            this.panel1.Controls.Add(this.buttonLast);
            this.panel1.Controls.Add(this.buttonNext);
            this.panel1.Controls.Add(this.buttonFirst);
            this.panel1.Controls.Add(this.gameId);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.orderNum);
            this.panel1.Controls.Add(this.playerNum);
            this.panel1.Controls.Add(this.col);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonUpdate);
            this.panel1.Controls.Add(this.row);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(61, 14);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 999);
            this.panel1.TabIndex = 35;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(881, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(163, 37);
            this.label11.TabIndex = 36;
            this.label11.Text = "עדכון מהלך";
            // 
            // buttonPrev
            // 
            this.buttonPrev.Enabled = false;
            this.buttonPrev.Location = new System.Drawing.Point(820, 511);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(93, 51);
            this.buttonPrev.TabIndex = 5;
            this.buttonPrev.Text = "הקודם";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(623, 511);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(92, 51);
            this.buttonLast.TabIndex = 6;
            this.buttonLast.Text = "אחרון";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Enabled = false;
            this.buttonNext.Location = new System.Drawing.Point(1012, 511);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(93, 51);
            this.buttonNext.TabIndex = 4;
            this.buttonNext.Text = "הבא";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(1208, 511);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(90, 51);
            this.buttonFirst.TabIndex = 3;
            this.buttonFirst.Text = "ראשון";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // gameId
            // 
            this.gameId.Enabled = false;
            this.gameId.Location = new System.Drawing.Point(1108, 329);
            this.gameId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gameId.Name = "gameId";
            this.gameId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gameId.Size = new System.Drawing.Size(110, 26);
            this.gameId.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1229, 332);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 31;
            this.label3.Text = "מספר משחק";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1026, 397);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "שורה";
            // 
            // orderNum
            // 
            this.orderNum.Enabled = false;
            this.orderNum.Location = new System.Drawing.Point(623, 329);
            this.orderNum.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.orderNum.Name = "orderNum";
            this.orderNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.orderNum.Size = new System.Drawing.Size(110, 26);
            this.orderNum.TabIndex = 29;
            // 
            // playerNum
            // 
            this.playerNum.Location = new System.Drawing.Point(1108, 394);
            this.playerNum.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.playerNum.Name = "playerNum";
            this.playerNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.playerNum.Size = new System.Drawing.Size(110, 26);
            this.playerNum.TabIndex = 0;
            // 
            // col
            // 
            this.col.Location = new System.Drawing.Point(900, 394);
            this.col.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.col.Name = "col";
            this.col.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.col.Size = new System.Drawing.Size(110, 26);
            this.col.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(802, 397);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "עמודה";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stepGameIDDataGridViewTextBoxColumn,
            this.stepOrderNumDataGridViewTextBoxColumn,
            this.stepPlayerDataGridViewTextBoxColumn,
            this.stepRowDataGridViewTextBoxColumn,
            this.stepColDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStepsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(623, 641);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(695, 312);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // stepGameIDDataGridViewTextBoxColumn
            // 
            this.stepGameIDDataGridViewTextBoxColumn.DataPropertyName = "stepGameID";
            this.stepGameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.stepGameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepGameIDDataGridViewTextBoxColumn.Name = "stepGameIDDataGridViewTextBoxColumn";
            this.stepGameIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.stepGameIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // stepOrderNumDataGridViewTextBoxColumn
            // 
            this.stepOrderNumDataGridViewTextBoxColumn.DataPropertyName = "stepOrderNum";
            this.stepOrderNumDataGridViewTextBoxColumn.HeaderText = "מספר מהלך";
            this.stepOrderNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepOrderNumDataGridViewTextBoxColumn.Name = "stepOrderNumDataGridViewTextBoxColumn";
            this.stepOrderNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.stepOrderNumDataGridViewTextBoxColumn.Width = 122;
            // 
            // stepPlayerDataGridViewTextBoxColumn
            // 
            this.stepPlayerDataGridViewTextBoxColumn.DataPropertyName = "stepPlayer";
            this.stepPlayerDataGridViewTextBoxColumn.HeaderText = "שחקן";
            this.stepPlayerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepPlayerDataGridViewTextBoxColumn.Name = "stepPlayerDataGridViewTextBoxColumn";
            this.stepPlayerDataGridViewTextBoxColumn.ReadOnly = true;
            this.stepPlayerDataGridViewTextBoxColumn.Width = 82;
            // 
            // stepRowDataGridViewTextBoxColumn
            // 
            this.stepRowDataGridViewTextBoxColumn.DataPropertyName = "stepRow";
            this.stepRowDataGridViewTextBoxColumn.HeaderText = "שורה";
            this.stepRowDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepRowDataGridViewTextBoxColumn.Name = "stepRowDataGridViewTextBoxColumn";
            this.stepRowDataGridViewTextBoxColumn.ReadOnly = true;
            this.stepRowDataGridViewTextBoxColumn.Width = 79;
            // 
            // stepColDataGridViewTextBoxColumn
            // 
            this.stepColDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.stepColDataGridViewTextBoxColumn.DataPropertyName = "stepCol";
            this.stepColDataGridViewTextBoxColumn.HeaderText = "עמודה";
            this.stepColDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepColDataGridViewTextBoxColumn.Name = "stepColDataGridViewTextBoxColumn";
            this.stepColDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblStepsBindingSource
            // 
            this.tblStepsBindingSource.DataMember = "tblSteps";
            this.tblStepsBindingSource.DataSource = this.dataSetSteps;
            // 
            // dataSetSteps
            // 
            this.dataSetSteps.DataSetName = "DataSetSteps";
            this.dataSetSteps.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonUpdate.Location = new System.Drawing.Point(286, 434);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(188, 59);
            this.buttonUpdate.TabIndex = 7;
            this.buttonUpdate.Text = "עדכן";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // row
            // 
            this.row.Location = new System.Drawing.Point(623, 394);
            this.row.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.row.Name = "row";
            this.row.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.row.Size = new System.Drawing.Size(110, 26);
            this.row.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1272, 397);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "שחקן";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(764, 332);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "מספר מהלך ";
            // 
            // tblStepsTableAdapter
            // 
            this.tblStepsTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1203, 613);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 25);
            this.label8.TabIndex = 37;
            this.label8.Text = "טבלת מהלכים";
            // 
            // FormUpdateSteps
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormUpdateSteps";
            this.Text = "FormUpdateSteps";
            this.Load += new System.EventHandler(this.FormUpdateSteps_Load);
            this.SizeChanged += new System.EventHandler(this.FormUpdateSteps_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStepsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSteps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox orderNum;
        private System.Windows.Forms.TextBox playerNum;
        private System.Windows.Forms.TextBox col;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.TextBox row;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private DataSetSteps dataSetSteps;
        private System.Windows.Forms.BindingSource tblStepsBindingSource;
        private DataSetStepsTableAdapters.tblStepsTableAdapter tblStepsTableAdapter;
        private System.Windows.Forms.TextBox gameId;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepGameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepOrderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepPlayerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepRowDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepColDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
