﻿namespace Submarines
{
    partial class FormSearchStartGames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.startGameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startOrderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStartGamesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetStartGames = new Submarines.DataSetStartGames();
            this.refreshButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.searchStr = new System.Windows.Forms.TextBox();
            this.tblStartGamesTableAdapter = new Submarines.DataSetStartGamesTableAdapters.tblStartGamesTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.refreshButton);
            this.panel1.Controls.Add(this.searchButton);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.searchStr);
            this.panel1.Location = new System.Drawing.Point(97, 66);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1778, 900);
            this.panel1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(535, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(648, 38);
            this.label2.TabIndex = 18;
            this.label2.Text = "חיפוש בטבלת מיקומי צוללות בתחילת משחק";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.startGameIDDataGridViewTextBoxColumn,
            this.startOrderNumDataGridViewTextBoxColumn,
            this.startSubIDDataGridViewTextBoxColumn,
            this.startRow1DataGridViewTextBoxColumn,
            this.startCol1DataGridViewTextBoxColumn,
            this.startRow2DataGridViewTextBoxColumn,
            this.startCol2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStartGamesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(21, 309);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(1643, 520);
            this.dataGridView1.TabIndex = 15;
            // 
            // startGameIDDataGridViewTextBoxColumn
            // 
            this.startGameIDDataGridViewTextBoxColumn.DataPropertyName = "startGameID";
            this.startGameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.startGameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startGameIDDataGridViewTextBoxColumn.Name = "startGameIDDataGridViewTextBoxColumn";
            this.startGameIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.startGameIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startOrderNumDataGridViewTextBoxColumn
            // 
            this.startOrderNumDataGridViewTextBoxColumn.DataPropertyName = "startOrderNum";
            this.startOrderNumDataGridViewTextBoxColumn.HeaderText = "מס סידורי צוללת";
            this.startOrderNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startOrderNumDataGridViewTextBoxColumn.Name = "startOrderNumDataGridViewTextBoxColumn";
            this.startOrderNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.startOrderNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // startSubIDDataGridViewTextBoxColumn
            // 
            this.startSubIDDataGridViewTextBoxColumn.DataPropertyName = "startSubID";
            this.startSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.startSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startSubIDDataGridViewTextBoxColumn.Name = "startSubIDDataGridViewTextBoxColumn";
            this.startSubIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.startSubIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow1DataGridViewTextBoxColumn
            // 
            this.startRow1DataGridViewTextBoxColumn.DataPropertyName = "startRow1";
            this.startRow1DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 1";
            this.startRow1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow1DataGridViewTextBoxColumn.Name = "startRow1DataGridViewTextBoxColumn";
            this.startRow1DataGridViewTextBoxColumn.ReadOnly = true;
            this.startRow1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol1DataGridViewTextBoxColumn
            // 
            this.startCol1DataGridViewTextBoxColumn.DataPropertyName = "startCol1";
            this.startCol1DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 1";
            this.startCol1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol1DataGridViewTextBoxColumn.Name = "startCol1DataGridViewTextBoxColumn";
            this.startCol1DataGridViewTextBoxColumn.ReadOnly = true;
            this.startCol1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow2DataGridViewTextBoxColumn
            // 
            this.startRow2DataGridViewTextBoxColumn.DataPropertyName = "startRow2";
            this.startRow2DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 2";
            this.startRow2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow2DataGridViewTextBoxColumn.Name = "startRow2DataGridViewTextBoxColumn";
            this.startRow2DataGridViewTextBoxColumn.ReadOnly = true;
            this.startRow2DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol2DataGridViewTextBoxColumn
            // 
            this.startCol2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.startCol2DataGridViewTextBoxColumn.DataPropertyName = "startCol2";
            this.startCol2DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 2";
            this.startCol2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol2DataGridViewTextBoxColumn.Name = "startCol2DataGridViewTextBoxColumn";
            this.startCol2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblStartGamesBindingSource
            // 
            this.tblStartGamesBindingSource.DataMember = "tblStartGames";
            this.tblStartGamesBindingSource.DataSource = this.dataSetStartGames;
            // 
            // dataSetStartGames
            // 
            this.dataSetStartGames.DataSetName = "DataSetStartGames";
            this.dataSetStartGames.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // refreshButton
            // 
            this.refreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Location = new System.Drawing.Point(547, 225);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(133, 53);
            this.refreshButton.TabIndex = 3;
            this.refreshButton.Text = "רענן";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Location = new System.Drawing.Point(710, 225);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(133, 53);
            this.searchButton.TabIndex = 2;
            this.searchButton.Text = "חפש";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1066, 245);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "טקסט לחיפוש:";
            // 
            // searchStr
            // 
            this.searchStr.Location = new System.Drawing.Point(897, 242);
            this.searchStr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.searchStr.Name = "searchStr";
            this.searchStr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchStr.Size = new System.Drawing.Size(148, 26);
            this.searchStr.TabIndex = 1;
            // 
            // tblStartGamesTableAdapter
            // 
            this.tblStartGamesTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(1505, 281);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 25);
            this.label4.TabIndex = 36;
            this.label4.Text = "טבלת תחילת משחק";
            // 
            // FormSearchStartGames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormSearchStartGames";
            this.Text = "FormSearchStartGames";
            this.Load += new System.EventHandler(this.FormSearchStartGames_Load);
            this.SizeChanged += new System.EventHandler(this.FormSearchStartGames_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox searchStr;
        private System.Windows.Forms.Label label2;
        private DataSetStartGames dataSetStartGames;
        private System.Windows.Forms.BindingSource tblStartGamesBindingSource;
        private DataSetStartGamesTableAdapters.tblStartGamesTableAdapter tblStartGamesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn startGameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startOrderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol2DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label4;
    }
}
