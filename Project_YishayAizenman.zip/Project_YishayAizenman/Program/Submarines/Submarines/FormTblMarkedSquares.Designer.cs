﻿namespace Submarines
{
    partial class FormTblMarkedSquares
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.msSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msRowNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msColNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblMarkedSquaresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetMarkedSquares = new Submarines.DataSetMarkedSquares();
            this.tblMarkedSquaresTableAdapter = new Submarines.DataSetMarkedSquaresTableAdapters.tblMarkedSquaresTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMarkedSquaresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetMarkedSquares)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(63, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1793, 1035);
            this.panel1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(1067, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 25);
            this.label3.TabIndex = 35;
            this.label3.Text = "טבלת משבצות מסומנות";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(596, 156);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(554, 37);
            this.label2.TabIndex = 6;
            this.label2.Text = "טבלת משבצות מסומנות בצוללות";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(846, 958);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 53);
            this.saveButton.TabIndex = 1;
            this.saveButton.Text = "שמור";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.msSubIDDataGridViewTextBoxColumn,
            this.msRowNumDataGridViewTextBoxColumn,
            this.msColNumDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblMarkedSquaresBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(535, 292);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(720, 630);
            this.dataGridView1.TabIndex = 0;
            // 
            // msSubIDDataGridViewTextBoxColumn
            // 
            this.msSubIDDataGridViewTextBoxColumn.DataPropertyName = "msSubID";
            this.msSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.msSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msSubIDDataGridViewTextBoxColumn.Name = "msSubIDDataGridViewTextBoxColumn";
            this.msSubIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // msRowNumDataGridViewTextBoxColumn
            // 
            this.msRowNumDataGridViewTextBoxColumn.DataPropertyName = "msRowNum";
            this.msRowNumDataGridViewTextBoxColumn.HeaderText = "מספר שורה";
            this.msRowNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msRowNumDataGridViewTextBoxColumn.Name = "msRowNumDataGridViewTextBoxColumn";
            this.msRowNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // msColNumDataGridViewTextBoxColumn
            // 
            this.msColNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.msColNumDataGridViewTextBoxColumn.DataPropertyName = "msColNum";
            this.msColNumDataGridViewTextBoxColumn.HeaderText = "מספר עמודה";
            this.msColNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msColNumDataGridViewTextBoxColumn.Name = "msColNumDataGridViewTextBoxColumn";
            // 
            // tblMarkedSquaresBindingSource
            // 
            this.tblMarkedSquaresBindingSource.DataMember = "tblMarkedSquares";
            this.tblMarkedSquaresBindingSource.DataSource = this.dataSetMarkedSquares;
            // 
            // dataSetMarkedSquares
            // 
            this.dataSetMarkedSquares.DataSetName = "DataSetMarkedSquares";
            this.dataSetMarkedSquares.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblMarkedSquaresTableAdapter
            // 
            this.tblMarkedSquaresTableAdapter.ClearBeforeFill = true;
            // 
            // FormTblMarkedSquares
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormTblMarkedSquares";
            this.Text = "FormTblMarkedSquares";
            this.Load += new System.EventHandler(this.FormTblMarkedSquares_Load);
            this.SizeChanged += new System.EventHandler(this.FormTblMarkedSquares_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMarkedSquaresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetMarkedSquares)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private DataSetMarkedSquares dataSetMarkedSquares;
        private System.Windows.Forms.BindingSource tblMarkedSquaresBindingSource;
        private DataSetMarkedSquaresTableAdapters.tblMarkedSquaresTableAdapter tblMarkedSquaresTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn msSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn msRowNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn msColNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
    }
}
