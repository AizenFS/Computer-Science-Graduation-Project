﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;


namespace Submarines
{
    public partial class FormGameSelect : Submarines.FormBaseGame
    {
        public enum NextForm { ContinueGame, ReplayGame}

        private readonly OleDbConnection dataConnection;
        private NextForm nextForm;

        private List<int[]> subsCoords;

        DataGridViewRow selectedRow;
        int gameId;
        int currentTurn;

        int AScount1, AScount2;
        private int[,] boardLocations1, boardLocations2;

        public FormGameSelect(OleDbConnection dataConnection, NextForm nextForm)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

            this.dataConnection = dataConnection;
            this.nextForm = nextForm;

            AScount1 = 1;
            AScount2 = 1;

            subsCoords = new List<int[]>();             
        }

        #region initiallization
        private void FormGameSelect_Load(object sender, EventArgs e)
        {
            if (ShowAppropriateGames(nextForm))
            {
                DataGridViewCellEventArgs clickDefaultRow = new DataGridViewCellEventArgs(0, 0);
                dataGridView1_CellClick(this, clickDefaultRow);
            }
            else
            {
                HidePlayerControls();
                string s = nextForm == NextForm.ReplayGame ? "לשחזר" : "להמשיך";
                MessageBox.Show($"לא נמצאו משחקים שניתן {s}.");
            }
        }
        private bool ShowAppropriateGames(NextForm nextForm)
        {
            string whereCondition = "";
            if (nextForm == NextForm.ReplayGame)
            {
                whereCondition = "NOT";
            }
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM tblGames " +
                                     $"WHERE YEAR(gameTime) {whereCondition} IN (2001, 2002) " +
                                     "ORDER BY gameID DESC";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                if (dataGridView1.Rows.Count > 0)
                {
                    SubmarinesUtils.SetDataGridViewTimeFormat(dataGridView1, 8);
                    return true;
                }
                return false;
            }
            catch (Exception err)
            {
                MessageBox.Show("show dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        private void HidePlayerControls()
        {
            playerNameAndPic1.Visible = false;
            playerNameAndPic2.Visible = false;
            labelP1.Visible = false;
            labelP2.Visible = false;           
        }
        #endregion

        #region  Assemble Game Object
        private void UpdatePlantedGameInfoVariables()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT gameTime " +
                                          "FROM tblGames " +
                                          "WHERE gameID = @id";
                datacommand.Parameters.AddWithValue("@id", gameId);
                DateTime time = (DateTime)datacommand.ExecuteScalar();
                currentTurn = time.Year % 10;
                AScount1 = time.Month == 11 ? 0 : time.Month % 10;
                AScount2 = time.Day == 11 ? 0 : time.Day % 10;
            }
            catch (Exception err)
            {
                MessageBox.Show("getting Planted unfinished game data failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetReplayStarterPlayer()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT stepPlayer " +
                                          "FROM tblSteps " +
                                          "WHERE stepGameID = @id";
                datacommand.Parameters.AddWithValue("@id", gameId);
                currentTurn = (int)datacommand.ExecuteScalar();
            }
            catch (Exception err)
            {
                MessageBox.Show("getting starter player failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);             
            }
            return currentTurn;
        }

        private Player GetPlayer(int playerId)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerFirstName, playerLastName " +
                                          "FROM tblPlayers " +
                                          "WHERE playerID = @playerId";
                datacommand.Parameters.AddWithValue("@playerId", playerId);
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                dataReader.Read();
                Player player = new Player(playerId, dataReader.GetString(0), dataReader.GetString(1));
                dataReader.Close();
                return player;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get player details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private Game GetGameDetails()
        {            
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = 
                    "SELECT gameBoardRows, gameBoardCols, gamePlayer1ID, gameType1,gamePlayer2ID, gameType2," +
                    "       gameColor1, gameColor2 " +
                    "FROM tblGames " +
                    "WHERE gameID = @gameID";
                datacommand.Parameters.AddWithValue("@gameID", gameId);
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                dataReader.Read();

                int r = dataReader.GetInt32(0);
                int c = dataReader.GetInt32(1);
                Player p1 = GetPlayer(dataReader.GetInt32(2));

                int argb = dataReader.GetInt32(6);
                bool isBot = dataReader.GetInt32(3) == 2;
                p1 = new Player(p1, argb, isBot);

                Player p2 = GetPlayer(dataReader.GetInt32(4));
                argb = dataReader.GetInt32(7);
                isBot = dataReader.GetInt32(5) == 2;
                p2 = new Player(p2 , argb, isBot);

                dataReader.Close();

                List<Submarine> subList = GetGameSubsList();
                if(nextForm == NextForm.ReplayGame) { currentTurn = GetReplayStarterPlayer(); }

                return new Game(gameId, currentTurn, r, c, p1, p2, subList);
            }
            catch (Exception err)
            {
                MessageBox.Show("Get game details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private List<Submarine> GetGameSubsList()
        {
            List<Submarine> list = new List<Submarine>();
            string s = "";
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "SELECT s.*, sg.startRow1, sg.startCol1, sg.startRow2, sg.startCol2 " +
                    "FROM tblStartGames AS sg " +
                    "INNER JOIN tblSubmarines AS s " +
                    "ON s.subID = sg.startSubID " +
                    "WHERE sg.startGameID = @gameID " +
                    "ORDER BY sg.startOrderNum";
                datacommand.Parameters.AddWithValue("@gameID", gameId);
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    int id = dataReader.GetInt32(0);
                    int rows = dataReader.GetInt32(1);
                    int cols = dataReader.GetInt32(2);
                    string name = dataReader.GetString(3);
                    int sinkP = dataReader.GetInt32(4);
                    list.Add(new Submarine(id, name, rows, cols, sinkP));
                    int[] coords = new int[5];
                    coords[0] = id;
                    coords[1] = dataReader.GetInt32(5);
                    coords[2] = dataReader.GetInt32(6);
                    coords[3] = dataReader.GetInt32(7);
                    coords[4] = dataReader.GetInt32(8);
                    subsCoords.Add(coords);
                }
                dataReader.Close();
                return list;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get subs list failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return list;
            }
        }
        #endregion

        #region Create Board Location arrays
        private void CreateBoardLocations(int boardNum, List<Submarine> subsList)
        {
            int[,] board = boardNum == 1 ? boardLocations1 : boardLocations2;
            string s = "";
            foreach(Submarine sub in subsList)
            {
                int[,] markedSquares = sub.GetMarkedSquaresArray(dataConnection);
                int[] coords = subsCoords.First(coordArr => coordArr[0] == sub.subId);
                int originRow = boardNum == 1 ? coords[1] : coords[3];
                int originCol = boardNum == 1 ? coords[2] : coords[4];
                EmbedArray(board, markedSquares, originRow, originCol, sub.subId);
            }
        }

        private void EmbedArray(int[,] bigArray, int[,] smallArray, int startRow, int startColumn, int fillValue)
        {
            int smallRows = smallArray.GetLength(0);
            int smallColumns = smallArray.GetLength(1);

            for (int i = 0; i < smallRows; i++)
            {
                for (int j = 0; j < smallColumns; j++)
                {
                    if (smallArray[i, j] != 0)
                    {
                        bigArray[startRow + i, startColumn + j] = fillValue;
                    }
                }
            }
        }

        private void RerunPreviousSteps()
        {
            OleDbCommand datacommand = new OleDbCommand();
            datacommand.Connection = dataConnection;
            datacommand.CommandText =
                "SELECT stepOrderNum, stepPlayer, stepRow, stepCol " +
                "FROM tblSteps " +
                "WHERE stepGameID = @gameID";
            datacommand.Parameters.AddWithValue("@gameID", gameId);

            OleDbDataReader dataReader = datacommand.ExecuteReader();
            while (dataReader.Read())
            {
                double orderNum = dataReader.GetDouble(0);
                int playerNum = dataReader.GetInt32(1);
                int r = dataReader.GetInt32(2);
                int c = dataReader.GetInt32(3);

                int[,] board = playerNum == 1 ? boardLocations2 : boardLocations1;
                if (board[r, c] == 0 || board[r,c] == -999) { board[r, c] = -999; }
                else { board[r, c] *= -1; }
            }
        }
        #endregion

        #region DataGridView management
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                selectedRow = dataGridView1.SelectedRows[0];
                gameId = SubmarinesUtils.GetIdFromDetails(selectedRow.Cells[0].Value.ToString());
                SetupPlayerNameAndPic(1);
                SetupPlayerNameAndPic(2);
            }
        }

        private void SetupPlayerNameAndPic(int playerNum)
        {
            playerNameAndPic playerNameAndPic = playerNum == 1 ? playerNameAndPic1 : playerNameAndPic2;
            int i = playerNum == 1 ? 3 : 5;
            int playerID = int.Parse(selectedRow.Cells[i].Value.ToString());
            Player player = GetPlayer(playerID);
            playerNameAndPic.UpdateProperties(player,dataConnection);
        }
        #endregion

        #region Continuing
        private void RemovePlantedInfo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "UPDATE tblGames " +
                    "SET gameTime = DateValue(#12/30/1899#) + TimeValue(gameTime) " +
                    "WHERE gameID = @id";
                datacommand.Parameters.AddWithValue("@id", gameId);
                datacommand.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("Unplanting unfinished game data failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) {
                MessageBox.Show("לא נבחר משחק, לחץ על" +
                                ".שורה כדי לבחור משחק",
                                "שגיאה",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                );
                return;
            }

            UpdatePlantedGameInfoVariables();
            Game game = GetGameDetails();

            boardLocations1 = new int[game.boardRows,game.boardCols];
            boardLocations2 = new int[game.boardRows, game.boardCols];

            CreateBoardLocations(1,game.submarines);
            CreateBoardLocations(2,game.submarines);

            if (nextForm == NextForm.ContinueGame)
            {
                RerunPreviousSteps();
                int[] airStrikeCounts = new int[] { AScount1, AScount2 };
                RemovePlantedInfo();

                this.Hide();
                FormGamePlay formGamePlay = new FormGamePlay(dataConnection, true, game, new List<SubmarineLocation>(),
                    boardLocations1, boardLocations2, airStrikeCounts);
                SubmarinesUtils.mainGameFormOpen = true;
                formGamePlay.Show();
            }
            else
            {                
                this.Hide();
                FormGameReplay formGameReplay = new FormGameReplay(dataConnection, game,
                    boardLocations1, boardLocations2);
                formGameReplay.Show();
                formGameReplay.FormClosed += (s, args) => 
                {   this.Show();
                    subsCoords = new List<int[]>();
                };
            }
        }
        #endregion

        private void FormGameContinue_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }

        private void helpButton_Click(object sender, EventArgs e)
        {
            FormHelpGameSelect helpGameSelect = new FormHelpGameSelect();
            helpGameSelect.Height = panel1.Height;
            helpGameSelect.Show();
        }
    }
}
