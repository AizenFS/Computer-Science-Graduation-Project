﻿namespace Submarines
{
    partial class FormAddStartGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.title = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gameId = new System.Windows.Forms.ComboBox();
            this.p2Col = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.startGameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startOrderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStartGamesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetStartGames = new Submarines.DataSetStartGames();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.p1Col = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.p1Row = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.p2Row = new System.Windows.Forms.TextBox();
            this.submarines = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.subOrder = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tblStartGamesTableAdapter = new Submarines.DataSetStartGamesTableAdapters.tblStartGamesTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(659, 10);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(452, 37);
            this.title.TabIndex = 30;
            this.title.Text = "הוספת מיקום צוללת בתחילת משחק";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.gameId);
            this.panel1.Controls.Add(this.title);
            this.panel1.Controls.Add(this.p2Col);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonAdd);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.p1Col);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.p1Row);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.p2Row);
            this.panel1.Controls.Add(this.submarines);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.subOrder);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(36, 82);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 874);
            this.panel1.TabIndex = 31;
            // 
            // gameId
            // 
            this.gameId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gameId.FormattingEnabled = true;
            this.gameId.Location = new System.Drawing.Point(642, 233);
            this.gameId.Name = "gameId";
            this.gameId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gameId.Size = new System.Drawing.Size(411, 28);
            this.gameId.TabIndex = 1;
            // 
            // p2Col
            // 
            this.p2Col.Location = new System.Drawing.Point(423, 341);
            this.p2Col.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p2Col.Name = "p2Col";
            this.p2Col.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p2Col.Size = new System.Drawing.Size(110, 26);
            this.p2Col.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(561, 347);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "עמודה שחקן 2";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.startGameIDDataGridViewTextBoxColumn,
            this.startOrderNumDataGridViewTextBoxColumn,
            this.startSubIDDataGridViewTextBoxColumn,
            this.startRow1DataGridViewTextBoxColumn,
            this.startCol1DataGridViewTextBoxColumn,
            this.startRow2DataGridViewTextBoxColumn,
            this.startCol2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStartGamesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(82, 550);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(1643, 312);
            this.dataGridView1.TabIndex = 16;
            // 
            // startGameIDDataGridViewTextBoxColumn
            // 
            this.startGameIDDataGridViewTextBoxColumn.DataPropertyName = "startGameID";
            this.startGameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.startGameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startGameIDDataGridViewTextBoxColumn.Name = "startGameIDDataGridViewTextBoxColumn";
            this.startGameIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startOrderNumDataGridViewTextBoxColumn
            // 
            this.startOrderNumDataGridViewTextBoxColumn.DataPropertyName = "startOrderNum";
            this.startOrderNumDataGridViewTextBoxColumn.HeaderText = "מספר סידורי צוללת";
            this.startOrderNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startOrderNumDataGridViewTextBoxColumn.Name = "startOrderNumDataGridViewTextBoxColumn";
            this.startOrderNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // startSubIDDataGridViewTextBoxColumn
            // 
            this.startSubIDDataGridViewTextBoxColumn.DataPropertyName = "startSubID";
            this.startSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.startSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startSubIDDataGridViewTextBoxColumn.Name = "startSubIDDataGridViewTextBoxColumn";
            this.startSubIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow1DataGridViewTextBoxColumn
            // 
            this.startRow1DataGridViewTextBoxColumn.DataPropertyName = "startRow1";
            this.startRow1DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 1";
            this.startRow1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow1DataGridViewTextBoxColumn.Name = "startRow1DataGridViewTextBoxColumn";
            this.startRow1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol1DataGridViewTextBoxColumn
            // 
            this.startCol1DataGridViewTextBoxColumn.DataPropertyName = "startCol1";
            this.startCol1DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 1";
            this.startCol1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol1DataGridViewTextBoxColumn.Name = "startCol1DataGridViewTextBoxColumn";
            this.startCol1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow2DataGridViewTextBoxColumn
            // 
            this.startRow2DataGridViewTextBoxColumn.DataPropertyName = "startRow2";
            this.startRow2DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 2";
            this.startRow2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow2DataGridViewTextBoxColumn.Name = "startRow2DataGridViewTextBoxColumn";
            this.startRow2DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol2DataGridViewTextBoxColumn
            // 
            this.startCol2DataGridViewTextBoxColumn.DataPropertyName = "startCol2";
            this.startCol2DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 2";
            this.startCol2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol2DataGridViewTextBoxColumn.Name = "startCol2DataGridViewTextBoxColumn";
            this.startCol2DataGridViewTextBoxColumn.Width = 150;
            // 
            // tblStartGamesBindingSource
            // 
            this.tblStartGamesBindingSource.DataMember = "tblStartGames";
            this.tblStartGamesBindingSource.DataSource = this.dataSetStartGames;
            // 
            // dataSetStartGames
            // 
            this.dataSetStartGames.DataSetName = "DataSetStartGames";
            this.dataSetStartGames.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonAdd.Location = new System.Drawing.Point(866, 458);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(131, 52);
            this.buttonAdd.TabIndex = 8;
            this.buttonAdd.Text = "הוסף";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1088, 236);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "מספר משחק";
            // 
            // p1Col
            // 
            this.p1Col.Location = new System.Drawing.Point(797, 341);
            this.p1Col.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p1Col.Name = "p1Col";
            this.p1Col.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p1Col.Size = new System.Drawing.Size(110, 26);
            this.p1Col.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(947, 288);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "שורה שחקן 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1390, 344);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "צוללת";
            // 
            // p1Row
            // 
            this.p1Row.Location = new System.Drawing.Point(797, 285);
            this.p1Row.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p1Row.Name = "p1Row";
            this.p1Row.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p1Row.Size = new System.Drawing.Size(110, 26);
            this.p1Row.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(570, 288);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "שורה שחקן 2";
            // 
            // p2Row
            // 
            this.p2Row.Location = new System.Drawing.Point(423, 285);
            this.p2Row.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p2Row.Name = "p2Row";
            this.p2Row.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p2Row.Size = new System.Drawing.Size(110, 26);
            this.p2Row.TabIndex = 4;
            // 
            // submarines
            // 
            this.submarines.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.submarines.FormattingEnabled = true;
            this.submarines.Location = new System.Drawing.Point(1138, 341);
            this.submarines.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.submarines.Name = "submarines";
            this.submarines.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.submarines.Size = new System.Drawing.Size(148, 28);
            this.submarines.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1304, 288);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "מספר סידורי צוללת";
            // 
            // subOrder
            // 
            this.subOrder.Location = new System.Drawing.Point(1138, 285);
            this.subOrder.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.subOrder.Name = "subOrder";
            this.subOrder.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.subOrder.Size = new System.Drawing.Size(148, 26);
            this.subOrder.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(938, 344);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "עמודה שחקן 1";
            // 
            // tblStartGamesTableAdapter
            // 
            this.tblStartGamesTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1439, 522);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(286, 25);
            this.label8.TabIndex = 35;
            this.label8.Text = "טבלת מיקומי צוללות בתחילת משחק";
            // 
            // FormAddStartGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormAddStartGame";
            this.Text = "FormAddStartGame";
            this.Load += new System.EventHandler(this.FormAddStartGame_Load);
            this.SizeChanged += new System.EventHandler(this.FormAddStartGame_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox p2Col;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox p1Col;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox p1Row;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox p2Row;
        private System.Windows.Forms.ComboBox submarines;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox subOrder;
        private System.Windows.Forms.Label label7;
        private DataSetStartGames dataSetStartGames;
        private System.Windows.Forms.BindingSource tblStartGamesBindingSource;
        private DataSetStartGamesTableAdapters.tblStartGamesTableAdapter tblStartGamesTableAdapter;
        private System.Windows.Forms.ComboBox gameId;
        private System.Windows.Forms.DataGridViewTextBoxColumn startGameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startOrderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol2DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
