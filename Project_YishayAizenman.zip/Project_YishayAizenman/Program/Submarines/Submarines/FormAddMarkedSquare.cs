﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormAddMarkedSquare : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        public FormAddMarkedSquare(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillSubmarinesCombo();
        }

        private void FillSubmarinesCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT subID, subName " +
                                          "FROM tblSubmarines "+
                                          "ORDER BY subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    submarines.Items.Add(dataReader.GetInt32(0).ToString()+", "+dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarines combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddMarkedSquare_Load(object sender, EventArgs e)
        {
            this.tblMarkedSquaresTableAdapter.Fill(this.dataSetMarkedSquares.tblMarkedSquares);
            dataGridView1.AllowUserToAddRows = false;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = string.Format(
                    "INSERT INTO tblMarkedSquares " +
                    "(msSubID, msRowNum, msColNum) " +
                    "VALUES ({0}, {1}, {2})",
                    SubmarinesUtils.GetIdFromDetails(submarines.Text),row.Text,col.Text);                                    
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblMarkedSquares ended successfully", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblMarkedSquares failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM tblMarkedSquares ";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddMarkedSquare_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (this.ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (this.ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack(); panel1.Left = (this.ClientSize.Width - panel1.Width) / 2;
        }
    }
}

