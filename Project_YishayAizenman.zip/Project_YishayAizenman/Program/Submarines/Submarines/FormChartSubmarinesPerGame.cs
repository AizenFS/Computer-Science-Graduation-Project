﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormChartSubmarinesPerGame : Submarines.FormBaseCharts
    {
        private OleDbConnection dataConnection;
        private int counter;
        private string[] arrGames;
        private int[] arrCounts;

        public FormChartSubmarinesPerGame(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            CountGames();
            arrGames = new string[counter];
            arrCounts = new int[counter];
            FillArrGames();
            FillArrCounts();
            ShowChart();
            EditDataGridView();
        }

        private void CountGames()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT   COUNT(*) " +
                                          "FROM     tblGames";
                counter = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Count tblGames failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrGames()
        {
            try
            {
                int k = 0;
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT g.gameID, g.gameDate, " +
                                             "p1.playerFirstName + ' ' + p1.playerLastName AS Player1Name, " +
                                             "p2.playerFirstName + ' ' + p2.playerLastName AS Player2Name " +
                                          "FROM (tblGames AS g " +
                                          "LEFT JOIN tblPlayers AS p1 ON g.gamePlayer1ID = p1.playerID) " +
                                          "LEFT JOIN tblPlayers AS p2 ON g.gamePlayer2ID = p2.playerID " +
                                          "ORDER BY g.gameID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    int gameID = dataReader.GetInt32(0);
                    string gameDate = dataReader.GetDateTime(1).ToString("dd/MM/yyyy");
                    string player1Name = dataReader.GetString(2);
                    string player2Name = dataReader.GetString(3);

                    arrGames[k] = $"{gameID}, {gameDate}, {player1Name} נגד {player2Name}";
                    k++;                    
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select tblGames failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrCounts()
        {
            for (int idx = 0; idx < arrGames.Length; idx++)
                CountSubmarines(idx);
        }

        private void CountSubmarines(int idx)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT COUNT(startSubID) " +
                                          "FROM tblStartGames " +
                                          "WHERE startGameID = @gameID";
                datacommand.Parameters.AddWithValue("@gameID", SubmarinesUtils.GetIdFromDetails(arrGames[idx]));
                arrCounts[idx] = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("count submarines failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ShowChart()
        {
            try
            {
                chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -60;

                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoom(1, 10);
                chart1.ChartAreas["ChartArea1"].CursorX.IsUserSelectionEnabled = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoomable = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.Interval = 1;
                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                chart1.Legends.Clear();

                chart1.ChartAreas["ChartArea1"].AxisX.Title = "משחקים";
                chart1.ChartAreas["ChartArea1"].AxisY.Title = "מספר צוללת";

                chart1.Series.Clear();
                chart1.Series.Add("נתונים");


                for (int i = 0; i < arrGames.Length; i++)
                {
                    chart1.Series["נתונים"].Points.AddXY(
                        SubmarinesUtils.StringRightToLeft(arrGames[i]), arrCounts[i]);
                }
            }
            
            catch (Exception ex)
            {
                MessageBox.Show("Show chart failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EditDataGridView()
        {
            try
            {
                for (int i = 0; i < arrGames.Length; i++)
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
                    row.Cells[0].Value = arrGames[i];
                    row.Cells[1].Value = arrCounts[i].ToString();
                    dataGridView1.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit gridview item failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormChartSubmarinesPerGame_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
