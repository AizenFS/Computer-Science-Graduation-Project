﻿namespace Submarines
{
    partial class FormTblPlayers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.playerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerFirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerLastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerCityIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerPasswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerIsManagerDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.playerIsActiveDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.playerPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerPictureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblPlayersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetPlayers = new Submarines.DataSetPlayers();
            this.tblPlayersTableAdapter = new Submarines.DataSetPlayersTableAdapters.tblPlayersTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPlayersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetPlayers)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(124, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1788, 1035);
            this.panel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(800, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "טבלת שחקנים";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(838, 939);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 53);
            this.saveButton.TabIndex = 1;
            this.saveButton.Text = "שמור";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.playerIDDataGridViewTextBoxColumn,
            this.playerFirstNameDataGridViewTextBoxColumn,
            this.playerLastNameDataGridViewTextBoxColumn,
            this.playerAddressDataGridViewTextBoxColumn,
            this.playerCityIDDataGridViewTextBoxColumn,
            this.playerPasswordDataGridViewTextBoxColumn,
            this.playerIsManagerDataGridViewCheckBoxColumn,
            this.playerIsActiveDataGridViewCheckBoxColumn,
            this.playerPhoneDataGridViewTextBoxColumn,
            this.playerMailDataGridViewTextBoxColumn,
            this.playerPictureDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblPlayersBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(49, 295);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(1651, 596);
            this.dataGridView1.TabIndex = 0;
            // 
            // playerIDDataGridViewTextBoxColumn
            // 
            this.playerIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerIDDataGridViewTextBoxColumn.DataPropertyName = "playerID";
            this.playerIDDataGridViewTextBoxColumn.HeaderText = "תז";
            this.playerIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerIDDataGridViewTextBoxColumn.Name = "playerIDDataGridViewTextBoxColumn";
            this.playerIDDataGridViewTextBoxColumn.Width = 61;
            // 
            // playerFirstNameDataGridViewTextBoxColumn
            // 
            this.playerFirstNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerFirstNameDataGridViewTextBoxColumn.DataPropertyName = "playerFirstName";
            this.playerFirstNameDataGridViewTextBoxColumn.HeaderText = "שם פרטי";
            this.playerFirstNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerFirstNameDataGridViewTextBoxColumn.Name = "playerFirstNameDataGridViewTextBoxColumn";
            this.playerFirstNameDataGridViewTextBoxColumn.Width = 101;
            // 
            // playerLastNameDataGridViewTextBoxColumn
            // 
            this.playerLastNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerLastNameDataGridViewTextBoxColumn.DataPropertyName = "playerLastName";
            this.playerLastNameDataGridViewTextBoxColumn.HeaderText = "שם משפחה";
            this.playerLastNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerLastNameDataGridViewTextBoxColumn.Name = "playerLastNameDataGridViewTextBoxColumn";
            this.playerLastNameDataGridViewTextBoxColumn.Width = 117;
            // 
            // playerAddressDataGridViewTextBoxColumn
            // 
            this.playerAddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerAddressDataGridViewTextBoxColumn.DataPropertyName = "playerAddress";
            this.playerAddressDataGridViewTextBoxColumn.HeaderText = "כתובת";
            this.playerAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerAddressDataGridViewTextBoxColumn.Name = "playerAddressDataGridViewTextBoxColumn";
            this.playerAddressDataGridViewTextBoxColumn.Width = 87;
            // 
            // playerCityIDDataGridViewTextBoxColumn
            // 
            this.playerCityIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerCityIDDataGridViewTextBoxColumn.DataPropertyName = "playerCityID";
            this.playerCityIDDataGridViewTextBoxColumn.HeaderText = "קוד עיר";
            this.playerCityIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerCityIDDataGridViewTextBoxColumn.Name = "playerCityIDDataGridViewTextBoxColumn";
            this.playerCityIDDataGridViewTextBoxColumn.Width = 96;
            // 
            // playerPasswordDataGridViewTextBoxColumn
            // 
            this.playerPasswordDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerPasswordDataGridViewTextBoxColumn.DataPropertyName = "playerPassword";
            this.playerPasswordDataGridViewTextBoxColumn.HeaderText = "סיסמה";
            this.playerPasswordDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerPasswordDataGridViewTextBoxColumn.Name = "playerPasswordDataGridViewTextBoxColumn";
            this.playerPasswordDataGridViewTextBoxColumn.Width = 87;
            // 
            // playerIsManagerDataGridViewCheckBoxColumn
            // 
            this.playerIsManagerDataGridViewCheckBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerIsManagerDataGridViewCheckBoxColumn.DataPropertyName = "playerIsManager";
            this.playerIsManagerDataGridViewCheckBoxColumn.HeaderText = "מנהל?";
            this.playerIsManagerDataGridViewCheckBoxColumn.MinimumWidth = 8;
            this.playerIsManagerDataGridViewCheckBoxColumn.Name = "playerIsManagerDataGridViewCheckBoxColumn";
            this.playerIsManagerDataGridViewCheckBoxColumn.Width = 58;
            // 
            // playerIsActiveDataGridViewCheckBoxColumn
            // 
            this.playerIsActiveDataGridViewCheckBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerIsActiveDataGridViewCheckBoxColumn.DataPropertyName = "playerIsActive";
            this.playerIsActiveDataGridViewCheckBoxColumn.HeaderText = "שחקן פעיל?";
            this.playerIsActiveDataGridViewCheckBoxColumn.MinimumWidth = 8;
            this.playerIsActiveDataGridViewCheckBoxColumn.Name = "playerIsActiveDataGridViewCheckBoxColumn";
            this.playerIsActiveDataGridViewCheckBoxColumn.Width = 97;
            // 
            // playerPhoneDataGridViewTextBoxColumn
            // 
            this.playerPhoneDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerPhoneDataGridViewTextBoxColumn.DataPropertyName = "playerPhone";
            this.playerPhoneDataGridViewTextBoxColumn.HeaderText = "טלפון";
            this.playerPhoneDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerPhoneDataGridViewTextBoxColumn.Name = "playerPhoneDataGridViewTextBoxColumn";
            this.playerPhoneDataGridViewTextBoxColumn.Width = 84;
            // 
            // playerMailDataGridViewTextBoxColumn
            // 
            this.playerMailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.playerMailDataGridViewTextBoxColumn.DataPropertyName = "playerMail";
            this.playerMailDataGridViewTextBoxColumn.HeaderText = "אימייל";
            this.playerMailDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerMailDataGridViewTextBoxColumn.Name = "playerMailDataGridViewTextBoxColumn";
            this.playerMailDataGridViewTextBoxColumn.Width = 89;
            // 
            // playerPictureDataGridViewTextBoxColumn
            // 
            this.playerPictureDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.playerPictureDataGridViewTextBoxColumn.DataPropertyName = "playerPicture";
            this.playerPictureDataGridViewTextBoxColumn.HeaderText = "תמונה";
            this.playerPictureDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.playerPictureDataGridViewTextBoxColumn.Name = "playerPictureDataGridViewTextBoxColumn";
            // 
            // tblPlayersBindingSource
            // 
            this.tblPlayersBindingSource.DataMember = "tblPlayers";
            this.tblPlayersBindingSource.DataSource = this.dataSetPlayers;
            // 
            // dataSetPlayers
            // 
            this.dataSetPlayers.DataSetName = "DataSetPlayers";
            this.dataSetPlayers.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblPlayersTableAdapter
            // 
            this.tblPlayersTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(1582, 267);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 25);
            this.label3.TabIndex = 35;
            this.label3.Text = "טבלת שחקנים";
            // 
            // FormTblPlayers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormTblPlayers";
            this.Text = "FormTblPlayers";
            this.Load += new System.EventHandler(this.FormTblPlayers_Load);
            this.SizeChanged += new System.EventHandler(this.FormTblPlayers_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPlayersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetPlayers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSetPlayers dataSetPlayers;
        private System.Windows.Forms.BindingSource tblPlayersBindingSource;
        private DataSetPlayersTableAdapters.tblPlayersTableAdapter tblPlayersTableAdapter;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerFirstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerLastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerCityIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerPasswordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn playerIsManagerDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn playerIsActiveDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerPictureDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label3;
    }
}
