﻿namespace Submarines
{
    partial class FormTblStartGames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.startGameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startOrderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStartGamesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetStartGames = new Submarines.DataSetStartGames();
            this.tblStartGamesTableAdapter = new Submarines.DataSetStartGamesTableAdapters.tblStartGamesTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(551, 165);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(611, 37);
            this.label2.TabIndex = 6;
            this.label2.Text = "טבלת מיקומי צוללות בתחילת המשחק";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1627, 1026);
            this.panel1.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1183, 255);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(286, 25);
            this.label8.TabIndex = 36;
            this.label8.Text = "טבלת מיקומי צוללות בתחילת משחק";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(814, 949);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 53);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "שמור";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.startGameIDDataGridViewTextBoxColumn,
            this.startOrderNumDataGridViewTextBoxColumn,
            this.startSubIDDataGridViewTextBoxColumn,
            this.startRow1DataGridViewTextBoxColumn,
            this.startCol1DataGridViewTextBoxColumn,
            this.startRow2DataGridViewTextBoxColumn,
            this.startCol2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStartGamesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(215, 283);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(1278, 633);
            this.dataGridView1.TabIndex = 0;
            // 
            // startGameIDDataGridViewTextBoxColumn
            // 
            this.startGameIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.startGameIDDataGridViewTextBoxColumn.DataPropertyName = "startGameID";
            this.startGameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.startGameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startGameIDDataGridViewTextBoxColumn.Name = "startGameIDDataGridViewTextBoxColumn";
            this.startGameIDDataGridViewTextBoxColumn.Width = 70;
            // 
            // startOrderNumDataGridViewTextBoxColumn
            // 
            this.startOrderNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.startOrderNumDataGridViewTextBoxColumn.DataPropertyName = "startOrderNum";
            this.startOrderNumDataGridViewTextBoxColumn.HeaderText = "מספר סידורי צוללת";
            this.startOrderNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startOrderNumDataGridViewTextBoxColumn.Name = "startOrderNumDataGridViewTextBoxColumn";
            this.startOrderNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // startSubIDDataGridViewTextBoxColumn
            // 
            this.startSubIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.startSubIDDataGridViewTextBoxColumn.DataPropertyName = "startSubID";
            this.startSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.startSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startSubIDDataGridViewTextBoxColumn.Name = "startSubIDDataGridViewTextBoxColumn";
            this.startSubIDDataGridViewTextBoxColumn.Width = 70;
            // 
            // startRow1DataGridViewTextBoxColumn
            // 
            this.startRow1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.startRow1DataGridViewTextBoxColumn.DataPropertyName = "startRow1";
            this.startRow1DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 1";
            this.startRow1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow1DataGridViewTextBoxColumn.Name = "startRow1DataGridViewTextBoxColumn";
            this.startRow1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol1DataGridViewTextBoxColumn
            // 
            this.startCol1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.startCol1DataGridViewTextBoxColumn.DataPropertyName = "startCol1";
            this.startCol1DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 1";
            this.startCol1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol1DataGridViewTextBoxColumn.Name = "startCol1DataGridViewTextBoxColumn";
            this.startCol1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow2DataGridViewTextBoxColumn
            // 
            this.startRow2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.startRow2DataGridViewTextBoxColumn.DataPropertyName = "startRow2";
            this.startRow2DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 2";
            this.startRow2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow2DataGridViewTextBoxColumn.Name = "startRow2DataGridViewTextBoxColumn";
            this.startRow2DataGridViewTextBoxColumn.Width = 111;
            // 
            // startCol2DataGridViewTextBoxColumn
            // 
            this.startCol2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.startCol2DataGridViewTextBoxColumn.DataPropertyName = "startCol2";
            this.startCol2DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 2";
            this.startCol2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol2DataGridViewTextBoxColumn.Name = "startCol2DataGridViewTextBoxColumn";
            // 
            // tblStartGamesBindingSource
            // 
            this.tblStartGamesBindingSource.DataMember = "tblStartGames";
            this.tblStartGamesBindingSource.DataSource = this.dataSetStartGames;
            // 
            // dataSetStartGames
            // 
            this.dataSetStartGames.DataSetName = "DataSetStartGames";
            this.dataSetStartGames.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStartGamesTableAdapter
            // 
            this.tblStartGamesTableAdapter.ClearBeforeFill = true;
            // 
            // FormTblStartGames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormTblStartGames";
            this.Text = "FormTblStartGames";
            this.Load += new System.EventHandler(this.FormTblStartGames_Load);
            this.SizeChanged += new System.EventHandler(this.FormTblStartGames_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSetStartGames dataSetStartGames;
        private System.Windows.Forms.BindingSource tblStartGamesBindingSource;
        private DataSetStartGamesTableAdapters.tblStartGamesTableAdapter tblStartGamesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn startGameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startOrderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol2DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
