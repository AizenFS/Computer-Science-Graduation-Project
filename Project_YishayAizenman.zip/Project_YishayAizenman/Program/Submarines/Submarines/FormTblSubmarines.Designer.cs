﻿namespace Submarines
{
    partial class FormTblSubmarines
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.subIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subRowsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subColsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subSinkPercentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblSubmarinesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetSubmarines = new Submarines.DataSetSubmarines();
            this.tblSubmarinesTableAdapter = new Submarines.DataSetSubmarinesTableAdapters.tblSubmarinesTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSubmarinesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSubmarines)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(24, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1832, 1035);
            this.panel1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(862, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 37);
            this.label2.TabIndex = 5;
            this.label2.Text = "טבלת צוללות";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(899, 949);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 53);
            this.saveButton.TabIndex = 1;
            this.saveButton.Text = "שמור";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.subIDDataGridViewTextBoxColumn,
            this.subRowsDataGridViewTextBoxColumn,
            this.subColsDataGridViewTextBoxColumn,
            this.subNameDataGridViewTextBoxColumn,
            this.subSinkPercentDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblSubmarinesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(613, 288);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(720, 624);
            this.dataGridView1.TabIndex = 0;
            // 
            // subIDDataGridViewTextBoxColumn
            // 
            this.subIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.subIDDataGridViewTextBoxColumn.DataPropertyName = "subID";
            this.subIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.subIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subIDDataGridViewTextBoxColumn.Name = "subIDDataGridViewTextBoxColumn";
            this.subIDDataGridViewTextBoxColumn.Width = 65;
            // 
            // subRowsDataGridViewTextBoxColumn
            // 
            this.subRowsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.subRowsDataGridViewTextBoxColumn.DataPropertyName = "subRows";
            this.subRowsDataGridViewTextBoxColumn.HeaderText = "מספר שורות";
            this.subRowsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subRowsDataGridViewTextBoxColumn.Name = "subRowsDataGridViewTextBoxColumn";
            this.subRowsDataGridViewTextBoxColumn.Width = 70;
            // 
            // subColsDataGridViewTextBoxColumn
            // 
            this.subColsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.subColsDataGridViewTextBoxColumn.DataPropertyName = "subCols";
            this.subColsDataGridViewTextBoxColumn.HeaderText = "מספר עמודות";
            this.subColsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subColsDataGridViewTextBoxColumn.Name = "subColsDataGridViewTextBoxColumn";
            this.subColsDataGridViewTextBoxColumn.Width = 70;
            // 
            // subNameDataGridViewTextBoxColumn
            // 
            this.subNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.subNameDataGridViewTextBoxColumn.DataPropertyName = "subName";
            this.subNameDataGridViewTextBoxColumn.HeaderText = "שם צוללת";
            this.subNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subNameDataGridViewTextBoxColumn.Name = "subNameDataGridViewTextBoxColumn";
            this.subNameDataGridViewTextBoxColumn.Width = 103;
            // 
            // subSinkPercentDataGridViewTextBoxColumn
            // 
            this.subSinkPercentDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.subSinkPercentDataGridViewTextBoxColumn.DataPropertyName = "subSinkPercent";
            this.subSinkPercentDataGridViewTextBoxColumn.HeaderText = "אחוז משבצות להטבעה";
            this.subSinkPercentDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subSinkPercentDataGridViewTextBoxColumn.Name = "subSinkPercentDataGridViewTextBoxColumn";
            // 
            // tblSubmarinesBindingSource
            // 
            this.tblSubmarinesBindingSource.DataMember = "tblSubmarines";
            this.tblSubmarinesBindingSource.DataSource = this.dataSetSubmarines;
            // 
            // dataSetSubmarines
            // 
            this.dataSetSubmarines.DataSetName = "DataSetSubmarines";
            this.dataSetSubmarines.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblSubmarinesTableAdapter
            // 
            this.tblSubmarinesTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1222, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 25);
            this.label8.TabIndex = 36;
            this.label8.Text = "טבלת צוללות";
            // 
            // FormTblSubmarines
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormTblSubmarines";
            this.Text = "FormTblSubmarines";
            this.Load += new System.EventHandler(this.FormTblSubmarines_Load);
            this.SizeChanged += new System.EventHandler(this.FormTblSubmarines_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSubmarinesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSubmarines)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private DataSetSubmarines dataSetSubmarines;
        private System.Windows.Forms.BindingSource tblSubmarinesBindingSource;
        private DataSetSubmarinesTableAdapters.tblSubmarinesTableAdapter tblSubmarinesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn subIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subRowsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subColsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subSinkPercentDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
