﻿namespace Submarines
{
    partial class FormUpdateStartGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.gameId = new System.Windows.Forms.TextBox();
            this.p2Col = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.startGameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startOrderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startRow2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startCol2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStartGamesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetStartGames = new Submarines.DataSetStartGames();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.p1Col = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.p1Row = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.p2Row = new System.Windows.Forms.TextBox();
            this.submarines = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.subOrder = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tblStartGamesTableAdapter = new Submarines.DataSetStartGamesTableAdapters.tblStartGamesTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(585, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(453, 37);
            this.label11.TabIndex = 34;
            this.label11.Text = "עדכון מיקום צוללות בתחילת משחק";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.buttonPrev);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.buttonLast);
            this.panel1.Controls.Add(this.buttonNext);
            this.panel1.Controls.Add(this.buttonFirst);
            this.panel1.Controls.Add(this.gameId);
            this.panel1.Controls.Add(this.p2Col);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonUpdate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.p1Col);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.p1Row);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.p2Row);
            this.panel1.Controls.Add(this.submarines);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.subOrder);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(61, 14);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 992);
            this.panel1.TabIndex = 35;
            // 
            // buttonPrev
            // 
            this.buttonPrev.Enabled = false;
            this.buttonPrev.Location = new System.Drawing.Point(743, 539);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(93, 51);
            this.buttonPrev.TabIndex = 7;
            this.buttonPrev.Text = "הקודם";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(557, 539);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(92, 51);
            this.buttonLast.TabIndex = 8;
            this.buttonLast.Text = "אחרון";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Enabled = false;
            this.buttonNext.Location = new System.Drawing.Point(928, 539);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(93, 51);
            this.buttonNext.TabIndex = 6;
            this.buttonNext.Text = "הבא";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(1106, 539);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(90, 51);
            this.buttonFirst.TabIndex = 5;
            this.buttonFirst.Text = "ראשון";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // gameId
            // 
            this.gameId.Enabled = false;
            this.gameId.Location = new System.Drawing.Point(928, 300);
            this.gameId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gameId.Name = "gameId";
            this.gameId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gameId.Size = new System.Drawing.Size(148, 26);
            this.gameId.TabIndex = 0;
            // 
            // p2Col
            // 
            this.p2Col.Location = new System.Drawing.Point(599, 456);
            this.p2Col.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p2Col.Name = "p2Col";
            this.p2Col.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p2Col.Size = new System.Drawing.Size(110, 26);
            this.p2Col.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(737, 459);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "עמודה שחקן 2";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.startGameIDDataGridViewTextBoxColumn,
            this.startOrderNumDataGridViewTextBoxColumn,
            this.startSubIDDataGridViewTextBoxColumn,
            this.startRow1DataGridViewTextBoxColumn,
            this.startCol1DataGridViewTextBoxColumn,
            this.startRow2DataGridViewTextBoxColumn,
            this.startCol2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStartGamesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(41, 644);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1643, 312);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // startGameIDDataGridViewTextBoxColumn
            // 
            this.startGameIDDataGridViewTextBoxColumn.DataPropertyName = "startGameID";
            this.startGameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.startGameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startGameIDDataGridViewTextBoxColumn.Name = "startGameIDDataGridViewTextBoxColumn";
            this.startGameIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.startGameIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startOrderNumDataGridViewTextBoxColumn
            // 
            this.startOrderNumDataGridViewTextBoxColumn.DataPropertyName = "startOrderNum";
            this.startOrderNumDataGridViewTextBoxColumn.HeaderText = "מס סידורי צוללת";
            this.startOrderNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startOrderNumDataGridViewTextBoxColumn.Name = "startOrderNumDataGridViewTextBoxColumn";
            this.startOrderNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.startOrderNumDataGridViewTextBoxColumn.Width = 150;
            // 
            // startSubIDDataGridViewTextBoxColumn
            // 
            this.startSubIDDataGridViewTextBoxColumn.DataPropertyName = "startSubID";
            this.startSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.startSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startSubIDDataGridViewTextBoxColumn.Name = "startSubIDDataGridViewTextBoxColumn";
            this.startSubIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.startSubIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow1DataGridViewTextBoxColumn
            // 
            this.startRow1DataGridViewTextBoxColumn.DataPropertyName = "startRow1";
            this.startRow1DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 1";
            this.startRow1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow1DataGridViewTextBoxColumn.Name = "startRow1DataGridViewTextBoxColumn";
            this.startRow1DataGridViewTextBoxColumn.ReadOnly = true;
            this.startRow1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol1DataGridViewTextBoxColumn
            // 
            this.startCol1DataGridViewTextBoxColumn.DataPropertyName = "startCol1";
            this.startCol1DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 1";
            this.startCol1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol1DataGridViewTextBoxColumn.Name = "startCol1DataGridViewTextBoxColumn";
            this.startCol1DataGridViewTextBoxColumn.ReadOnly = true;
            this.startCol1DataGridViewTextBoxColumn.Width = 150;
            // 
            // startRow2DataGridViewTextBoxColumn
            // 
            this.startRow2DataGridViewTextBoxColumn.DataPropertyName = "startRow2";
            this.startRow2DataGridViewTextBoxColumn.HeaderText = "שורה שחקן 2";
            this.startRow2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startRow2DataGridViewTextBoxColumn.Name = "startRow2DataGridViewTextBoxColumn";
            this.startRow2DataGridViewTextBoxColumn.ReadOnly = true;
            this.startRow2DataGridViewTextBoxColumn.Width = 150;
            // 
            // startCol2DataGridViewTextBoxColumn
            // 
            this.startCol2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.startCol2DataGridViewTextBoxColumn.DataPropertyName = "startCol2";
            this.startCol2DataGridViewTextBoxColumn.HeaderText = "עמודה שחקן 2";
            this.startCol2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.startCol2DataGridViewTextBoxColumn.Name = "startCol2DataGridViewTextBoxColumn";
            this.startCol2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblStartGamesBindingSource
            // 
            this.tblStartGamesBindingSource.DataMember = "tblStartGames";
            this.tblStartGamesBindingSource.DataSource = this.dataSetStartGames;
            // 
            // dataSetStartGames
            // 
            this.dataSetStartGames.DataSetName = "DataSetStartGames";
            this.dataSetStartGames.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonUpdate.Location = new System.Drawing.Point(316, 405);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(131, 52);
            this.buttonUpdate.TabIndex = 9;
            this.buttonUpdate.Text = "עדכן";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1092, 303);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "מספר משחק";
            // 
            // p1Col
            // 
            this.p1Col.Location = new System.Drawing.Point(928, 456);
            this.p1Col.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p1Col.Name = "p1Col";
            this.p1Col.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p1Col.Size = new System.Drawing.Size(110, 26);
            this.p1Col.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1070, 405);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "שורה שחקן 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(924, 353);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "צוללת";
            // 
            // p1Row
            // 
            this.p1Row.Location = new System.Drawing.Point(928, 402);
            this.p1Row.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p1Row.Name = "p1Row";
            this.p1Row.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p1Row.Size = new System.Drawing.Size(110, 26);
            this.p1Row.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(746, 405);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "שורה שחקן 2";
            // 
            // p2Row
            // 
            this.p2Row.Location = new System.Drawing.Point(599, 402);
            this.p2Row.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p2Row.Name = "p2Row";
            this.p2Row.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p2Row.Size = new System.Drawing.Size(110, 26);
            this.p2Row.TabIndex = 3;
            // 
            // submarines
            // 
            this.submarines.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.submarines.FormattingEnabled = true;
            this.submarines.Location = new System.Drawing.Point(759, 350);
            this.submarines.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.submarines.Name = "submarines";
            this.submarines.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.submarines.Size = new System.Drawing.Size(133, 28);
            this.submarines.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(755, 303);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "מספר סידורי צוללת";
            // 
            // subOrder
            // 
            this.subOrder.Enabled = false;
            this.subOrder.Location = new System.Drawing.Point(579, 300);
            this.subOrder.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.subOrder.Name = "subOrder";
            this.subOrder.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.subOrder.Size = new System.Drawing.Size(148, 26);
            this.subOrder.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1061, 459);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "עמודה שחקן 1";
            // 
            // tblStartGamesTableAdapter
            // 
            this.tblStartGamesTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1398, 616);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(286, 25);
            this.label8.TabIndex = 36;
            this.label8.Text = "טבלת מיקומי צוללות בתחילת משחק";
            // 
            // FormUpdateStartGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormUpdateStartGame";
            this.Text = "FormUpdateStartGame";
            this.Load += new System.EventHandler(this.FormUpdateStartGame_Load);
            this.SizeChanged += new System.EventHandler(this.FormUpdateStartGame_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStartGamesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetStartGames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox p2Col;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox p1Col;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox p1Row;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox p2Row;
        private System.Windows.Forms.ComboBox submarines;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox subOrder;
        private System.Windows.Forms.Label label7;
        private DataSetStartGames dataSetStartGames;
        private System.Windows.Forms.BindingSource tblStartGamesBindingSource;
        private DataSetStartGamesTableAdapters.tblStartGamesTableAdapter tblStartGamesTableAdapter;
        private System.Windows.Forms.TextBox gameId;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.DataGridViewTextBoxColumn startGameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startOrderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startRow2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startCol2DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
