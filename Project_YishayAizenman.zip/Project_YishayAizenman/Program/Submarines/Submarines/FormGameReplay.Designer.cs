﻿namespace Submarines
{
    partial class FormGameReplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.labelTotalSteps = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.labelCurrStep = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.replaySpeedBar = new System.Windows.Forms.TrackBar();
            this.btnStartStop = new System.Windows.Forms.Button();
            this.labelComputerPlayer = new System.Windows.Forms.Label();
            this.labelCurrPlayer = new System.Windows.Forms.Label();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.labelCurrPlayerNum = new System.Windows.Forms.Label();
            this.rmnSubs2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rmnSubs1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.labelAirStrikeCount2 = new System.Windows.Forms.Label();
            this.labelAirStrikeCount1 = new System.Windows.Forms.Label();
            this.airStrike1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.depthCharge1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.airStrike2 = new System.Windows.Forms.PictureBox();
            this.depthCharge2 = new System.Windows.Forms.PictureBox();
            this.helpButton = new System.Windows.Forms.Button();
            this.NP1 = new Submarines.playerNameAndPic();
            this.label4 = new System.Windows.Forms.Label();
            this.NP2 = new Submarines.playerNameAndPic();
            this.label6 = new System.Windows.Forms.Label();
            this.board2 = new System.Windows.Forms.Panel();
            this.board1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnReveal = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.replaySpeedBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btnReveal);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.labelTotalSteps);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.labelCurrStep);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.replaySpeedBar);
            this.panel1.Controls.Add(this.btnStartStop);
            this.panel1.Controls.Add(this.labelComputerPlayer);
            this.panel1.Controls.Add(this.labelCurrPlayer);
            this.panel1.Controls.Add(this.btnLast);
            this.panel1.Controls.Add(this.btnReset);
            this.panel1.Controls.Add(this.btnNext);
            this.panel1.Controls.Add(this.btnPrev);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.labelCurrPlayerNum);
            this.panel1.Controls.Add(this.rmnSubs2);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.rmnSubs1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.labelAirStrikeCount2);
            this.panel1.Controls.Add(this.labelAirStrikeCount1);
            this.panel1.Controls.Add(this.airStrike1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.depthCharge1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.airStrike2);
            this.panel1.Controls.Add(this.depthCharge2);
            this.panel1.Controls.Add(this.helpButton);
            this.panel1.Controls.Add(this.NP1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.NP2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.board2);
            this.panel1.Controls.Add(this.board1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1900, 1026);
            this.panel1.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(1299, 72);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label14.Size = new System.Drawing.Size(111, 22);
            this.label14.TabIndex = 115;
            this.label14.Text = "מהירות הרצה";
            // 
            // labelTotalSteps
            // 
            this.labelTotalSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalSteps.Location = new System.Drawing.Point(790, 174);
            this.labelTotalSteps.Margin = new System.Windows.Forms.Padding(0);
            this.labelTotalSteps.Name = "labelTotalSteps";
            this.labelTotalSteps.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelTotalSteps.Size = new System.Drawing.Size(58, 31);
            this.labelTotalSteps.TabIndex = 108;
            this.labelTotalSteps.Text = "111";
            this.labelTotalSteps.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(849, 174);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label15.Size = new System.Drawing.Size(65, 29);
            this.label15.TabIndex = 109;
            this.label15.Text = "מתוך";
            // 
            // labelCurrStep
            // 
            this.labelCurrStep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrStep.Location = new System.Drawing.Point(920, 174);
            this.labelCurrStep.Margin = new System.Windows.Forms.Padding(0);
            this.labelCurrStep.Name = "labelCurrStep";
            this.labelCurrStep.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelCurrStep.Size = new System.Drawing.Size(58, 31);
            this.labelCurrStep.TabIndex = 107;
            this.labelCurrStep.Text = "111";
            this.labelCurrStep.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(978, 174);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(148, 29);
            this.label10.TabIndex = 99;
            this.label10.Text = "הצעד הנוכחי:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(1414, 178);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label13.Size = new System.Drawing.Size(47, 22);
            this.label13.TabIndex = 114;
            this.label13.Text = "מהיר";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1250, 178);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label12.Size = new System.Drawing.Size(44, 22);
            this.label12.TabIndex = 113;
            this.label12.Text = "איטי";
            // 
            // replaySpeedBar
            // 
            this.replaySpeedBar.AutoSize = false;
            this.replaySpeedBar.LargeChange = 0;
            this.replaySpeedBar.Location = new System.Drawing.Point(1250, 109);
            this.replaySpeedBar.Maximum = 2;
            this.replaySpeedBar.Name = "replaySpeedBar";
            this.replaySpeedBar.Size = new System.Drawing.Size(207, 65);
            this.replaySpeedBar.TabIndex = 112;
            this.replaySpeedBar.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.replaySpeedBar.ValueChanged += new System.EventHandler(this.replaySpeedBar_ValueChanged);
            // 
            // btnStartStop
            // 
            this.btnStartStop.BackColor = System.Drawing.SystemColors.Control;
            this.btnStartStop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStartStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.btnStartStop.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnStartStop.Location = new System.Drawing.Point(1167, 109);
            this.btnStartStop.Name = "btnStartStop";
            this.btnStartStop.Size = new System.Drawing.Size(65, 65);
            this.btnStartStop.TabIndex = 111;
            this.btnStartStop.UseVisualStyleBackColor = false;
            this.btnStartStop.Click += new System.EventHandler(this.btnStartStop_Click);
            // 
            // labelComputerPlayer
            // 
            this.labelComputerPlayer.AutoSize = true;
            this.labelComputerPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelComputerPlayer.Location = new System.Drawing.Point(1683, 248);
            this.labelComputerPlayer.Name = "labelComputerPlayer";
            this.labelComputerPlayer.Size = new System.Drawing.Size(163, 37);
            this.labelComputerPlayer.TabIndex = 110;
            this.labelComputerPlayer.Text = "שחקן מחשב";
            // 
            // labelCurrPlayer
            // 
            this.labelCurrPlayer.AutoSize = true;
            this.labelCurrPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.labelCurrPlayer.Location = new System.Drawing.Point(898, 214);
            this.labelCurrPlayer.Name = "labelCurrPlayer";
            this.labelCurrPlayer.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelCurrPlayer.Size = new System.Drawing.Size(136, 29);
            this.labelCurrPlayer.TabIndex = 106;
            this.labelCurrPlayer.Text = "שחקן הצעד:";
            // 
            // btnLast
            // 
            this.btnLast.BackColor = System.Drawing.SystemColors.Control;
            this.btnLast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLast.Location = new System.Drawing.Point(356, 108);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(98, 65);
            this.btnLast.TabIndex = 105;
            this.btnLast.Text = "האחרון";
            this.btnLast.UseVisualStyleBackColor = false;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.SystemColors.Control;
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(1480, 109);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(102, 65);
            this.btnReset.TabIndex = 104;
            this.btnReset.Text = "איפוס לוחות";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.SystemColors.Control;
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.Location = new System.Drawing.Point(490, 108);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(98, 65);
            this.btnNext.TabIndex = 103;
            this.btnNext.Text = "הבא";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.BackColor = System.Drawing.SystemColors.Control;
            this.btnPrev.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrev.Location = new System.Drawing.Point(626, 108);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(98, 65);
            this.btnPrev.TabIndex = 102;
            this.btnPrev.Text = "הקודם";
            this.btnPrev.UseVisualStyleBackColor = false;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(867, 117);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(168, 37);
            this.label11.TabIndex = 101;
            this.label11.Text = "צפייה חוזרת";
            // 
            // labelCurrPlayerNum
            // 
            this.labelCurrPlayerNum.AutoSize = true;
            this.labelCurrPlayerNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrPlayerNum.Location = new System.Drawing.Point(878, 214);
            this.labelCurrPlayerNum.Name = "labelCurrPlayerNum";
            this.labelCurrPlayerNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelCurrPlayerNum.Size = new System.Drawing.Size(27, 29);
            this.labelCurrPlayerNum.TabIndex = 100;
            this.labelCurrPlayerNum.Text = "0";
            this.labelCurrPlayerNum.TextChanged += new System.EventHandler(this.labelCurrPlayerNum_TextChanged);
            // 
            // rmnSubs2
            // 
            this.rmnSubs2.Enabled = false;
            this.rmnSubs2.Location = new System.Drawing.Point(50, 946);
            this.rmnSubs2.Name = "rmnSubs2";
            this.rmnSubs2.Size = new System.Drawing.Size(49, 26);
            this.rmnSubs2.TabIndex = 98;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(106, 932);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(145, 40);
            this.label9.TabIndex = 97;
            this.label9.Text = "מספר צוללות אויב\r\nשנותרו:";
            // 
            // rmnSubs1
            // 
            this.rmnSubs1.Enabled = false;
            this.rmnSubs1.Location = new System.Drawing.Point(1635, 946);
            this.rmnSubs1.Name = "rmnSubs1";
            this.rmnSubs1.Size = new System.Drawing.Size(49, 26);
            this.rmnSubs1.TabIndex = 96;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1706, 932);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(145, 40);
            this.label8.TabIndex = 95;
            this.label8.Text = "מספר צוללות אויב\r\nשנותרו:";
            // 
            // labelAirStrikeCount2
            // 
            this.labelAirStrikeCount2.AutoSize = true;
            this.labelAirStrikeCount2.Enabled = false;
            this.labelAirStrikeCount2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.labelAirStrikeCount2.Location = new System.Drawing.Point(236, 865);
            this.labelAirStrikeCount2.Name = "labelAirStrikeCount2";
            this.labelAirStrikeCount2.Size = new System.Drawing.Size(27, 29);
            this.labelAirStrikeCount2.TabIndex = 94;
            this.labelAirStrikeCount2.Text = "1";
            this.labelAirStrikeCount2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelAirStrikeCount1
            // 
            this.labelAirStrikeCount1.AutoSize = true;
            this.labelAirStrikeCount1.Enabled = false;
            this.labelAirStrikeCount1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAirStrikeCount1.Location = new System.Drawing.Point(1630, 865);
            this.labelAirStrikeCount1.Name = "labelAirStrikeCount1";
            this.labelAirStrikeCount1.Size = new System.Drawing.Size(27, 29);
            this.labelAirStrikeCount1.TabIndex = 93;
            this.labelAirStrikeCount1.Text = "1";
            this.labelAirStrikeCount1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // airStrike1
            // 
            this.airStrike1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.airStrike1.Enabled = false;
            this.airStrike1.Location = new System.Drawing.Point(1624, 714);
            this.airStrike1.Name = "airStrike1";
            this.airStrike1.Size = new System.Drawing.Size(148, 184);
            this.airStrike1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.airStrike1.TabIndex = 90;
            this.airStrike1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1654, 658);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(101, 40);
            this.label5.TabIndex = 91;
            this.label5.Text = "הפגזה אווירית\r\nפגיעה: 3 על 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1785, 658);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(101, 40);
            this.label7.TabIndex = 88;
            this.label7.Text = "פצצת עומק\r\nפגיעה: 1 על 1";
            // 
            // depthCharge1
            // 
            this.depthCharge1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.depthCharge1.Enabled = false;
            this.depthCharge1.Image = global::Submarines.Properties.Resources.DepthChargeTurned;
            this.depthCharge1.Location = new System.Drawing.Point(1788, 714);
            this.depthCharge1.Name = "depthCharge1";
            this.depthCharge1.Size = new System.Drawing.Size(94, 184);
            this.depthCharge1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.depthCharge1.TabIndex = 89;
            this.depthCharge1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(152, 658);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(101, 40);
            this.label3.TabIndex = 85;
            this.label3.Text = "הפגזה אווירית\r\nפגיעה: 3 על 3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 658);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(101, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "פצצת עומק\r\nפגיעה: 1 על 1";
            // 
            // airStrike2
            // 
            this.airStrike2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.airStrike2.Enabled = false;
            this.airStrike2.Image = global::Submarines.Properties.Resources.AirStrike;
            this.airStrike2.Location = new System.Drawing.Point(122, 714);
            this.airStrike2.Name = "airStrike2";
            this.airStrike2.Size = new System.Drawing.Size(148, 184);
            this.airStrike2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.airStrike2.TabIndex = 84;
            this.airStrike2.TabStop = false;
            // 
            // depthCharge2
            // 
            this.depthCharge2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.depthCharge2.Enabled = false;
            this.depthCharge2.Image = global::Submarines.Properties.Resources.DepthChargeTurned;
            this.depthCharge2.Location = new System.Drawing.Point(12, 714);
            this.depthCharge2.Name = "depthCharge2";
            this.depthCharge2.Size = new System.Drawing.Size(94, 184);
            this.depthCharge2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.depthCharge2.TabIndex = 83;
            this.depthCharge2.TabStop = false;
            // 
            // helpButton
            // 
            this.helpButton.BackColor = System.Drawing.SystemColors.Control;
            this.helpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(1785, 37);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(81, 34);
            this.helpButton.TabIndex = 82;
            this.helpButton.Text = "עזרה";
            this.helpButton.UseVisualStyleBackColor = false;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // NP1
            // 
            this.NP1.firstName = "";
            this.NP1.id = "";
            this.NP1.lastName = "";
            this.NP1.Location = new System.Drawing.Point(1652, 308);
            this.NP1.Margin = new System.Windows.Forms.Padding(2);
            this.NP1.Name = "NP1";
            this.NP1.picLocation = null;
            this.NP1.Size = new System.Drawing.Size(210, 331);
            this.NP1.TabIndex = 76;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(554, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 37);
            this.label4.TabIndex = 78;
            this.label4.Text = "שחקן 2";
            // 
            // NP2
            // 
            this.NP2.firstName = "";
            this.NP2.id = "";
            this.NP2.lastName = "";
            this.NP2.Location = new System.Drawing.Point(50, 308);
            this.NP2.Margin = new System.Windows.Forms.Padding(2);
            this.NP2.Name = "NP2";
            this.NP2.picLocation = null;
            this.NP2.Size = new System.Drawing.Size(210, 331);
            this.NP2.TabIndex = 77;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1222, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 37);
            this.label6.TabIndex = 73;
            this.label6.Text = "שחקן 1";
            // 
            // board2
            // 
            this.board2.BackColor = System.Drawing.Color.Transparent;
            this.board2.BackgroundImage = global::Submarines.Properties.Resources.GameBackround;
            this.board2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.board2.Location = new System.Drawing.Point(296, 302);
            this.board2.Name = "board2";
            this.board2.Size = new System.Drawing.Size(656, 694);
            this.board2.TabIndex = 67;
            // 
            // board1
            // 
            this.board1.BackgroundImage = global::Submarines.Properties.Resources.GameBackround;
            this.board1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.board1.Location = new System.Drawing.Point(958, 302);
            this.board1.Name = "board1";
            this.board1.Size = new System.Drawing.Size(656, 694);
            this.board1.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(812, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 52);
            this.label2.TabIndex = 65;
            this.label2.Text = "משחק צוללות";
            // 
            // btnReveal
            // 
            this.btnReveal.BackColor = System.Drawing.Color.Tomato;
            this.btnReveal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.btnReveal.Location = new System.Drawing.Point(858, 246);
            this.btnReveal.Name = "btnReveal";
            this.btnReveal.Size = new System.Drawing.Size(215, 43);
            this.btnReveal.TabIndex = 116;
            this.btnReveal.Text = "חשוף את כל הצוללות";
            this.btnReveal.UseVisualStyleBackColor = false;
            this.btnReveal.Visible = false;
            this.btnReveal.VisibleChanged += new System.EventHandler(this.btnReveal_VisibleChanged);
            this.btnReveal.Click += new System.EventHandler(this.buttonReveal_Click);
            // 
            // FormGameReplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormGameReplay";
            this.Text = "FormGameReplay";
            this.Load += new System.EventHandler(this.FormGameReplay_Load);
            this.SizeChanged += new System.EventHandler(this.FormGameReplay_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.replaySpeedBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelCurrPlayerNum;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox rmnSubs2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox rmnSubs1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelAirStrikeCount2;
        private System.Windows.Forms.Label labelAirStrikeCount1;
        private System.Windows.Forms.PictureBox airStrike1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox depthCharge1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox airStrike2;
        private System.Windows.Forms.PictureBox depthCharge2;
        private System.Windows.Forms.Button helpButton;
        private playerNameAndPic NP1;
        private System.Windows.Forms.Label label4;
        private playerNameAndPic NP2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel board2;
        private System.Windows.Forms.Panel board1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label labelCurrPlayer;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label labelTotalSteps;
        private System.Windows.Forms.Label labelCurrStep;
        private System.Windows.Forms.Label labelComputerPlayer;
        private System.Windows.Forms.Button btnStartStop;
        private System.Windows.Forms.TrackBar replaySpeedBar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnReveal;
    }
}
