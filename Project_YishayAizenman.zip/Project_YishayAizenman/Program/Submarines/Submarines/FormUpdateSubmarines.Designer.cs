﻿namespace Submarines
{
    partial class FormUpdateSubmarines
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.subId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.sinkPercent = new System.Windows.Forms.TextBox();
            this.subName = new System.Windows.Forms.TextBox();
            this.cols = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.subIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subRowsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subColsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subSinkPercentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblSubmarinesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetSubmarines = new Submarines.DataSetSubmarines();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.rows = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tblSubmarinesTableAdapter = new Submarines.DataSetSubmarinesTableAdapters.tblSubmarinesTableAdapter();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSubmarinesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSubmarines)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.subId);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.buttonPrev);
            this.panel1.Controls.Add(this.buttonLast);
            this.panel1.Controls.Add(this.buttonNext);
            this.panel1.Controls.Add(this.buttonFirst);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.sinkPercent);
            this.panel1.Controls.Add(this.subName);
            this.panel1.Controls.Add(this.cols);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonUpdate);
            this.panel1.Controls.Add(this.rows);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(61, 14);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 994);
            this.panel1.TabIndex = 34;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(863, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 37);
            this.label11.TabIndex = 35;
            this.label11.Text = "עדכון צוללת";
            // 
            // subId
            // 
            this.subId.Enabled = false;
            this.subId.Location = new System.Drawing.Point(839, 309);
            this.subId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.subId.Name = "subId";
            this.subId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.subId.Size = new System.Drawing.Size(110, 26);
            this.subId.TabIndex = 65;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1005, 312);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 64;
            this.label3.Text = "קוד צוללת";
            // 
            // buttonPrev
            // 
            this.buttonPrev.Enabled = false;
            this.buttonPrev.Location = new System.Drawing.Point(783, 511);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(93, 51);
            this.buttonPrev.TabIndex = 6;
            this.buttonPrev.Text = "הקודם";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(570, 511);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(92, 51);
            this.buttonLast.TabIndex = 7;
            this.buttonLast.Text = "אחרון";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Enabled = false;
            this.buttonNext.Location = new System.Drawing.Point(1042, 511);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(93, 51);
            this.buttonNext.TabIndex = 5;
            this.buttonNext.Text = "הבא";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(1289, 511);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(90, 51);
            this.buttonFirst.TabIndex = 4;
            this.buttonFirst.Text = "ראשון";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(788, 373);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "מספר שורות";
            // 
            // sinkPercent
            // 
            this.sinkPercent.Location = new System.Drawing.Point(1042, 437);
            this.sinkPercent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sinkPercent.Name = "sinkPercent";
            this.sinkPercent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sinkPercent.Size = new System.Drawing.Size(110, 26);
            this.sinkPercent.TabIndex = 1;
            // 
            // subName
            // 
            this.subName.Location = new System.Drawing.Point(1042, 370);
            this.subName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.subName.Name = "subName";
            this.subName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.subName.Size = new System.Drawing.Size(110, 26);
            this.subName.TabIndex = 0;
            // 
            // cols
            // 
            this.cols.Location = new System.Drawing.Point(636, 437);
            this.cols.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cols.Name = "cols";
            this.cols.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cols.Size = new System.Drawing.Size(110, 26);
            this.cols.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(779, 440);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "מספר עמודות";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.subIDDataGridViewTextBoxColumn,
            this.subRowsDataGridViewTextBoxColumn,
            this.subColsDataGridViewTextBoxColumn,
            this.subNameDataGridViewTextBoxColumn,
            this.subSinkPercentDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblSubmarinesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(570, 633);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(809, 312);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // subIDDataGridViewTextBoxColumn
            // 
            this.subIDDataGridViewTextBoxColumn.DataPropertyName = "subID";
            this.subIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.subIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subIDDataGridViewTextBoxColumn.Name = "subIDDataGridViewTextBoxColumn";
            this.subIDDataGridViewTextBoxColumn.Width = 106;
            // 
            // subRowsDataGridViewTextBoxColumn
            // 
            this.subRowsDataGridViewTextBoxColumn.DataPropertyName = "subRows";
            this.subRowsDataGridViewTextBoxColumn.HeaderText = "מספר שורות";
            this.subRowsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subRowsDataGridViewTextBoxColumn.Name = "subRowsDataGridViewTextBoxColumn";
            this.subRowsDataGridViewTextBoxColumn.Width = 116;
            // 
            // subColsDataGridViewTextBoxColumn
            // 
            this.subColsDataGridViewTextBoxColumn.DataPropertyName = "subCols";
            this.subColsDataGridViewTextBoxColumn.HeaderText = "מספר עמודות";
            this.subColsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subColsDataGridViewTextBoxColumn.Name = "subColsDataGridViewTextBoxColumn";
            this.subColsDataGridViewTextBoxColumn.Width = 124;
            // 
            // subNameDataGridViewTextBoxColumn
            // 
            this.subNameDataGridViewTextBoxColumn.DataPropertyName = "subName";
            this.subNameDataGridViewTextBoxColumn.HeaderText = "שם צוללת";
            this.subNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subNameDataGridViewTextBoxColumn.Name = "subNameDataGridViewTextBoxColumn";
            this.subNameDataGridViewTextBoxColumn.Width = 103;
            // 
            // subSinkPercentDataGridViewTextBoxColumn
            // 
            this.subSinkPercentDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.subSinkPercentDataGridViewTextBoxColumn.DataPropertyName = "subSinkPercent";
            this.subSinkPercentDataGridViewTextBoxColumn.HeaderText = "אחוז משבצות להטבעה";
            this.subSinkPercentDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.subSinkPercentDataGridViewTextBoxColumn.Name = "subSinkPercentDataGridViewTextBoxColumn";
            // 
            // tblSubmarinesBindingSource
            // 
            this.tblSubmarinesBindingSource.DataMember = "tblSubmarines";
            this.tblSubmarinesBindingSource.DataSource = this.dataSetSubmarines;
            // 
            // dataSetSubmarines
            // 
            this.dataSetSubmarines.DataSetName = "DataSetSubmarines";
            this.dataSetSubmarines.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonUpdate.Location = new System.Drawing.Point(297, 386);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(188, 63);
            this.buttonUpdate.TabIndex = 8;
            this.buttonUpdate.Text = "עדכן";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // rows
            // 
            this.rows.Location = new System.Drawing.Point(636, 370);
            this.rows.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rows.Name = "rows";
            this.rows.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rows.Size = new System.Drawing.Size(110, 26);
            this.rows.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1274, 376);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "שם צוללת";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1191, 440);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "אחוז משבצות להטבעה";
            // 
            // tblSubmarinesTableAdapter
            // 
            this.tblSubmarinesTableAdapter.ClearBeforeFill = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1268, 605);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 25);
            this.label8.TabIndex = 66;
            this.label8.Text = "טבלת צוללות";
            // 
            // FormUpdateSubmarines
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormUpdateSubmarines";
            this.Text = "FormUpdateSubmarines";
            this.Load += new System.EventHandler(this.FormUpdateSubmarines_Load);
            this.SizeChanged += new System.EventHandler(this.FormUpdateSubmarines_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSubmarinesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSubmarines)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sinkPercent;
        private System.Windows.Forms.TextBox subName;
        private System.Windows.Forms.TextBox cols;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.TextBox rows;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private DataSetSubmarines dataSetSubmarines;
        private System.Windows.Forms.BindingSource tblSubmarinesBindingSource;
        private DataSetSubmarinesTableAdapters.tblSubmarinesTableAdapter tblSubmarinesTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonFirst;
        private System.Windows.Forms.TextBox subId;
        private System.Windows.Forms.DataGridViewTextBoxColumn subIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subRowsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subColsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subSinkPercentDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
