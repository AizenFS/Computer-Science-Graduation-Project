﻿namespace Submarines
{
    partial class FormTblSteps
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.stepGameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepOrderNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepPlayerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepRowDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stepColDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStepsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetSteps = new Submarines.DataSetSteps();
            this.tblStepsTableAdapter = new Submarines.DataSetStepsTableAdapters.tblStepsTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStepsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSteps)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(803, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 37);
            this.label2.TabIndex = 6;
            this.label2.Text = "טבלת מהלכים";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(38, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1818, 1035);
            this.panel1.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1104, 278);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 25);
            this.label8.TabIndex = 36;
            this.label8.Text = "טבלת מהלכים";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(831, 955);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 53);
            this.saveButton.TabIndex = 1;
            this.saveButton.Text = "שמור";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stepGameIDDataGridViewTextBoxColumn,
            this.stepOrderNumDataGridViewTextBoxColumn,
            this.stepPlayerDataGridViewTextBoxColumn,
            this.stepRowDataGridViewTextBoxColumn,
            this.stepColDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStepsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(551, 306);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(668, 611);
            this.dataGridView1.TabIndex = 0;
            // 
            // stepGameIDDataGridViewTextBoxColumn
            // 
            this.stepGameIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.stepGameIDDataGridViewTextBoxColumn.DataPropertyName = "stepGameID";
            this.stepGameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.stepGameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepGameIDDataGridViewTextBoxColumn.Name = "stepGameIDDataGridViewTextBoxColumn";
            this.stepGameIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // stepOrderNumDataGridViewTextBoxColumn
            // 
            this.stepOrderNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.stepOrderNumDataGridViewTextBoxColumn.DataPropertyName = "stepOrderNum";
            this.stepOrderNumDataGridViewTextBoxColumn.HeaderText = "מספר מהלך";
            this.stepOrderNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepOrderNumDataGridViewTextBoxColumn.Name = "stepOrderNumDataGridViewTextBoxColumn";
            this.stepOrderNumDataGridViewTextBoxColumn.Width = 122;
            // 
            // stepPlayerDataGridViewTextBoxColumn
            // 
            this.stepPlayerDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.stepPlayerDataGridViewTextBoxColumn.DataPropertyName = "stepPlayer";
            this.stepPlayerDataGridViewTextBoxColumn.HeaderText = "שחקן";
            this.stepPlayerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepPlayerDataGridViewTextBoxColumn.Name = "stepPlayerDataGridViewTextBoxColumn";
            this.stepPlayerDataGridViewTextBoxColumn.Width = 82;
            // 
            // stepRowDataGridViewTextBoxColumn
            // 
            this.stepRowDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.stepRowDataGridViewTextBoxColumn.DataPropertyName = "stepRow";
            this.stepRowDataGridViewTextBoxColumn.HeaderText = "שורה";
            this.stepRowDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepRowDataGridViewTextBoxColumn.Name = "stepRowDataGridViewTextBoxColumn";
            this.stepRowDataGridViewTextBoxColumn.Width = 79;
            // 
            // stepColDataGridViewTextBoxColumn
            // 
            this.stepColDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.stepColDataGridViewTextBoxColumn.DataPropertyName = "stepCol";
            this.stepColDataGridViewTextBoxColumn.HeaderText = "עמודה";
            this.stepColDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.stepColDataGridViewTextBoxColumn.Name = "stepColDataGridViewTextBoxColumn";
            // 
            // tblStepsBindingSource
            // 
            this.tblStepsBindingSource.DataMember = "tblSteps";
            this.tblStepsBindingSource.DataSource = this.dataSetSteps;
            // 
            // dataSetSteps
            // 
            this.dataSetSteps.DataSetName = "DataSetSteps";
            this.dataSetSteps.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStepsTableAdapter
            // 
            this.tblStepsTableAdapter.ClearBeforeFill = true;
            // 
            // FormTblSteps
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormTblSteps";
            this.Text = "FormTblSteps";
            this.Load += new System.EventHandler(this.FormTblSteps_Load);
            this.SizeChanged += new System.EventHandler(this.FormTblSteps_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStepsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetSteps)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSetSteps dataSetSteps;
        private System.Windows.Forms.BindingSource tblStepsBindingSource;
        private DataSetStepsTableAdapters.tblStepsTableAdapter tblStepsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepGameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepOrderNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepPlayerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepRowDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stepColDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
    }
}
