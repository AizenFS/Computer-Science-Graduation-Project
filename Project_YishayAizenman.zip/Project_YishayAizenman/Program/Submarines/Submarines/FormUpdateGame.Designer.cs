﻿namespace Submarines
{
    partial class FormUpdateGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.gameId = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonPrev = new System.Windows.Forms.Button();
            this.buttonLast = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonFirst = new System.Windows.Forms.Button();
            this.comboId2 = new System.Windows.Forms.ComboBox();
            this.comboId1 = new System.Windows.Forms.ComboBox();
            this.colorB2 = new System.Windows.Forms.Button();
            this.colorB1 = new System.Windows.Forms.Button();
            this.col2 = new System.Windows.Forms.TextBox();
            this.col1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.stepsNumber = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.gameMinutes = new System.Windows.Forms.TextBox();
            this.gameTime = new System.Windows.Forms.DateTimePicker();
            this.gameDate = new System.Windows.Forms.DateTimePicker();
            this.p2Type = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.colsBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameBoardRowsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameBoardColsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gamePlayer1IDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameType1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gamePlayer2IDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameType2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameMinutesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameMovesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameColor1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameColor2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblGamesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetGames = new Submarines.DataSetGames();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.rowsBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.p1Type = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tblGamesTableAdapter = new Submarines.DataSetGamesTableAdapters.tblGamesTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblGamesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetGames)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.gameId);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.buttonPrev);
            this.panel1.Controls.Add(this.buttonLast);
            this.panel1.Controls.Add(this.buttonNext);
            this.panel1.Controls.Add(this.buttonFirst);
            this.panel1.Controls.Add(this.comboId2);
            this.panel1.Controls.Add(this.comboId1);
            this.panel1.Controls.Add(this.colorB2);
            this.panel1.Controls.Add(this.colorB1);
            this.panel1.Controls.Add(this.col2);
            this.panel1.Controls.Add(this.col1);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.stepsNumber);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.gameMinutes);
            this.panel1.Controls.Add(this.gameTime);
            this.panel1.Controls.Add(this.gameDate);
            this.panel1.Controls.Add(this.p2Type);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.colsBox);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.buttonUpdate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.rowsBox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.p1Type);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(63, 14);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 948);
            this.panel1.TabIndex = 32;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label16.Location = new System.Drawing.Point(1590, 569);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(122, 25);
            this.label16.TabIndex = 54;
            this.label16.Text = "טבלת משחקים";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(789, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(166, 37);
            this.label11.TabIndex = 33;
            this.label11.Text = "עדכון משחק";
            // 
            // gameId
            // 
            this.gameId.Enabled = false;
            this.gameId.Location = new System.Drawing.Point(1478, 340);
            this.gameId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gameId.Name = "gameId";
            this.gameId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gameId.Size = new System.Drawing.Size(106, 26);
            this.gameId.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1610, 343);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 20);
            this.label10.TabIndex = 52;
            this.label10.Text = "מספר משחק";
            // 
            // buttonPrev
            // 
            this.buttonPrev.Enabled = false;
            this.buttonPrev.Location = new System.Drawing.Point(841, 501);
            this.buttonPrev.Name = "buttonPrev";
            this.buttonPrev.Size = new System.Drawing.Size(93, 51);
            this.buttonPrev.TabIndex = 17;
            this.buttonPrev.Text = "הקודם";
            this.buttonPrev.UseVisualStyleBackColor = true;
            this.buttonPrev.Click += new System.EventHandler(this.buttonPrev_Click);
            // 
            // buttonLast
            // 
            this.buttonLast.Location = new System.Drawing.Point(655, 501);
            this.buttonLast.Name = "buttonLast";
            this.buttonLast.Size = new System.Drawing.Size(92, 51);
            this.buttonLast.TabIndex = 18;
            this.buttonLast.Text = "אחרון";
            this.buttonLast.UseVisualStyleBackColor = true;
            this.buttonLast.Click += new System.EventHandler(this.buttonLast_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.Enabled = false;
            this.buttonNext.Location = new System.Drawing.Point(1026, 501);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(93, 51);
            this.buttonNext.TabIndex = 16;
            this.buttonNext.Text = "הבא";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonFirst
            // 
            this.buttonFirst.Location = new System.Drawing.Point(1204, 501);
            this.buttonFirst.Name = "buttonFirst";
            this.buttonFirst.Size = new System.Drawing.Size(90, 51);
            this.buttonFirst.TabIndex = 15;
            this.buttonFirst.Text = "ראשון";
            this.buttonFirst.UseVisualStyleBackColor = true;
            this.buttonFirst.Click += new System.EventHandler(this.buttonFirst_Click);
            // 
            // comboId2
            // 
            this.comboId2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboId2.FormattingEnabled = true;
            this.comboId2.Location = new System.Drawing.Point(420, 330);
            this.comboId2.Name = "comboId2";
            this.comboId2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboId2.Size = new System.Drawing.Size(205, 28);
            this.comboId2.TabIndex = 3;
            // 
            // comboId1
            // 
            this.comboId1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboId1.FormattingEnabled = true;
            this.comboId1.Location = new System.Drawing.Point(796, 335);
            this.comboId1.Name = "comboId1";
            this.comboId1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboId1.Size = new System.Drawing.Size(205, 28);
            this.comboId1.TabIndex = 2;
            // 
            // colorB2
            // 
            this.colorB2.Location = new System.Drawing.Point(420, 438);
            this.colorB2.Name = "colorB2";
            this.colorB2.Size = new System.Drawing.Size(35, 35);
            this.colorB2.TabIndex = 13;
            this.colorB2.Text = "...";
            this.colorB2.UseVisualStyleBackColor = true;
            this.colorB2.Click += new System.EventHandler(this.colorB2_Click);
            // 
            // colorB1
            // 
            this.colorB1.Location = new System.Drawing.Point(796, 439);
            this.colorB1.Name = "colorB1";
            this.colorB1.Size = new System.Drawing.Size(35, 35);
            this.colorB1.TabIndex = 12;
            this.colorB1.Text = "...";
            this.colorB1.UseVisualStyleBackColor = true;
            this.colorB1.Click += new System.EventHandler(this.colorB1_Click);
            // 
            // col2
            // 
            this.col2.Location = new System.Drawing.Point(456, 442);
            this.col2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.col2.Name = "col2";
            this.col2.Size = new System.Drawing.Size(169, 26);
            this.col2.TabIndex = 43;
            this.col2.TabStop = false;
            this.col2.Text = "< color selector";
            // 
            // col1
            // 
            this.col1.Location = new System.Drawing.Point(833, 442);
            this.col1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.col1.Name = "col1";
            this.col1.Size = new System.Drawing.Size(169, 26);
            this.col1.TabIndex = 66;
            this.col1.TabStop = false;
            this.col1.Text = "< color selector";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1023, 442);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 20);
            this.label15.TabIndex = 41;
            this.label15.Text = "צבע שחקן 1";
            // 
            // stepsNumber
            // 
            this.stepsNumber.Location = new System.Drawing.Point(1204, 440);
            this.stepsNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.stepsNumber.Name = "stepsNumber";
            this.stepsNumber.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.stepsNumber.Size = new System.Drawing.Size(106, 26);
            this.stepsNumber.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1336, 443);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 20);
            this.label14.TabIndex = 39;
            this.label14.Text = "מספר מהלכים";
            // 
            // gameMinutes
            // 
            this.gameMinutes.Location = new System.Drawing.Point(1478, 498);
            this.gameMinutes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gameMinutes.Name = "gameMinutes";
            this.gameMinutes.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gameMinutes.Size = new System.Drawing.Size(106, 26);
            this.gameMinutes.TabIndex = 14;
            // 
            // gameTime
            // 
            this.gameTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.gameTime.Location = new System.Drawing.Point(420, 386);
            this.gameTime.Name = "gameTime";
            this.gameTime.ShowUpDown = true;
            this.gameTime.Size = new System.Drawing.Size(205, 26);
            this.gameTime.TabIndex = 7;
            // 
            // gameDate
            // 
            this.gameDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.gameDate.Location = new System.Drawing.Point(796, 385);
            this.gameDate.Name = "gameDate";
            this.gameDate.Size = new System.Drawing.Size(206, 26);
            this.gameDate.TabIndex = 6;
            // 
            // p2Type
            // 
            this.p2Type.Location = new System.Drawing.Point(1204, 389);
            this.p2Type.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p2Type.Name = "p2Type";
            this.p2Type.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p2Type.Size = new System.Drawing.Size(106, 26);
            this.p2Type.TabIndex = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1351, 392);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 20);
            this.label13.TabIndex = 34;
            this.label13.Text = "סוג שחקן 2";
            // 
            // colsBox
            // 
            this.colsBox.Location = new System.Drawing.Point(1204, 335);
            this.colsBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.colsBox.Name = "colsBox";
            this.colsBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.colsBox.Size = new System.Drawing.Size(106, 26);
            this.colsBox.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1337, 341);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 20);
            this.label12.TabIndex = 32;
            this.label12.Text = "מספר עמודות";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeight = 34;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gameIDDataGridViewTextBoxColumn,
            this.gameBoardRowsDataGridViewTextBoxColumn,
            this.gameBoardColsDataGridViewTextBoxColumn,
            this.gamePlayer1IDDataGridViewTextBoxColumn,
            this.gameType1DataGridViewTextBoxColumn,
            this.gamePlayer2IDDataGridViewTextBoxColumn,
            this.gameType2DataGridViewTextBoxColumn,
            this.gameDateDataGridViewTextBoxColumn,
            this.gameTimeDataGridViewTextBoxColumn,
            this.gameMinutesDataGridViewTextBoxColumn,
            this.gameMovesDataGridViewTextBoxColumn,
            this.gameColor1DataGridViewTextBoxColumn,
            this.gameColor2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblGamesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(30, 597);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1682, 326);
            this.dataGridView1.TabIndex = 31;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // gameIDDataGridViewTextBoxColumn
            // 
            this.gameIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameIDDataGridViewTextBoxColumn.DataPropertyName = "gameID";
            this.gameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.gameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameIDDataGridViewTextBoxColumn.Name = "gameIDDataGridViewTextBoxColumn";
            this.gameIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // gameBoardRowsDataGridViewTextBoxColumn
            // 
            this.gameBoardRowsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameBoardRowsDataGridViewTextBoxColumn.DataPropertyName = "gameBoardRows";
            this.gameBoardRowsDataGridViewTextBoxColumn.HeaderText = "שורות לוח";
            this.gameBoardRowsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameBoardRowsDataGridViewTextBoxColumn.Name = "gameBoardRowsDataGridViewTextBoxColumn";
            this.gameBoardRowsDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameBoardRowsDataGridViewTextBoxColumn.Width = 113;
            // 
            // gameBoardColsDataGridViewTextBoxColumn
            // 
            this.gameBoardColsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameBoardColsDataGridViewTextBoxColumn.DataPropertyName = "gameBoardCols";
            this.gameBoardColsDataGridViewTextBoxColumn.HeaderText = "עמודות לוח";
            this.gameBoardColsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameBoardColsDataGridViewTextBoxColumn.Name = "gameBoardColsDataGridViewTextBoxColumn";
            this.gameBoardColsDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameBoardColsDataGridViewTextBoxColumn.Width = 122;
            // 
            // gamePlayer1IDDataGridViewTextBoxColumn
            // 
            this.gamePlayer1IDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gamePlayer1IDDataGridViewTextBoxColumn.DataPropertyName = "gamePlayer1ID";
            this.gamePlayer1IDDataGridViewTextBoxColumn.HeaderText = "תז שחקן 1";
            this.gamePlayer1IDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gamePlayer1IDDataGridViewTextBoxColumn.Name = "gamePlayer1IDDataGridViewTextBoxColumn";
            this.gamePlayer1IDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gamePlayer1IDDataGridViewTextBoxColumn.Width = 115;
            // 
            // gameType1DataGridViewTextBoxColumn
            // 
            this.gameType1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameType1DataGridViewTextBoxColumn.DataPropertyName = "gameType1";
            this.gameType1DataGridViewTextBoxColumn.HeaderText = "סוג שחקן 1";
            this.gameType1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameType1DataGridViewTextBoxColumn.Name = "gameType1DataGridViewTextBoxColumn";
            this.gameType1DataGridViewTextBoxColumn.ReadOnly = true;
            this.gameType1DataGridViewTextBoxColumn.Width = 120;
            // 
            // gamePlayer2IDDataGridViewTextBoxColumn
            // 
            this.gamePlayer2IDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gamePlayer2IDDataGridViewTextBoxColumn.DataPropertyName = "gamePlayer2ID";
            this.gamePlayer2IDDataGridViewTextBoxColumn.HeaderText = "תז שחקן 2";
            this.gamePlayer2IDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gamePlayer2IDDataGridViewTextBoxColumn.Name = "gamePlayer2IDDataGridViewTextBoxColumn";
            this.gamePlayer2IDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gamePlayer2IDDataGridViewTextBoxColumn.Width = 115;
            // 
            // gameType2DataGridViewTextBoxColumn
            // 
            this.gameType2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameType2DataGridViewTextBoxColumn.DataPropertyName = "gameType2";
            this.gameType2DataGridViewTextBoxColumn.HeaderText = "סוג שחקן 2";
            this.gameType2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameType2DataGridViewTextBoxColumn.Name = "gameType2DataGridViewTextBoxColumn";
            this.gameType2DataGridViewTextBoxColumn.ReadOnly = true;
            this.gameType2DataGridViewTextBoxColumn.Width = 120;
            // 
            // gameDateDataGridViewTextBoxColumn
            // 
            this.gameDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameDateDataGridViewTextBoxColumn.DataPropertyName = "gameDate";
            this.gameDateDataGridViewTextBoxColumn.HeaderText = "תאריך משחק";
            this.gameDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameDateDataGridViewTextBoxColumn.Name = "gameDateDataGridViewTextBoxColumn";
            this.gameDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameDateDataGridViewTextBoxColumn.Width = 132;
            // 
            // gameTimeDataGridViewTextBoxColumn
            // 
            this.gameTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameTimeDataGridViewTextBoxColumn.DataPropertyName = "gameTime";
            this.gameTimeDataGridViewTextBoxColumn.HeaderText = "זמן תחילת משחק";
            this.gameTimeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameTimeDataGridViewTextBoxColumn.Name = "gameTimeDataGridViewTextBoxColumn";
            this.gameTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameTimeDataGridViewTextBoxColumn.Width = 160;
            // 
            // gameMinutesDataGridViewTextBoxColumn
            // 
            this.gameMinutesDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameMinutesDataGridViewTextBoxColumn.DataPropertyName = "gameMinutes";
            this.gameMinutesDataGridViewTextBoxColumn.HeaderText = "דקות משחק";
            this.gameMinutesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameMinutesDataGridViewTextBoxColumn.Name = "gameMinutesDataGridViewTextBoxColumn";
            this.gameMinutesDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameMinutesDataGridViewTextBoxColumn.Width = 122;
            // 
            // gameMovesDataGridViewTextBoxColumn
            // 
            this.gameMovesDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameMovesDataGridViewTextBoxColumn.DataPropertyName = "gameMoves";
            this.gameMovesDataGridViewTextBoxColumn.HeaderText = "מספר מהלכים";
            this.gameMovesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameMovesDataGridViewTextBoxColumn.Name = "gameMovesDataGridViewTextBoxColumn";
            this.gameMovesDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameMovesDataGridViewTextBoxColumn.Width = 135;
            // 
            // gameColor1DataGridViewTextBoxColumn
            // 
            this.gameColor1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameColor1DataGridViewTextBoxColumn.DataPropertyName = "gameColor1";
            this.gameColor1DataGridViewTextBoxColumn.HeaderText = "צבע שחקן 1";
            this.gameColor1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameColor1DataGridViewTextBoxColumn.Name = "gameColor1DataGridViewTextBoxColumn";
            this.gameColor1DataGridViewTextBoxColumn.ReadOnly = true;
            this.gameColor1DataGridViewTextBoxColumn.Width = 127;
            // 
            // gameColor2DataGridViewTextBoxColumn
            // 
            this.gameColor2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gameColor2DataGridViewTextBoxColumn.DataPropertyName = "gameColor2";
            this.gameColor2DataGridViewTextBoxColumn.HeaderText = "צבע שחקן 2";
            this.gameColor2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameColor2DataGridViewTextBoxColumn.Name = "gameColor2DataGridViewTextBoxColumn";
            this.gameColor2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblGamesBindingSource
            // 
            this.tblGamesBindingSource.DataMember = "tblGames";
            this.tblGamesBindingSource.DataSource = this.dataSetGames;
            // 
            // dataSetGames
            // 
            this.dataSetGames.DataSetName = "DataSetGames";
            this.dataSetGames.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(676, 446);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 29;
            this.label8.Text = "צבע שחקן 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(643, 391);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "זמן תחילת משחק";
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonUpdate.Location = new System.Drawing.Point(149, 341);
            this.buttonUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(120, 52);
            this.buttonUpdate.TabIndex = 19;
            this.buttonUpdate.Text = "עדכן";
            this.buttonUpdate.UseVisualStyleBackColor = true;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1610, 397);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "מספר שורות";
            // 
            // rowsBox
            // 
            this.rowsBox.Location = new System.Drawing.Point(1478, 391);
            this.rowsBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rowsBox.Name = "rowsBox";
            this.rowsBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rowsBox.Size = new System.Drawing.Size(106, 26);
            this.rowsBox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1035, 338);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "תז שחקן 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1616, 501);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "זקות משחק";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(688, 338);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "תז שחקן 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1615, 448);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "סוג שחקן 1";
            // 
            // p1Type
            // 
            this.p1Type.Location = new System.Drawing.Point(1478, 445);
            this.p1Type.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.p1Type.Name = "p1Type";
            this.p1Type.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.p1Type.Size = new System.Drawing.Size(106, 26);
            this.p1Type.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1018, 391);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "תאריך משחק";
            // 
            // tblGamesTableAdapter
            // 
            this.tblGamesTableAdapter.ClearBeforeFill = true;
            // 
            // FormUpdateGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormUpdateGame";
            this.Text = "FormUpdateGame";
            this.Load += new System.EventHandler(this.FormUpdateGame_Load);
            this.SizeChanged += new System.EventHandler(this.FormUpdateGame_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblGamesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetGames)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboId2;
        private System.Windows.Forms.ComboBox comboId1;
        private System.Windows.Forms.Button colorB2;
        private System.Windows.Forms.Button colorB1;
        private System.Windows.Forms.TextBox col2;
        private System.Windows.Forms.TextBox col1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox stepsNumber;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox gameMinutes;
        private System.Windows.Forms.DateTimePicker gameTime;
        private System.Windows.Forms.DateTimePicker gameDate;
        private System.Windows.Forms.TextBox p2Type;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox colsBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox rowsBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox p1Type;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonPrev;
        private System.Windows.Forms.Button buttonLast;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonFirst;
        private DataSetGames dataSetGames;
        private System.Windows.Forms.BindingSource tblGamesBindingSource;
        private DataSetGamesTableAdapters.tblGamesTableAdapter tblGamesTableAdapter;
        private System.Windows.Forms.TextBox gameId;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameBoardRowsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameBoardColsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gamePlayer1IDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameType1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gamePlayer2IDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameType2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameMinutesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameMovesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameColor1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameColor2DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label16;
    }
}
