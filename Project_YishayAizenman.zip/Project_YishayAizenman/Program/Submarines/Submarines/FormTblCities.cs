﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormTblCities : Submarines.FormBaseTables
    {
        public FormTblCities()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void FormTblCities_Load(object sender, EventArgs e)
        {
            this.tblCitiesTableAdapter.Fill(this.dataSetCities.tblCities);

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataSetCities changes = (DataSetCities)dataSetCities.GetChanges();
                if (changes == null)
                    return;
                DataTable dt = changes.tblCities.GetChanges();
                DataRow[] badRows = dt.GetErrors();

                if (badRows.Length > 0)
                {
                    string errorMsg = "";
                    foreach (DataRow row in badRows)
                    {
                        foreach (DataColumn col in row.GetColumnsInError())
                        {
                            errorMsg = errorMsg + row.GetColumnsInError() + "\n";
                        }
                    }
                    MessageBox.Show("Errors in data: " + errorMsg,
                    "Data errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                int numRows = tblCitiesTableAdapter.Update(changes);
                MessageBox.Show("Updated " + numRows + " rows", "Success");
                dataSetCities.AcceptChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Erros",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                dataSetCities.RejectChanges();
            }
        }

        private void FormTblCities_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
