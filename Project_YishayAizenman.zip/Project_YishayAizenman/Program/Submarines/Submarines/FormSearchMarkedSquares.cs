﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormSearchMarkedSquares : Submarines.FormBaseSearch
    {
        private OleDbConnection dataConnection;
        public FormSearchMarkedSquares(OleDbConnection dataConnection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.dataConnection = dataConnection;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM  tblMarkedSquares WHERE " +
                                           "msSubID  LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "msRowNum LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "msColNum LIKE \"%" + searchStr.Text + "%\"     " +
                                     "ORDER BY msSubID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                if (tbl.Rows.Count == 0)
                {
                    MessageBox.Show("לא נמצאו התאמות", "לא נמצא",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    dataGridView1.DataSource = tbl;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Search tblMarkedSquares failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblMarkedSquares " +
                                     "ORDER BY msSubID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh tblMarkedSquares table failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormSearchMarkedSquares_Load(object sender, EventArgs e)
        {
            this.tblMarkedSquaresTableAdapter.Fill(this.dataSetMarkedSquares.tblMarkedSquares);

        }

        private void FormSearchMarkedSquares_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
