﻿namespace Submarines
{
    partial class FormAddOrganization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAddOrganization));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOpenSite = new System.Windows.Forms.Button();
            this.siteAddress = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnShowVid = new System.Windows.Forms.Button();
            this.btnShowDir = new System.Windows.Forms.Button();
            this.btnShowPic = new System.Windows.Forms.Button();
            this.btnBrowseVid = new System.Windows.Forms.Button();
            this.btnBrowseFldr = new System.Windows.Forms.Button();
            this.vidLocation = new System.Windows.Forms.TextBox();
            this.folderLocation = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnBrowsePic = new System.Windows.Forms.Button();
            this.pictureLocation = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.wmp = new AxWMPLib.AxWindowsMediaPlayer();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.orgNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgCityIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgDirectorIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPictureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPicturesFolderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgClipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblOrganizationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetOrganization = new Submarines.DataSetOrganization();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.orgName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboCity = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.addressBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tblOrganizationTableAdapter = new Submarines.DataSetOrganizationTableAdapters.tblOrganizationTableAdapter();
            this.picFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.folderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.vidFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.comboManager = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboManager);
            this.panel1.Controls.Add(this.btnOpenSite);
            this.panel1.Controls.Add(this.siteAddress);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.btnShowVid);
            this.panel1.Controls.Add(this.btnShowDir);
            this.panel1.Controls.Add(this.btnShowPic);
            this.panel1.Controls.Add(this.btnBrowseVid);
            this.panel1.Controls.Add(this.btnBrowseFldr);
            this.panel1.Controls.Add(this.vidLocation);
            this.panel1.Controls.Add(this.folderLocation);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.btnBrowsePic);
            this.panel1.Controls.Add(this.pictureLocation);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.wmp);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.title);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.buttonAdd);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.orgName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.comboCity);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.addressBox);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(41, 74);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1839, 882);
            this.panel1.TabIndex = 31;
            // 
            // btnOpenSite
            // 
            this.btnOpenSite.Location = new System.Drawing.Point(327, 420);
            this.btnOpenSite.Name = "btnOpenSite";
            this.btnOpenSite.Size = new System.Drawing.Size(84, 29);
            this.btnOpenSite.TabIndex = 80;
            this.btnOpenSite.Text = "פתח";
            this.btnOpenSite.UseVisualStyleBackColor = true;
            this.btnOpenSite.Click += new System.EventHandler(this.btnOpenSite_Click);
            // 
            // siteAddress
            // 
            this.siteAddress.Location = new System.Drawing.Point(429, 421);
            this.siteAddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.siteAddress.Name = "siteAddress";
            this.siteAddress.Size = new System.Drawing.Size(346, 26);
            this.siteAddress.TabIndex = 79;
            this.siteAddress.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(809, 424);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 78;
            this.label4.Text = "אתר ארגון";
            // 
            // btnShowVid
            // 
            this.btnShowVid.Location = new System.Drawing.Point(237, 375);
            this.btnShowVid.Name = "btnShowVid";
            this.btnShowVid.Size = new System.Drawing.Size(84, 29);
            this.btnShowVid.TabIndex = 72;
            this.btnShowVid.Text = "הצג";
            this.btnShowVid.UseVisualStyleBackColor = true;
            this.btnShowVid.Click += new System.EventHandler(this.btnShowVid_Click);
            // 
            // btnShowDir
            // 
            this.btnShowDir.Location = new System.Drawing.Point(237, 329);
            this.btnShowDir.Name = "btnShowDir";
            this.btnShowDir.Size = new System.Drawing.Size(84, 29);
            this.btnShowDir.TabIndex = 70;
            this.btnShowDir.Text = "הצג";
            this.btnShowDir.UseVisualStyleBackColor = true;
            this.btnShowDir.Click += new System.EventHandler(this.btnShowDir_Click);
            // 
            // btnShowPic
            // 
            this.btnShowPic.Location = new System.Drawing.Point(237, 279);
            this.btnShowPic.Name = "btnShowPic";
            this.btnShowPic.Size = new System.Drawing.Size(84, 29);
            this.btnShowPic.TabIndex = 68;
            this.btnShowPic.Text = "הצג";
            this.btnShowPic.UseVisualStyleBackColor = true;
            this.btnShowPic.Click += new System.EventHandler(this.btnShowPic_Click);
            // 
            // btnBrowseVid
            // 
            this.btnBrowseVid.Location = new System.Drawing.Point(327, 375);
            this.btnBrowseVid.Name = "btnBrowseVid";
            this.btnBrowseVid.Size = new System.Drawing.Size(84, 29);
            this.btnBrowseVid.TabIndex = 71;
            this.btnBrowseVid.Text = ". . .עיון";
            this.btnBrowseVid.UseVisualStyleBackColor = true;
            this.btnBrowseVid.Click += new System.EventHandler(this.btnBrowseVid_Click);
            // 
            // btnBrowseFldr
            // 
            this.btnBrowseFldr.Location = new System.Drawing.Point(327, 329);
            this.btnBrowseFldr.Name = "btnBrowseFldr";
            this.btnBrowseFldr.Size = new System.Drawing.Size(84, 29);
            this.btnBrowseFldr.TabIndex = 69;
            this.btnBrowseFldr.Text = ". . .עיון";
            this.btnBrowseFldr.UseVisualStyleBackColor = true;
            this.btnBrowseFldr.Click += new System.EventHandler(this.btnBrowseFldr_Click);
            // 
            // vidLocation
            // 
            this.vidLocation.Enabled = false;
            this.vidLocation.Location = new System.Drawing.Point(429, 377);
            this.vidLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.vidLocation.Name = "vidLocation";
            this.vidLocation.Size = new System.Drawing.Size(346, 26);
            this.vidLocation.TabIndex = 77;
            this.vidLocation.TabStop = false;
            // 
            // folderLocation
            // 
            this.folderLocation.Enabled = false;
            this.folderLocation.Location = new System.Drawing.Point(429, 330);
            this.folderLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.folderLocation.Name = "folderLocation";
            this.folderLocation.Size = new System.Drawing.Size(346, 26);
            this.folderLocation.TabIndex = 76;
            this.folderLocation.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(798, 380);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 75;
            this.label5.Text = "סרטון ארגון";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(786, 333);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 20);
            this.label9.TabIndex = 74;
            this.label9.Text = "תיקיית תמונות";
            // 
            // btnBrowsePic
            // 
            this.btnBrowsePic.Location = new System.Drawing.Point(327, 279);
            this.btnBrowsePic.Name = "btnBrowsePic";
            this.btnBrowsePic.Size = new System.Drawing.Size(84, 29);
            this.btnBrowsePic.TabIndex = 67;
            this.btnBrowsePic.Text = ". . .עיון";
            this.btnBrowsePic.UseVisualStyleBackColor = true;
            this.btnBrowsePic.Click += new System.EventHandler(this.btnBrowsePic_Click);
            // 
            // pictureLocation
            // 
            this.pictureLocation.Enabled = false;
            this.pictureLocation.Location = new System.Drawing.Point(429, 280);
            this.pictureLocation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureLocation.Name = "pictureLocation";
            this.pictureLocation.Size = new System.Drawing.Size(346, 26);
            this.pictureLocation.TabIndex = 66;
            this.pictureLocation.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(797, 283);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 20);
            this.label10.TabIndex = 73;
            this.label10.Text = "תמונת ארגון";
            // 
            // wmp
            // 
            this.wmp.Enabled = true;
            this.wmp.Location = new System.Drawing.Point(907, 44);
            this.wmp.Name = "wmp";
            this.wmp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wmp.OcxState")));
            this.wmp.Size = new System.Drawing.Size(266, 266);
            this.wmp.TabIndex = 10;
            this.wmp.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(1361, 66);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 400);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(1661, 501);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 25);
            this.label8.TabIndex = 35;
            this.label8.Text = "טבלת ארגון";
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(851, 36);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(169, 37);
            this.title.TabIndex = 32;
            this.title.Text = "הוספת ארגון";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orgNameDataGridViewTextBoxColumn,
            this.orgAddressDataGridViewTextBoxColumn,
            this.orgCityIDDataGridViewTextBoxColumn,
            this.orgDirectorIDDataGridViewTextBoxColumn,
            this.orgPictureDataGridViewTextBoxColumn,
            this.orgPicturesFolderDataGridViewTextBoxColumn,
            this.orgClipDataGridViewTextBoxColumn,
            this.orgSite});
            this.dataGridView1.DataSource = this.tblOrganizationBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(35, 529);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1726, 312);
            this.dataGridView1.TabIndex = 16;
            // 
            // orgNameDataGridViewTextBoxColumn
            // 
            this.orgNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgNameDataGridViewTextBoxColumn.DataPropertyName = "orgName";
            this.orgNameDataGridViewTextBoxColumn.HeaderText = "שם ארגון";
            this.orgNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgNameDataGridViewTextBoxColumn.Name = "orgNameDataGridViewTextBoxColumn";
            this.orgNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgNameDataGridViewTextBoxColumn.Width = 170;
            // 
            // orgAddressDataGridViewTextBoxColumn
            // 
            this.orgAddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgAddressDataGridViewTextBoxColumn.DataPropertyName = "orgAddress";
            this.orgAddressDataGridViewTextBoxColumn.HeaderText = "כתובת";
            this.orgAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgAddressDataGridViewTextBoxColumn.Name = "orgAddressDataGridViewTextBoxColumn";
            this.orgAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgAddressDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgCityIDDataGridViewTextBoxColumn
            // 
            this.orgCityIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgCityIDDataGridViewTextBoxColumn.DataPropertyName = "orgCityID";
            this.orgCityIDDataGridViewTextBoxColumn.HeaderText = "קוד עיר";
            this.orgCityIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgCityIDDataGridViewTextBoxColumn.Name = "orgCityIDDataGridViewTextBoxColumn";
            this.orgCityIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgCityIDDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgDirectorIDDataGridViewTextBoxColumn
            // 
            this.orgDirectorIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgDirectorIDDataGridViewTextBoxColumn.DataPropertyName = "orgDirectorID";
            this.orgDirectorIDDataGridViewTextBoxColumn.HeaderText = "תז מנהל";
            this.orgDirectorIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgDirectorIDDataGridViewTextBoxColumn.Name = "orgDirectorIDDataGridViewTextBoxColumn";
            this.orgDirectorIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgDirectorIDDataGridViewTextBoxColumn.Width = 80;
            // 
            // orgPictureDataGridViewTextBoxColumn
            // 
            this.orgPictureDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPictureDataGridViewTextBoxColumn.DataPropertyName = "orgPicture";
            this.orgPictureDataGridViewTextBoxColumn.HeaderText = "מיקום תמונה";
            this.orgPictureDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPictureDataGridViewTextBoxColumn.Name = "orgPictureDataGridViewTextBoxColumn";
            this.orgPictureDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgPictureDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgPicturesFolderDataGridViewTextBoxColumn
            // 
            this.orgPicturesFolderDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPicturesFolderDataGridViewTextBoxColumn.DataPropertyName = "orgPicturesFolder";
            this.orgPicturesFolderDataGridViewTextBoxColumn.HeaderText = "מיקום תיקיית תמונות";
            this.orgPicturesFolderDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Name = "orgPicturesFolderDataGridViewTextBoxColumn";
            this.orgPicturesFolderDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgClipDataGridViewTextBoxColumn
            // 
            this.orgClipDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgClipDataGridViewTextBoxColumn.DataPropertyName = "orgClip";
            this.orgClipDataGridViewTextBoxColumn.HeaderText = "מיקום סרטון";
            this.orgClipDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgClipDataGridViewTextBoxColumn.Name = "orgClipDataGridViewTextBoxColumn";
            this.orgClipDataGridViewTextBoxColumn.ReadOnly = true;
            this.orgClipDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgSite
            // 
            this.orgSite.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.orgSite.DataPropertyName = "orgSite";
            this.orgSite.HeaderText = "כתובת אתר";
            this.orgSite.MinimumWidth = 8;
            this.orgSite.Name = "orgSite";
            this.orgSite.ReadOnly = true;
            // 
            // tblOrganizationBindingSource
            // 
            this.tblOrganizationBindingSource.DataMember = "tblOrganization";
            this.tblOrganizationBindingSource.DataSource = this.dataSetOrganization;
            // 
            // dataSetOrganization
            // 
            this.dataSetOrganization.DataSetName = "DataSetOrganization";
            this.dataSetOrganization.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.buttonAdd.Location = new System.Drawing.Point(63, 328);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(120, 52);
            this.buttonAdd.TabIndex = 11;
            this.buttonAdd.Text = "הוסף";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1187, 283);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "שם ארגון";
            // 
            // orgName
            // 
            this.orgName.Location = new System.Drawing.Point(959, 277);
            this.orgName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.orgName.Name = "orgName";
            this.orgName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.orgName.Size = new System.Drawing.Size(199, 26);
            this.orgName.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1195, 380);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "תז מנהל";
            // 
            // comboCity
            // 
            this.comboCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboCity.FormattingEnabled = true;
            this.comboCity.Location = new System.Drawing.Point(959, 421);
            this.comboCity.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboCity.Name = "comboCity";
            this.comboCity.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboCity.Size = new System.Drawing.Size(199, 28);
            this.comboCity.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1207, 333);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "כתובת";
            // 
            // addressBox
            // 
            this.addressBox.Location = new System.Drawing.Point(959, 330);
            this.addressBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addressBox.Name = "addressBox";
            this.addressBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.addressBox.Size = new System.Drawing.Size(199, 26);
            this.addressBox.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1225, 424);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "עיר";
            // 
            // tblOrganizationTableAdapter
            // 
            this.tblOrganizationTableAdapter.ClearBeforeFill = true;
            // 
            // comboManager
            // 
            this.comboManager.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboManager.FormattingEnabled = true;
            this.comboManager.Location = new System.Drawing.Point(959, 376);
            this.comboManager.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboManager.Name = "comboManager";
            this.comboManager.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboManager.Size = new System.Drawing.Size(199, 28);
            this.comboManager.TabIndex = 81;
            // 
            // FormAddOrganization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormAddOrganization";
            this.Text = "FormAddOrganization";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormAddOrganization_FormClosed);
            this.Load += new System.EventHandler(this.FormAddOrganization_Load);
            this.SizeChanged += new System.EventHandler(this.FormAddOrganization_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox orgName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboCity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox addressBox;
        private System.Windows.Forms.Label label7;
        private DataSetOrganization dataSetOrganization;
        private System.Windows.Forms.BindingSource tblOrganizationBindingSource;
        private DataSetOrganizationTableAdapters.tblOrganizationTableAdapter tblOrganizationTableAdapter;
        private System.Windows.Forms.OpenFileDialog picFileDialog;
        private System.Windows.Forms.FolderBrowserDialog folderDialog;
        private System.Windows.Forms.OpenFileDialog vidFileDialog;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AxWMPLib.AxWindowsMediaPlayer wmp;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgCityIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgDirectorIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPictureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPicturesFolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgClipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgSite;
        private System.Windows.Forms.Button btnOpenSite;
        private System.Windows.Forms.TextBox siteAddress;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnShowVid;
        private System.Windows.Forms.Button btnShowDir;
        private System.Windows.Forms.Button btnShowPic;
        private System.Windows.Forms.Button btnBrowseVid;
        private System.Windows.Forms.Button btnBrowseFldr;
        private System.Windows.Forms.TextBox vidLocation;
        private System.Windows.Forms.TextBox folderLocation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnBrowsePic;
        private System.Windows.Forms.TextBox pictureLocation;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboManager;
    }
}
