﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Submarines
{
    public static class SubmarinesDataStructures
    {
        public class Player
        {
            public readonly int playerId;
            public readonly string firstName;
            public readonly string lastName;
            public readonly int playerColorArgb;
            public readonly bool isComputer;

            public Player(int playerId, string firstName, string lastName)
            {
                this.playerId = playerId;
                this.firstName = firstName;
                this.lastName = lastName;
            }

            public Player(Player idAndNames, int argb, bool isComputer)
            {
                this.playerColorArgb = argb;
                this.isComputer = isComputer;
                this.playerId = idAndNames.playerId;
                this.firstName = idAndNames.firstName;
                this.lastName = idAndNames.lastName;
            }

            public Player(string comboDetails)
            {
                string[] s = comboDetails.Split(' ');
                this.playerId = int.Parse(s[0].TrimEnd(','));
                this.firstName = s[1];
                this.lastName = s[2];
            }

            public string GetPlayerPicLocation(OleDbConnection dataConnection)
            {
                string location = "";
                try
                {
                    OleDbCommand datacommand = new OleDbCommand();
                    datacommand.Connection = dataConnection;
                    datacommand.CommandText = "SELECT playerPicture " +
                                              "FROM tblPlayers " +
                                              "WHERE playerID = @id";
                    datacommand.Parameters.AddWithValue("@id", playerId);
                    location = (string)datacommand.ExecuteScalar();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Get player picture failed \n" + err.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return location;
            }
        }

        public class Submarine
        {
            public readonly int subId;
            public readonly string subName;
            public readonly int subRows;
            public readonly int subCols;
            public readonly int subSinkPercent;

            public Submarine(int subId, string subName, int subRows, int subCols, int subSinkPercent)
            {
                this.subId = subId;
                this.subName = subName;
                this.subRows = subRows;
                this.subCols = subCols;
                this.subSinkPercent = subSinkPercent;
            }

            public override string ToString()
            {
                return $"{subId}, {subName}, גודל: {subRows} על {subCols}";
            }

            public string ExtendedString()
            {
                return $"{subId}, {subName}, גודל: {subRows} על {subCols}, אחוז הטבעה: {subSinkPercent}";
            }

            public int GetSubArea()
            {
                return subRows * subCols;
            }

            public int[,] GetMarkedSquaresArray(OleDbConnection dataConnection)
            {
                int[,] mSquares = new int[subRows, subCols];
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT msRowNum, msColNum " +
                                          "FROM tblMarkedSquares " +
                                          "WHERE msSubID = @id";
                datacommand.Parameters.AddWithValue("@id", subId);
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    int i = dataReader.GetInt32(0);
                    int j = dataReader.GetInt32(1);
                    mSquares[i, j] = 1;
                }
                dataReader.Close();
                return mSquares;
            }

            public bool IsSunk(OleDbConnection dataConnection, int remainingSqrs)
            {
                if (remainingSqrs == 0) { return true; }

                int totalSquares = 0;
                Action runCommand = () =>
                {
                    OleDbCommand datacommand = new OleDbCommand();
                    datacommand.Connection = dataConnection;
                    datacommand.CommandText = "SELECT COUNT(*) " +
                                              "FROM tblMarkedSquares " +
                                              "WHERE msSubID = @id";
                    datacommand.Parameters.AddWithValue("@id", subId);
                    totalSquares = (int)datacommand.ExecuteScalar();
                };

                try
                {
                    runCommand();
                }
                catch (OleDbException ex) when (ex.Message.Contains("Cannot open any more tables"))
                {
                    MessageBox.Show("Slow down! the database can't keep up with this speed... retrying",
                        "Slow down",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    runCommand();
                }
                catch (Exception err)
                {
                    MessageBox.Show("get total sub squares failed \n" + err.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                double n = (double)(totalSquares - remainingSqrs) / totalSquares;
                if (n * 100 >= subSinkPercent)
                {
                    return true;
                }
                return false;
            }
        }

        public class Game
        {
            public readonly int gameId;
            public readonly int gameStarterPlayer;
            public readonly int boardRows;
            public readonly int boardCols;
            public readonly Player player1;
            public readonly Player player2;
            public List<Submarine> submarines;            

            public Game(int gameId, int gameStarterPlayer, int boardRows, int boardCols,
                Player player1, Player player2, List<Submarine> submarines)
            {
                this.gameId = gameId;
                this.gameStarterPlayer = gameStarterPlayer;
                this.boardRows = boardRows;
                this.boardCols = boardCols;
                this.player1 = player1;
                this.player2 = player2;
                this.submarines = submarines;
            }

            public void RegisterToDatabase(OleDbConnection dataConnection)
            {
                int p1c = player1.isComputer ? 2 : 1;
                int p2c = player2.isComputer ? 2 : 1;
                DateTime gameStart = DateTime.Now;

                try
                {
                    OleDbCommand datacommand = new OleDbCommand();
                    datacommand.Connection = dataConnection;
                    string str = string.Format(
                        "INSERT INTO tblGames " +
                        "(gameBoardRows, gameBoardCols, gamePlayer1ID, gameType1, gamePlayer2ID, gameType2," +
                        " gameDate, gameTime, gameMinutes, gameMoves, gameColor1, gameColor2) " +
                        "VALUES ({0}, {1}, {2}, {3}, {4}, {5}, #{6}#, #{7}#, {8}, {9}, {10}, {11})",
                         boardRows, boardCols, player1.playerId, p1c, player2.playerId, p2c,
                         gameStart.ToString("dd/MM/yyyy"), gameStart.ToString("HH:mm:ss dd/MM/yyyy"),
                         0, 0, player1.playerColorArgb, player2.playerColorArgb);
                    datacommand.CommandText = str;
                    datacommand.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Insert into tblGames failed \n" + err.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            public void AddDurationAndSetSteps(OleDbConnection dataConnection, int duration, int steps)
            {
                try
                {
                    OleDbCommand datacommand = new OleDbCommand();
                    datacommand.Connection = dataConnection;
                    datacommand.CommandText = "UPDATE tblGames " +
                                              "SET  gameMinutes = gameMinutes + @duration, " +
                                              "     gameMoves   = @steps " +
                                              "WHERE  gameID = @id";
                    datacommand.Parameters.AddWithValue("@duration", duration);
                    datacommand.Parameters.AddWithValue("@steps", steps);
                    datacommand.Parameters.AddWithValue("@id", gameId);
                    datacommand.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Update tblGames failed \n" + err.Message, "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }                    

        public class Step
        {
            public readonly int orderNum;
            public readonly int row;
            public readonly int col;
            public readonly int playerNum;
            public readonly bool isAirStrike;

            public Step(int orderNum, int row, int col, int playerNum, bool isAirStrike)
            {
                this.orderNum = orderNum;
                this.row = row;
                this.col = col;
                this.playerNum = playerNum;
                this.isAirStrike = isAirStrike;
            }
        }

        public class SubmarineLocation
        {
            public readonly int player;
            public readonly int subID;
            public readonly int row;
            public readonly int col;

            public SubmarineLocation(int player, int subID, int row, int col)
            {
                this.player = player;
                this.subID = subID;
                this.row = row;
                this.col = col;
            }
        }
    }
}
