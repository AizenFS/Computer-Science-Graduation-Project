﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormGamePlay : Submarines.FormBaseGame
    {
        private enum Weapon { DepthCharge = 0, AirStrike = 1 }
        private enum SquareStates { Unavailable = -1, Available = 0, AlreadyHit = 1 }

        private SubmarinesUtils.GameBoardCreator gameBoardCreator;

        private readonly OleDbConnection dataConnection;
        private readonly Game game;
        private readonly List<SubmarineLocation> subsStartGame;
        private bool isContinuedGameInit;
        private int[] airStrikeCounts;

        private int stepCount = 0;
        private double orderStepCount = 0;
        private bool gameWon = false;
        private DateTime gameStart;

        private readonly Player p1, p2;
        private Weapon p1Weapon, p2Weapon;
        private int[,] boardLocations1, boardLocations2;

        private int computerPlayer;
        private Dictionary<int, Button> computerButtonHits;
        private Timer computerDelay;
        private readonly Random random = new Random();

        private int currentPlayer;
        private Weapon currentWeapon;
        private int[,] currentLocations;

        private Panel currentBoard;
        private Label currentAirStrikeCount;
        private TextBox currentRemainingSubs;

        public FormGamePlay(OleDbConnection dataConnection, bool isContinuedGameInit,
            Game game, List<SubmarineLocation> subsStartGame,
            int[,] boardLocations1, int[,] boardLocations2, int[] airStrikeCounts)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

            this.dataConnection = dataConnection;
            this.isContinuedGameInit = isContinuedGameInit;
            this.game = game;
            this.subsStartGame = subsStartGame;
            this.boardLocations1 = boardLocations1;
            this.boardLocations2 = boardLocations2;
            this.airStrikeCounts = airStrikeCounts;

            gameBoardCreator = new SubmarinesUtils.GameBoardCreator(game, ButtonEventsAssigner, 
                false, SquareStates.Available);

            computerButtonHits = new Dictionary<int, Button>();
            computerDelay = new Timer { Interval = 300 };

            computerDelay.Tick += ComputerDelay_Tick;

            p1 = game.player1;
            p2 = game.player2;
            currentPlayer = game.gameStarterPlayer;
        }

        private void AssignControlVariables(int playerNum)
        {
            currentWeapon = playerNum == 1 ? p1Weapon : p2Weapon;
            currentBoard = playerNum == 1 ? board1 : board2;
            currentAirStrikeCount = playerNum == 1 ? airStrikeCount1 : airStrikeCount2;
            currentRemainingSubs = playerNum == 1 ? rmnSubs1 : rmnSubs2;
            currentLocations = playerNum == 1 ? boardLocations2 : boardLocations1;
        }

        #region Initiallization
        private void FormGamePlay_Load(object sender, EventArgs e)
        {
            SetupPlayerGUIs();
            computerPlayer = DetermineComputerPlayer();

            gameBoardCreator.CreateBoard(board1);
            gameBoardCreator.CreateBoard(board2);

            game.submarines.ForEach(sub => computerButtonHits.Add(sub.subId, null));

            if (!isContinuedGameInit)
            {
                game.RegisterToDatabase(dataConnection);
                RegisterSubLocations();
            }
            else
            {
                DisplayPreviousHits();
                stepCount = GetGameStepCount();
                orderStepCount = stepCount;
                isContinuedGameInit = false;
            }

            gameStart = DateTime.Now;
            AssignControlVariables(currentPlayer);
            labelCurrPlayerNum.Text = currentPlayer.ToString();
            if(computerPlayer == currentPlayer) { computerDelay.Start(); }
        }

        private int DetermineComputerPlayer()
        {
            if (p1.isComputer)
            {
                int center = (NP1.Left + NP1.Width / 2) - labelComputerPlayer.Width / 2;
                labelComputerPlayer.Left = center;
                return 1;
            }
            if (p2.isComputer)
            {
                int center = (NP2.Left + NP2.Width / 2) - labelComputerPlayer.Width / 2;
                labelComputerPlayer.Left = center;
                return 2;
            }
            labelComputerPlayer.Visible = false;
            return 0;
        }

        private void ButtonEventsAssigner(Button button)
        {
            button.MouseEnter += button_MouseEnter;
            button.MouseLeave += button_MouseLeave;
            button.Click += button_Click;
            button.GotFocus += Button_GotFocus;
        }
        
        private void SetupPlayerGUIs()
        {
            Image copy = airStrike2.Image.Clone() as Image;
            copy.RotateFlip(RotateFlipType.RotateNoneFlipX);
            airStrike1.Image = copy;

            NP1.UpdateProperties(p1, dataConnection);
            NP2.UpdateProperties(p2, dataConnection);

            rmnSubs1.Text = game.submarines.Count.ToString();
            rmnSubs2.Text = game.submarines.Count.ToString();

            depthCharge1_Click(null, EventArgs.Empty);
            depthCharge2_Click(null, EventArgs.Empty);

            airStrikeCount1.Text = airStrikeCounts[0].ToString();
            airStrikeCount2.Text = airStrikeCounts[1].ToString();
        }

        #endregion

        #region Continued game initiallization
        private void DisplayPreviousHits()
        {
            DisplayPreviousHits(1);
            DisplayPreviousHits(2);
        }
        private void DisplayPreviousHits(int playerNum)
        {
            AssignControlVariables(playerNum);            
            for (int i = 0; i < game.submarines.Count; i++) {
                int id = game.submarines[i].subId;                
                CheckAndSink(id);
            }
            HitRemainingSquares(playerNum);            
        }
        private void HitRemainingSquares(int playerNum)
        {
            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b)
                {
                    int[] indices = SubmarinesUtils.GetButtonIndices(b);
                    int r = indices[0];
                    int c = indices[1];
                    int value = currentLocations[r, c];
                    if (value < 0)
                    {
                        if (value == -999) { 
                            b.BackColor = SystemColors.Control;
                            currentLocations[r, c] = 0;
                        }
                        else if((SquareStates)b.Tag != SquareStates.AlreadyHit)
                        {
                            b.BackColor = Color.Red;
                            if (playerNum == computerPlayer)
                            {
                                computerButtonHits[value] = b;
                            }
                        }
                        b.Tag = SquareStates.AlreadyHit;
                        b.Enabled = false;
                    }                 
                }
            }
        }

        private int GetGameStepCount()
        {
            int count = 0;
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;                
                datacommand.CommandText = "SELECT gameMoves " +
                                          "FROM tblGames " +
                                          "WHERE gameID = @id";
                datacommand.Parameters.AddWithValue("@id",game.gameId);
                count = (int)datacommand.ExecuteScalar();
            }
            catch (Exception err)
            {
                MessageBox.Show("getting game step count failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return count;
        }
        #endregion

        #region Registering to database
        private void RegisterSubLocations()
        {
            try
            {
                int c = subsStartGame.Count;
                for (int i = 0; i < c/2; i++)
                {
                    SubmarineLocation location1 = subsStartGame.First(location => location.player == 1);
                    subsStartGame.Remove(location1);
                    SubmarineLocation location2 = subsStartGame.First(location => location.subID == location1.subID);                    
                    subsStartGame.Remove(location2);

                    OleDbCommand datacommand = new OleDbCommand();
                    datacommand.Connection = dataConnection;
                    datacommand.CommandText = string.Format(
                        "INSERT INTO tblStartGames " +
                        "(startGameID, startOrderNum, startSubID, startRow1, startCol1, startRow2, startCol2) " +
                        "VALUES ({0}, {1}, {2}, {3}, {4}, {5}, {6})",
                        game.gameId, i, location1.subID, location1.row, location1.col, location2.row, location2.col);
                    datacommand.ExecuteNonQuery();
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblStartGames failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }        
        private void RegisterStep(int row, int col)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblSteps " +
                    "(stepGameID, stepOrderNum, stepPlayer, stepRow, stepCol) " +
                    "VALUES ({0}, {1}, {2}, {3}, {4})",
                    game.gameId, orderStepCount, currentPlayer, row, col);
                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();                
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblSteps failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Weapon controls
        private void depthCharge2_Click(object sender, EventArgs e)
        {
            depthCharge2.BackColor = Color.FromArgb(p2.playerColorArgb);
            airStrikeCount2.BackColor = Color.DarkGray;
            airStrike2.BackColor = Color.DarkGray;
            p2Weapon = Weapon.DepthCharge;
            currentWeapon = currentPlayer == 2 ? p2Weapon : currentWeapon;
        }

        private void airStrike2_Click(object sender, EventArgs e)
        {
            if (int.Parse(airStrikeCount2.Text) == 0)
            {
                if (computerPlayer != 2)
                {
                    MessageBox.Show(".שחקן 2, נגמרו לך ההפגזות האוויריות\n" +
                        ".אתה יכול להשיג עוד על ידי הטבעת צוללות אויב", "אין הפגזות אוייריות במלאי"
                        , MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }
            airStrike2.BackColor = Color.FromArgb(p2.playerColorArgb);
            airStrikeCount2.BackColor = Color.FromArgb(p2.playerColorArgb);
            depthCharge2.BackColor = Color.DarkGray;
            p2Weapon = Weapon.AirStrike;
            currentWeapon = currentPlayer == 2 ? p2Weapon : currentWeapon;
        }

        private void airStrike1_Click(object sender, EventArgs e)
        {
            if (int.Parse(airStrikeCount1.Text) == 0)
            {
                if (computerPlayer != 1)
                {
                    MessageBox.Show(".שחקן 1, נגמרו לך ההפגזות האוויריות\n" +
                         ".אתה יכול להשיג עוד על ידי הטבעת צוללות אויב", "אין הפגזות אוייריות במלאי"
                         , MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }
            airStrike1.BackColor = Color.FromArgb(p1.playerColorArgb);
            airStrikeCount1.BackColor = Color.FromArgb(p1.playerColorArgb);
            depthCharge1.BackColor = Color.DarkGray;
            p1Weapon = Weapon.AirStrike;
            currentWeapon = currentPlayer == 1 ? p1Weapon : currentWeapon;
        }

        private void depthCharge1_Click(object sender, EventArgs e)
        {
            depthCharge1.BackColor = Color.FromArgb(p1.playerColorArgb);
            airStrikeCount1.BackColor = Color.DarkGray;
            airStrike1.BackColor = Color.DarkGray;
            p1Weapon = Weapon.DepthCharge;
            currentWeapon = currentPlayer == 1 ? p1Weapon : currentWeapon;
        }
        #endregion

        #region Computer player algorithm
        private void ComputerDelay_Tick(object sender, EventArgs e)
        {
            computerDelay.Stop();
            ComputerChoose();
        }

        private void ComputerChoose()
        {
            if (computerPlayer == 1) { airStrike1_Click(null, EventArgs.Empty); }
            if (computerPlayer == 2) { airStrike2_Click(null, EventArgs.Empty); }

            int randCount = 0;
            while(true)
            {
                Button hitButton = computerButtonHits.Values.FirstOrDefault(btn => btn != null);
                Button b = hitButton != null ? GetNearbyRandomButton(hitButton) : GetRandomButton();
                button_MouseEnter(b, EventArgs.Empty);
                if ((SquareStates)b.Tag == SquareStates.Available)
                {
                    button_Click(b, EventArgs.Empty);
                    button_MouseLeave(b, EventArgs.Empty);
                    return;
                }
                else
                {
                    button_MouseLeave(b, EventArgs.Empty);
                    randCount++;
                    if (randCount >= 30)
                    {
                        if (computerPlayer == 1) { depthCharge1_Click(null, EventArgs.Empty); }
                        else { depthCharge2_Click(null, EventArgs.Empty); }
                    }
                }
            }
        }

        private Button GetRandomButton()
        {
            List<Button> btnList = new List<Button>();
            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b && (SquareStates)b.Tag == SquareStates.Available)
                {
                    btnList.Add(b);
                }
            }
            int i = random.Next(0, btnList.Count);
            return btnList[i];
        }

        private Button GetNearbyRandomButton(Button button)
        {

            List<Button> btnList = new List<Button>();
            int[] indices = SubmarinesUtils.GetButtonIndices(button);
            int bRow = indices[0];
            int bCol = indices[1];
            int distanceFromOriginal = 0;
            do
            {
                distanceFromOriginal++;
                foreach (Control ctrl in currentBoard.Controls)
                {
                    if (ctrl is Button b && (SquareStates)b.Tag == SquareStates.Available)
                    {
                        indices = SubmarinesUtils.GetButtonIndices(b);
                        int r = indices[0];
                        int c = indices[1];
                        if (Math.Abs(r - bRow) <= distanceFromOriginal && Math.Abs(c - bCol) <= distanceFromOriginal)
                        {
                            btnList.Add(b);
                        }
                    }
                }
            } while (btnList.Count == 0);

            int i = random.Next(0, btnList.Count);
            return btnList[i];
        }
        #endregion

        #region Button Events               
        private void button_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if(btn.Parent != currentBoard || (SquareStates)btn.Tag == SquareStates.AlreadyHit) { return; }

            if (currentWeapon == Weapon.DepthCharge)
            {
                btn.BackColor = computerPlayer != currentPlayer ? Color.LightGreen : btn.BackColor;
            }
            else
            {
                int[] indicies = SubmarinesUtils.GetButtonIndices(btn);
                int bRow = indicies[0];
                int bCol = indicies[1];
                if (bRow == 0 || bRow == game.boardRows - 1 || bCol == 0 || bCol == game.boardCols - 1)
                {
                    btn.BackColor = computerPlayer != currentPlayer ? Color.Red : btn.BackColor;
                    btn.Tag = SquareStates.Unavailable;
                    return;
                }
                foreach (Control ctrl in currentBoard.Controls)
                {
                    if (ctrl is Button b)
                    {
                        indicies = SubmarinesUtils.GetButtonIndices(b);
                        int r = indicies[0];
                        int c = indicies[1];
                        if ((SquareStates)b.Tag == SquareStates.Available && Math.Abs(r - bRow) <= 1 &&
                            Math.Abs(c - bCol) <= 1)
                        {
                            b.BackColor = computerPlayer != currentPlayer ? Color.LightGreen : btn.BackColor;
                        }
                    }
                }
            }
        }

        private void button_MouseLeave(object sender, EventArgs e)
        {
            if((sender as Button).Parent != currentBoard) { return; }

            foreach (Control c in currentBoard.Controls)
            {
                if (c is Button btn && (SquareStates)btn.Tag != SquareStates.AlreadyHit)
                {
                    int r = SubmarinesUtils.GetButtonIndices(btn)[0];
                    btn.BackColor = r % 2 == 0 
                        ? Properties.Settings.Default.DefaultButtonColor1 
                        : Properties.Settings.Default.DefaultButtonColor2;
                    btn.Tag = SquareStates.Available;
                }
            }
        }

        private void Button_GotFocus(object sender, EventArgs e)
        {
            Button button = sender as Button;
            button.NotifyDefault(false);
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button target = sender as Button;
            if (target.Parent != currentBoard || (SquareStates)target.Tag != SquareStates.Available) { return; }           
            int[] indices = SubmarinesUtils.GetButtonIndices(target);
            int bRow = indices[0];
            int bCol = indices[1];

            bool passTurn = true;
            stepCount++;
            orderStepCount = Math.Floor(orderStepCount) + 1;

            if (currentWeapon == Weapon.DepthCharge)
            {
                RegisterStep(bRow, bCol);
                int subId = currentLocations[bRow, bCol];
                if (HitSquare(target, bRow, bCol))
                {
                    passTurn = false || CheckAndSink(subId);
                }
            }
            else
            {
                foreach (Control ctrl in currentBoard.Controls)
                {
                    if (ctrl is Button btn)
                    {
                        indices = SubmarinesUtils.GetButtonIndices(btn);
                        int r = indices[0];
                        int c = indices[1];

                        if (Math.Abs(r - bRow) <= 1 && Math.Abs(c - bCol) <= 1)
                        {
                            orderStepCount += 0.1;
                            RegisterStep(r, c);
                            int subId = currentLocations[r, c];
                            if (HitSquare(btn, r, c))
                            {
                                passTurn = false || CheckAndSink(subId);
                            }
                        }
                    }
                }
            }
            if (gameWon) { return; }

            if (currentWeapon == Weapon.AirStrike) {
                int ASCount = int.Parse(currentAirStrikeCount.Text) - 1;
                currentAirStrikeCount.Text = ASCount.ToString();
                if (ASCount == 0)
                {
                    if (currentPlayer == 1) { depthCharge1_Click(null, EventArgs.Empty); }
                    else { depthCharge2_Click(null, EventArgs.Empty); }
                }
            }

            if (passTurn)
            {
                currentPlayer = currentPlayer == 1 ? 2 : 1;
                AssignControlVariables(currentPlayer);
                labelCurrPlayerNum.Text = currentPlayer.ToString();
                if(currentPlayer == computerPlayer) { computerDelay.Start(); }
            }
            else if (currentPlayer == computerPlayer)
            {
                computerDelay.Start();
            }
        }
        #endregion

        private void labelCurrPlayerNum_TextChanged(object sender, EventArgs e)
        {
            int argb = currentPlayer == 1 ? p1.playerColorArgb : p2.playerColorArgb;
            labelCurrPlayerNum.ForeColor = Color.FromArgb(argb);
            labelCurrPlayer.ForeColor = Color.FromArgb(argb);
        }

        #region Hitting and Sinking
        private bool HitSquare(Button button, int row, int col)
        {
            if (gameWon || (SquareStates)button.Tag == SquareStates.AlreadyHit) { return false; }
            button.Tag = SquareStates.AlreadyHit;
            button.Enabled = false;
            int value = currentLocations[row,col];
            if (currentLocations[row, col] == 0)
            {
                button.BackColor = SystemColors.Control;
                return false;
            }
            else
            {
                button.BackColor = Color.Red;
                currentLocations[row, col] *= -1;
                if(currentPlayer == computerPlayer) { 
                    computerButtonHits[value] = button;
                }
                return true;
            }
        }

        private bool CheckAndSink(int subId)
        {
            Submarine selectedSub = game.submarines.FirstOrDefault(sub => sub.subId == subId);
            if (selectedSub == null) { return false; }

            int remainingSquares = currentLocations.Cast<int>().Count(val => val == subId);
            bool sunk = selectedSub.IsSunk(dataConnection, remainingSquares);
            if (!sunk) { return false; }
            
            if (currentPlayer == computerPlayer)
            {
                computerButtonHits[subId] = null;
            }

            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b)
                {
                    int[] indices = SubmarinesUtils.GetButtonIndices(b);
                    int r = indices[0];
                    int c = indices[1];

                    if (Math.Abs(currentLocations[r, c]) == subId)
                    {
                        b.Tag = SquareStates.AlreadyHit;
                        b.BackgroundImage = Properties.Resources.DestroyedX;
                        currentLocations[r, c] = -subId;
                    }
                }
            }

            int rmnSubs = int.Parse(currentRemainingSubs.Text) - 1;
            currentRemainingSubs.Text = rmnSubs.ToString();
            if (rmnSubs == 0 && !isContinuedGameInit)
            {
                EndGame();
                return true;
            }

            if (!isContinuedGameInit)
            {
                MessageBox.Show($"שחקן {currentPlayer} הטביע צוללת אויב!", "!הטבעה",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                int ASCount = int.Parse(currentAirStrikeCount.Text) + 1;
                currentAirStrikeCount.Text = ASCount.ToString();
            }
                
            return true;            
        }
        #endregion

        #region Ending the Game
        private void EndGame() {
            
            gameWon = true;
            DateTime endTime = DateTime.Now;
            int minutes = endTime.Subtract(gameStart).Minutes;
            game.AddDurationAndSetSteps(dataConnection, minutes, stepCount);
            DisableBoard(board1);
            DisableBoard(board2);
            depthCharge1.Enabled = false;
            depthCharge2.Enabled = false;
            airStrike1.Enabled = false;
            airStrike2.Enabled = false;
            buttonReveal.Visible = true;
            buttonReveal.BackColor = labelCurrPlayer.ForeColor;
            MessageBox.Show($"שחקן {currentPlayer} הטביע את כל צוללות האויב, הוא המנצח!", "!נצחון", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void DisableBoard(Control dsBoard)
        {
            if (dsBoard.Name.Contains(computerPlayer + "")) { return; }
            foreach (Control c in dsBoard.Controls)
            {
                if (c is Button b) { 
                    b.Enabled = false;
                }
            }
        }

        private void buttonReveal_Click(object sender, EventArgs e)
        {
            buttonReveal.Enabled = false;
            AssignControlVariables(currentPlayer == 1 ? 2 : 1);
            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b && b.BackColor != SystemColors.Control)
                {
                    int[] indices = SubmarinesUtils.GetButtonIndices(b);
                    int r = indices[0];
                    int c = indices[1];

                    if (currentLocations[r,c] != 0)
                    {
                        b.BackgroundImage = Properties.Resources.DestroyedX;
                    }
                }
            }
                      
        }
        #endregion
        
        #region Form closing logic
        private void FormGamePlay_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!gameWon)
            {
                string message = "";
                string s1 = "?המשחק עוד לא נגמר, האם לסגור אותו";
                string s2 = "תמיד ניתן להמשיך אותו דרך תפריט";
                string s3 = "בטופס התפריטים";
                string s4 = "משחק";
                message = $"{s1}\n" +
                          $"{s2} \"{s4}\" {s3}";
                DialogResult res = MessageBox.Show(message,
                    "סגירת משחק לא גמור",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information
                );
                if (res == DialogResult.Yes)
                {
                    PlantUnfinishedGameData();
                    DateTime endTime = DateTime.Now;
                    int minutes = endTime.Subtract(gameStart).Minutes;
                    game.AddDurationAndSetSteps(dataConnection, minutes, stepCount);
                }
                else { e.Cancel = true; }
            }
        }

        private void PlantUnfinishedGameData()
        {
            int currentPlayerIndicator = currentPlayer;
            int ASCount1 = int.Parse(airStrikeCount1.Text);
            ASCount1 = ASCount1 == 0 ? 11 : ASCount1;
            int ASCount2 = int.Parse(airStrikeCount2.Text);
            ASCount2 = ASCount2 == 0 ? 11 : ASCount2;
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT gameTime " +
                                          "FROM tblGames " +
                                          "WHERE gameID = @id";
                datacommand.Parameters.AddWithValue("@id", game.gameId);
                DateTime gameTime = (DateTime)datacommand.ExecuteScalar();

                TimeSpan time = gameTime.TimeOfDay;
                DateTime plantedDateTime = new DateTime(2000 + currentPlayerIndicator, ASCount1, ASCount2,
                    time.Hours, time.Minutes, time.Seconds);

                datacommand.CommandText = "UPDATE tblGames " +
                                           "SET gameTime = @dateTime " +
                                           "WHERE gameID = @id";
                datacommand.Parameters.Clear();
                datacommand.Parameters.AddWithValue("@dateTime", plantedDateTime);
                datacommand.Parameters.AddWithValue("@id", game.gameId);
                datacommand.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("Planting unfinished game data failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }        

        private void FormGamePlay_FormClosed(object sender, FormClosedEventArgs e)
        {
            SubmarinesUtils.mainGameFormOpen = false;
            FormMenu menu = Application.OpenForms.OfType<FormMenu>().FirstOrDefault();

            if (menu != null)
            {
                menu.Show();
                menu.Activate();
            }            
        }

        #endregion

        private void FormGamePlay_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }        
        private void helpButton_Click(object sender, EventArgs e)
        {
            FormHelpGamePlay helpGamePlay = new FormHelpGamePlay(); 
            helpGamePlay.Height = panel1.Height;
            helpGamePlay.Show();
        }
    }
}
