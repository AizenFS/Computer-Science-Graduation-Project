﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormSearchOrganizations : Submarines.FormBaseSearch
    {
        private OleDbConnection dataConnection;
        public FormSearchOrganizations(OleDbConnection dataConnection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.dataConnection = dataConnection;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM  tblOrganization WHERE " +
                                           "orgName            LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgAddress         LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgCityID          LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgDirectorID      LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgPicture         LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgPicturesFolder  LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgClip            LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "orgSite            LIKE \"%" + searchStr.Text + "%\"     " ;
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                if (tbl.Rows.Count == 0)
                {
                    MessageBox.Show("לא נמצאו התאמות", "לא נמצא",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    dataGridView1.DataSource = tbl;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Search tblOrganization failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblOrganization";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh tblOrganization table failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormSearchOrganizations_Load(object sender, EventArgs e)
        {
            this.tblOrganizationTableAdapter.Fill(this.dataSetOrganization.tblOrganization);

        }

        private void FormSearchOrganizations_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
