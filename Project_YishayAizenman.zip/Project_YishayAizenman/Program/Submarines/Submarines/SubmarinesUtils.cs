﻿using System;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Submarines
{
    public static class SubmarinesUtils      
    {
        public static bool mainGameFormOpen = false;      
        
        public static string StringRightToLeft(string leftToRight)
        {
            return $"\u200F{leftToRight}";
        }

        public static int GetIdFromDetails(string details)
        {
            string safeDetails = details ?? "-1";
            string n = details.Split(',')[0];
            return n.Equals("All") || n.Equals("None") ? 0 : int.Parse(n);
        }

        public static string GetDetailsFromID(DataGridView dataGrid, ComboBox combo, int cellIndex)
        {
            string id = dataGrid.SelectedRows[0].Cells[cellIndex].Value.ToString();
            for (int i = 0; i < combo.Items.Count; i++)
            {
                if (combo.Items[i].ToString().Split(',')[0].Equals(id))
                {
                    return combo.Items[i].ToString();
                }
            }
            return "isn't in databse";
        }

        public static void SetDataGridViewTimeFormat(System.Windows.Forms.DataGridView dataGridView, int colIndex)
        {
            if (dataGridView.Rows.Count != 0)
            {
                dataGridView.Columns[colIndex].DefaultCellStyle.Format = "HH:mm:ss";
            }
        }       

        public static int[] GetButtonIndices(Button btn)
        {
            string[] btnNameSplit = btn.Name.Split('_');
            string iS = btnNameSplit.Length == 4 ? btnNameSplit[2] : btnNameSplit[1];
            string jS = btnNameSplit.Length == 4 ? btnNameSplit[3] : btnNameSplit[2];
            int i = iS != "00" ? int.Parse(iS.TrimStart('0')) : 0;
            int j = jS != "00" ? int.Parse(jS.TrimStart('0')) : 0;
            return new int[] { i, j };
        }

        public static bool IsSubArrCompact(int[,] subArr)
        {
            int r = subArr.GetLength(0);
            int c = subArr.GetLength(1);

            return ContainsOneInColumn(c - 1, subArr) && ContainsOneInColumn(0, subArr)
                && ContainsOneInRow(r - 1, subArr) && ContainsOneInRow(0, subArr);
        }

        public static int[,] ShrinkArray(int[,] array)
        {
            int rows = array.GetLength(0);
            int cols = array.GetLength(1);

            int top = -1, bottom = -1, left = -1, right = -1;

            for (int i = 0; i < rows; i++)
            {
                if (ContainsOneInRow(i, array))
                {
                    top = i;
                    break;
                }
            }

            for (int i = rows - 1; i >= 0; i--)
            {
                if (ContainsOneInRow(i, array))
                {
                    bottom = i;
                    break;
                }
            }

            for (int j = 0; j < cols; j++)
            {
                if (ContainsOneInColumn(j, array))
                {
                    left = j;
                    break;
                }
            }

            for (int j = cols - 1; j >= 0; j--)
            {
                if (ContainsOneInColumn(j,array))
                {
                    right = j;
                    break;
                }
            }

            int newRows = bottom - top + 1;
            int newCols = right - left + 1;
            int[,] newArray = new int[newRows, newCols];

            for (int i = 0; i < newRows; i++)
            {
                for (int j = 0; j < newCols; j++)
                {
                    newArray[i, j] = array[top + i, left + j];
                }
            }

            return newArray;               
        }

        private static bool ContainsOneInRow(int row, int[,] array)
        {
            int cols = array.GetLength(1);
            for (int j = 0; j < cols; j++)
            {
                if (array[row, j] == 1)
                {
                    return true;
                }
            }
            return false;
        }

        private static bool ContainsOneInColumn(int col, int[,] array)
        {
            int rows = array.GetLength(0);
            for (int i = 0; i < rows; i++)
            {
                if (array[i, col] == 1)
                {
                    return true;
                }
            }
            return false;
        }

        public static string Get2DArrayString(int[,] array)
        {
            string message = "";
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    message += array[i, j] + "   ";
                }
                message += "\n";
            }
            return message;
        }

        public static void Copy2dArray(int[,] source, int[,] destination)
        {
            for(int i = 0;i < source.GetLength(0); i++)
            {
                for(int j = 0;j < source.GetLength(1); j++)
                {
                    destination[i,j] = source[i,j];
                }               
            }
        }

        public static class GlobalOrgData
        {
            public static string orgImageLocation { get; private set; } = "";
            public static string orgWebAddress { get; private set; } = "";
            public static string orgFolder { get; private set; } = "";
            public static string orgVidLocation { get; private set; } = "";

            public static void UpdateFromDB(OleDbConnection dataConnection)
            {
                try
                {
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = dataConnection;
                    command.CommandText = "SELECT orgPicture, orgPicturesFolder, orgClip, orgSite " +
                                          "FROM tblOrganization";
                    OleDbDataReader dataReader = command.ExecuteReader();
                    if (dataReader.Read())
                    {
                        orgImageLocation = dataReader.GetString(0);
                        orgFolder = dataReader.GetString(1);
                        orgVidLocation = dataReader.GetString(2);
                        orgWebAddress = dataReader.GetString(3);
                    }
                    else
                    {
                        throw new Exception("no data detected in organization table");
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show("Load organization data from database failed \n" + err.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public class GameBoardCreator
        {
            private int BUTTON_SIZE = Properties.Settings.Default.ButtonSideLength;
            private int BUTTON_MARGIN = Properties.Settings.Default.ButtonMargin;
            private Color DEFAULT_COLOR1 = Properties.Settings.Default.DefaultButtonColor1;
            private Color DEFAULT_COLOR2 = Properties.Settings.Default.DefaultButtonColor2;
            public delegate void AssignButtonEvents(Button button);

            private SubmarinesDataStructures.Game game;
            private readonly AssignButtonEvents assignButtonEvents;
            private bool useDefaultButtonColor;
            private object defaultTag;

            private int computerPlayer;
           

            public GameBoardCreator(SubmarinesDataStructures.Game game,
                AssignButtonEvents assignButtonEvents, bool useDefaultButtonColor, object defaultTag = null)
            {
                this.game = game;
                this.assignButtonEvents = assignButtonEvents;
                this.useDefaultButtonColor = useDefaultButtonColor;
                this.defaultTag = defaultTag;

                if (game.player1.isComputer) { computerPlayer = 1; }
                if (game.player2.isComputer) { computerPlayer = 2; }
            }

            public void CreateBoard(Panel board)
            {
                foreach (Control ctrl in board.Controls)
                {
                    if (ctrl is Button button) { button.Dispose(); }
                }

                int rows = game.boardRows;
                int cols = game.boardCols;

                int offsetX = (board.Width - CalculateTotalWidth(cols)) / 2;
                int offsetY = (board.Height - CalculateTotalHeight(rows)) / 2;

                for (int i = 0; i < rows; i++)
                    for (int j = 0; j < cols; j++)
                        AddButton(board, i, j, offsetX, offsetY);

            }

            private int CalculateTotalWidth(int cols) => cols * BUTTON_SIZE + (cols - 1) * BUTTON_MARGIN;
            private int CalculateTotalHeight(int rows) => rows * BUTTON_SIZE + (rows - 1) * BUTTON_MARGIN;

            private void AddButton(Panel board, int i, int j, int offsetX, int offsetY)
            {
                int sizeUnit = BUTTON_SIZE + BUTTON_MARGIN;
                var button = new Button
                {
                    Name = $"btn_{board.Name}_{i:D2}_{j:D2}",
                    Size = new Size(BUTTON_SIZE, BUTTON_SIZE),
                    Location = new Point(offsetX + j * sizeUnit, offsetY + i * sizeUnit),
                    UseVisualStyleBackColor = false,
                    Enabled = !board.Name.Contains(computerPlayer.ToString()),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = GetButtonColor(i),
                    BackgroundImageLayout = ImageLayout.Stretch,
                    Tag = defaultTag,
                    TabStop = false
                };

                button.FlatAppearance.BorderColor = Color.White;
                button.FlatAppearance.BorderSize = 1;

                assignButtonEvents(button);

                board.Controls.Add(button);
            }

            private Color GetButtonColor(int row)
            {
                if (useDefaultButtonColor) { return SystemColors.Control; }
                return (row % 2 == 0) ? DEFAULT_COLOR1 : DEFAULT_COLOR2;
            }

        }
    }
}
