﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormAddSubmarine : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        public FormAddSubmarine(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
        }

        private void FormAddSubmarine_Load(object sender, EventArgs e)
        {
            this.tblSubmarinesTableAdapter.Fill(this.dataSetSubmarines.tblSubmarines);
            dataGridView1.AllowUserToAddRows = false;

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!Validations.ValidName(subName.Text))
            {
                MessageBox.Show("השם שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Validations.Exist(dataConnection, "tblSubmarines", "subName", subName.Text))
            {
                MessageBox.Show("שם הצוללת הנבחר כבר קיים במסד הנתונים", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblSubmarines " +
                    "(subRows, subCols, subName, subSinkPercent) " +
                    "VALUES ({0}, {1}, \"{2}\", {3})",
                    int.Parse(rows.Text),
                    int.Parse(cols.Text),
                    subName.Text,
                    int.Parse(sinkPercent.Text));

                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblSubmarines ended successfully");
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblSubmarines failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM tblSubmarines ";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddSubmarine_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
