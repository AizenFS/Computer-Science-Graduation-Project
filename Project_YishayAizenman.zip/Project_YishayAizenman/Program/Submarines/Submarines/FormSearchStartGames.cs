﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormSearchStartGames : Submarines.FormBaseSearch
    {
        private OleDbConnection dataConnection;
        public FormSearchStartGames(OleDbConnection dataConnection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.dataConnection = dataConnection;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM  tblStartGames WHERE " +
                                           "startGameID   LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "startOrderNum LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "startSubID    LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "startRow1     LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "startCol1     LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "startRow2     LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "startCol2     LIKE \"%" + searchStr.Text + "%\"     " +
                                     "ORDER BY StartGameID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                if (tbl.Rows.Count == 0)
                {
                    MessageBox.Show("לא נמצאו התאמות", "לא נמצא", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    dataGridView1.DataSource = tbl;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Search tblStartGames failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblStartGames " +
                                     "ORDER BY StartGameID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh tblStartGames table failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormSearchStartGames_Load(object sender, EventArgs e)
        {
            this.tblStartGamesTableAdapter.Fill(this.dataSetStartGames.tblStartGames);

        }

        private void FormSearchStartGames_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
