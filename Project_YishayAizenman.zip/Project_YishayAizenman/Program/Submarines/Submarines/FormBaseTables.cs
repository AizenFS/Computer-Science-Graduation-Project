﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormBaseTables : Form
    {
        public FormBaseTables()
        {
            InitializeComponent();
            this.Icon = Properties.Resources.AppIcon;
            picLogo.ImageLocation = SubmarinesUtils.GlobalOrgData.orgImageLocation;
        }
        public Color GetColor()
        {
            return BackColor;
        }

        private void picLogo_Click(object sender, EventArgs e)
        {
            Process.Start(SubmarinesUtils.GlobalOrgData.orgWebAddress);
        }
    }
}
