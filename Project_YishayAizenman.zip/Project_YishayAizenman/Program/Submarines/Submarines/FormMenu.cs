﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormMenu : Form
    {
        private OleDbConnection dataConnection;
        private Player player;
        public FormMenu(OleDbConnection dataConnection, Player player, bool isManager)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.Icon = Properties.Resources.AppIcon;

            this.dataConnection = dataConnection;
            this.player = player;

            if (!isManager)
            {
                DisableManagerControls();
            }
            PaintMenuItems();
        }

        private void DisableManagerControls()
        {
            tablesMenu.Enabled = false;
            addMenu.Enabled = false;
            updateMenu.Enabled = false;
            subMenu.Enabled = false;

            labelManager.Visible = false;
            btnAddSub.Visible = false;
            btnUpdateSub.Visible = false;
        }

        private void PaintMenuItems()
        {
            FormBaseTables frm1 = new FormBaseTables();
            tablesMenu.BackColor = frm1.GetColor();

            FormBaseAdd frm2 = new FormBaseAdd();
            addMenu.BackColor = frm2.GetColor();

            FormBaseUpdate frm3 = new FormBaseUpdate();
            updateMenu.BackColor = frm3.GetColor();

            FormBaseReport frm4 = new FormBaseReport();
            reportsMenu.BackColor = frm4.GetColor();

            FormBaseCharts frm5 = new FormBaseCharts();
            chartsMenu.BackColor = frm5.GetColor();

            FormBaseSearch frm6 = new FormBaseSearch();
            searchMenu.BackColor = frm6.GetColor();

            FormBaseSubmarine frm7 = new FormBaseSubmarine();
            subMenu.BackColor = frm7.GetColor();

            FormBaseGame frm8 = new FormBaseGame();
            gameMenu.BackColor = frm8.GetColor();
        }

        private void FormMenu_Shown(object sender, EventArgs e)
        {
            picBoxLogo.ImageLocation = SubmarinesUtils.GlobalOrgData.orgImageLocation;
            playerNameAndPic1.UpdateProperties(player, dataConnection);            
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            newGameDropDown_Click(null, EventArgs.Empty);
        }

        private void btnContinueGame_Click(object sender, EventArgs e)
        {
            continueGameDropDown_Click(null, EventArgs.Empty);
        }

        private void btnReplayGame_Click(object sender, EventArgs e)
        {
            replayGameDropDown_Click(null, EventArgs.Empty);
        }

        private void btnAddSub_Click(object sender, EventArgs e)
        {
            subCreateDropDown_Click(null, EventArgs.Empty);
        }

        private void btnUpdateSub_Click(object sender, EventArgs e)
        {
            submarineFixDropDown_Click(null, EventArgs.Empty);
        }

        private void picBoxLogo_Click(object sender, EventArgs e)
        {
            Process.Start(SubmarinesUtils.GlobalOrgData.orgWebAddress);
        }

        void Form_Disposed(object sender, EventArgs e)
        {                       
            this.Show();
            this.Activate();
        }

        private void gamesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblGames frm = new FormTblGames();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void stepsDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblSteps frm = new FormTblSteps();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void submarinesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblSubmarines frm = new FormTblSubmarines();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void markedSquaresDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblMarkedSquares frm = new FormTblMarkedSquares();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void cityDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblCities frm = new FormTblCities();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void organizationDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblOrganization frm = new FormTblOrganization();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void playersDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblPlayers frm = new FormTblPlayers();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void startGamesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTblStartGames frm = new FormTblStartGames();
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addPlayerDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddPlayer frm = new FormAddPlayer(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddGame frm = new FormAddGame(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addStartGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddStartGame frm = new FormAddStartGame(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addMarkedSquareDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddMarkedSquare frm = new FormAddMarkedSquare(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addCityDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddCity frm = new FormAddCity(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addSubmarinesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddSubmarine frm = new FormAddSubmarine(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addStepDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddStep frm = new FormAddStep(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void addOrganizationDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddOrganization frm = new FormAddOrganization(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updatePlayerDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdatePlayer frm = new FormUpdatePlayer(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updateCityDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdateCities frm = new FormUpdateCities(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updateGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdateGame frm = new FormUpdateGame(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updateOrganizationDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdateOrganization frm = new FormUpdateOrganization(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updateStartGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdateStartGame frm = new FormUpdateStartGame(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updateStepsDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdateSteps frm = new FormUpdateSteps(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void updateSubmarinesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormUpdateSubmarines frm = new FormUpdateSubmarines(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptGamesByPlayerDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptGamesByPlayer frm = new FormRptGamesByPlayer(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptGamesByPeriodDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptGamesByPeriod frm = new FormRptGamesByPeriod(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptSubsByGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptSubmarinesInGame frm = new FormRptSubmarinesInGame(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptMarkedSquaresBySubmarinesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptMarkedSquaresBySubmarines frm = new FormRptMarkedSquaresBySubmarines(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptPlayersByCityDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptPlayersByCity frm = new FormRptPlayersByCity(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptSubmarinesByPlayerDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptSubmarinesByPlayer frm = new FormRptSubmarinesByPlayer(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void rptPlayerBySubmarineDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormRptPlayersBySubmarine frm = new FormRptPlayersBySubmarine(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void chartsGamesAmountByPlayerDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormChartGamesByPlayer frm = new FormChartGamesByPlayer(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;

        }

        private void chartSubsPerGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormChartSubmarinesPerGame frm = new FormChartSubmarinesPerGame(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void chartMarkedSquaresPerSubDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormChartMarkedSquaresBySubmarine frm = new FormChartMarkedSquaresBySubmarine(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void chartPlayersPerCityDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormChartPlayersByCity frm = new FormChartPlayersByCity(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void chartSubsPerPlayerDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormChartSubmarinesByPlayer frm = new FormChartSubmarinesByPlayer(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void chartPlayersPerSubDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormChartPlayersBySubmarine frm = new FormChartPlayersBySubmarine(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchPlayersDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchPlayers frm = new FormSearchPlayers(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchGamesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchGames frm = new FormSearchGames(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchCitiesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchCities frm = new FormSearchCities(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchSubmarinesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchSubmarines frm = new FormSearchSubmarines(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchMaekdSquaresDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchMarkedSquares frm = new FormSearchMarkedSquares(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchStepsDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchSteps frm = new FormSearchSteps(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchOrganizationsDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchOrganizations frm = new FormSearchOrganizations(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void searchStartGamesDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSearchStartGames frm = new FormSearchStartGames(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void subCreateDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSubmarineNew frm = new FormSubmarineNew(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void submarineFixDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormSubmarineFix frm = new FormSubmarineFix(dataConnection);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void newGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormGameStart frm = new FormGameStart(dataConnection);
            frm.Show();
            frm.Disposed += FormStartGame_Disposed;
        }

        private void continueGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormGameSelect frm = new FormGameSelect(dataConnection, FormGameSelect.NextForm.ContinueGame);
            frm.Show();
            frm.FormClosed += FormStartGame_Disposed;
        }

        private void replayGameDropDown_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormGameSelect frm = new FormGameSelect(dataConnection, FormGameSelect.NextForm.ReplayGame);
            frm.Show();
            frm.FormClosed += Form_Disposed;
        }

        private void FormStartGame_Disposed(object sender, EventArgs e)
        {
            if (!SubmarinesUtils.mainGameFormOpen)
            {
                this.Show();
                this.Activate();
            }
        }

        private void FormMenu_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
