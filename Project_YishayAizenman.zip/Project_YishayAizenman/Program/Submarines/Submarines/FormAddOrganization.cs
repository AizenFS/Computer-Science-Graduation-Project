﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AForge.Video.DirectShow;

namespace Submarines
{
    public partial class FormAddOrganization : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        private Timer picsDirectoryTimer;
        private string[] picFileTypes = { "*.jpg", "*.jpeg", "*.png", "*.bmp" };
        private string[] pics;
        int index;

        public FormAddOrganization(OleDbConnection dataConnection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

            this.dataConnection = dataConnection;

            picsDirectoryTimer = new Timer();
            picsDirectoryTimer.Interval = 300;
            picsDirectoryTimer.Tick += PicsDirectoryTimer_Tick;

            wmp.stretchToFit = true;

            FillCityCombo();
            FillManagerCombo();         
        }

        private void FillCityCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT cityID, cityName " +
                                          "FROM tblCities " +
                                          "ORDER BY cityID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    comboCity.Items.Add(dataReader.GetInt32(0).ToString()+", "+dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill cities combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillManagerCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerID, playerFirstName, playerLastName " +
                                          "FROM tblPlayers " +
                                          "ORDER BY playerID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    comboManager.Items.Add(dataReader.GetInt32(0).ToString() + ", " +
                        dataReader.GetString(1) + " "+ dataReader.GetString(2));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill manager combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void FormAddOrganization_Load(object sender, EventArgs e)
        {
            this.tblOrganizationTableAdapter.Fill(this.dataSetOrganization.tblOrganization);
            dataGridView1.AllowUserToAddRows = false;
        }

        private void btnBrowsePic_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = picFileDialog.ShowDialog();
            string pictureFileName = picFileDialog.FileName;
            pictureLocation.Text = pictureFileName;
        }
        private void btnShowPic_Click(object sender, EventArgs e)
        {
            if(pictureLocation.Text == "") {
                MessageBox.Show("לא נבחר קובץ", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            wmp.Ctlcontrols.stop();
            wmp.Visible = false;
            pictureBox1.Visible = true;
            picsDirectoryTimer.Stop();
            try
            {
                Image image = Image.FromFile(pictureLocation.Text);
                pictureBox1.Image = image;
            }
            catch (Exception err)
            {
                MessageBox.Show("Error in showing the Organization picture: \n" + err.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBrowseFldr_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = folderDialog.ShowDialog();
            string picturesFolderName = folderDialog.SelectedPath;
            folderLocation.Text = picturesFolderName;
        }
        private void btnShowDir_Click(object sender, EventArgs e)
        {
            if (folderLocation.Text == "")
            {
                MessageBox.Show("לא נבחרה תיקייה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            wmp.Ctlcontrols.stop();
            wmp.Visible = false;
            pictureBox1.Visible = true;
            pictureBox1.Image = null;
            try
            {
                pics = picFileTypes.SelectMany(
                    fileType => Directory.GetFiles(folderLocation.Text, fileType)).ToArray();
                index = 0;
                picsDirectoryTimer.Start();
            }
            catch (Exception err)
            {
                MessageBox.Show("Error in showing the Organization Pictures folder: \n" + err.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void PicsDirectoryTimer_Tick(object sender, EventArgs e)
        {
            if (index >= pics.Length)
            {
                picsDirectoryTimer.Stop();
                return;
            }
            try
            {
                pictureBox1.Image = Image.FromFile(pics[index++]);
            }
            catch (Exception err)
            {
                MessageBox.Show("Error in showing a picture in the Organization Pictures folder: \n" + err.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBrowseVid_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = vidFileDialog.ShowDialog();
            string vidFileName = vidFileDialog.FileName;
            vidLocation.Text = vidFileName;
        }
        private void btnShowVid_Click(object sender, EventArgs e)
        {
            if (vidLocation.Text == "")
            {
                MessageBox.Show("לא נבחר קובץ", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            picsDirectoryTimer.Stop();
            pictureBox1.Visible = false;
            wmp.Visible = true;
            try
            {
                wmp.URL = vidLocation.Text;
                wmp.Ctlcontrols.play();
            }
            catch (Exception err)
            {
                MessageBox.Show("Error in showing the Organization video: \n" + err.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOpenSite_Click(object sender, EventArgs e)
        {
            Process.Start(siteAddress.Text);
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {      
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblOrganization" +
                    "(orgName, orgAddress, orgCityID, orgDirectorID, orgPicture, orgPicturesFolder, orgClip) " +
                    "VALUES (\"{0}\", \"{1}\", {2}, {3}, \"{4}\", \"{5}\", \"{6}\")",
                    orgName.Text,addressBox.Text, SubmarinesUtils.GetIdFromDetails(comboCity.Text),
                    SubmarinesUtils.GetIdFromDetails(comboCity.Text), pictureLocation.Text,folderLocation.Text,
                    vidLocation.Text);
                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblOrganization ended successfully",
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblOrganization failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM tblOrganization";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddOrganization_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
        private void FormAddOrganization_FormClosed(object sender, FormClosedEventArgs e)
        {
            wmp.Ctlcontrols.stop();            
        }
    }
}
