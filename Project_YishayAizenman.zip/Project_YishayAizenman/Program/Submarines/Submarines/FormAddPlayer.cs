﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormAddPlayer : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        public FormAddPlayer(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillCityCombo();
        }

        private void FormAddPlayer_Load(object sender, EventArgs e)
        {
            this.tblPlayersTableAdapter.Fill(this.dataSetPlayers.tblPlayers);
            dataGridView1.AllowUserToAddRows = false;

        }

        private void FillCityCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT cityID, cityName " +
                                          "FROM tblCities " +
                                          "ORDER BY cityID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    comboCity.Items.Add(dataReader.GetInt32(0).ToString()+", "+dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill cities combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = openFileDialog1.ShowDialog();
            string pictureFileName = openFileDialog1.FileName;
            pictureBox1.ImageLocation = pictureFileName;
            pictureLocation.Text = pictureFileName;
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            string fileName = ShowSelfieDialog();
            if (!string.IsNullOrEmpty(fileName))
            {
                pictureLocation.Text = fileName;
                pictureBox1.Image = Image.FromFile(fileName);
            }
        }

        private string ShowSelfieDialog()
        {
            using (FormCaptureSelfie captureDialog = new FormCaptureSelfie())
            {
                captureDialog.Height = 1000;
                if (captureDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    return captureDialog.saveFileName;
                }
                else { return null; }
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!Validations.ValidID(idBox.Text))
            {
                MessageBox.Show("תעודת הזהות שנבחרה לא חוקית", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!Validations.ValidMail(mailBox.Text))
            {
                MessageBox.Show("כתובת המייל שנבחרה לא חוקית", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!Validations.ValidName(firstNameBox.Text) || !Validations.ValidName(lastNameBox.Text))
            {
                MessageBox.Show("השם שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!Validations.ValidPhone(phoneBox.Text))
            {
                MessageBox.Show("מספר הטלפון שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblPlayers " +
                    "(playerID, playerFirstName, playerLastName, playerAddress, playerCityID, playerPassword," +
                    "   playerIsManager, playerIsActive, playerPhone, playerMail, playerPicture) " +
                    "VALUES ({0}, \"{1}\", \"{2}\", \"{3}\", {4}, \"{5}\", {6}, {7}, \"{8}\", \"{9}\", \"{10}\")",
                    idBox.Text,firstNameBox.Text,lastNameBox.Text,addressBox.Text,
                    SubmarinesUtils.GetIdFromDetails(comboCity.Text), passwordBox.Text,isManager.Checked,
                    isActive.Checked,phoneBox.Text,mailBox.Text,pictureLocation.Text);
                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblPlayers ended successfully");
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblPlayers failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblPlayers " +
                                     "ORDER BY PlayerID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddPlayer_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}