﻿using System;
using System.Collections;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormRptSubmarinesInGame : Submarines.FormBaseReport
    {
        private OleDbConnection dataConnection;
        private string saveColor = "";

        public FormRptSubmarinesInGame(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillGameIdCombo();
            listView1.FullRowSelect = true;
        }

        private void FillGameIdCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT g.gameID, g.gameDate, " +
                                             "p1.playerFirstName + ' ' + p1.playerLastName AS Player1Name, " +
                                             "p2.playerFirstName + ' ' + p2.playerLastName AS Player2Name " +
                                          "FROM (tblGames g " +
                                          "LEFT JOIN tblPlayers p1 ON g.gamePlayer1ID = p1.playerID) " +
                                          "LEFT JOIN tblPlayers p2 ON g.gamePlayer2ID = p2.playerID " +
                                          "ORDER BY g.gameID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    int gameID = dataReader.GetInt32(0);
                    string gameDate = dataReader.GetDateTime(1).ToString("yyyy-MM-dd");
                    string player1Name = dataReader.GetString(2);
                    string player2Name = dataReader.GetString(3);

                    string comboItem = $"{gameID}, {gameDate}, {player1Name} נגד {player2Name}";
                    gameId.Items.Add(comboItem);
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill game ID combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #region Button events
        private void buttonShow_Click(object sender, EventArgs e)
        {
            EditListView(GetGameSubmarinesDetails());
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            gameId.Text = "";
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            buttonColor.ForeColor = cd.Color;
            saveColor = buttonColor.ForeColor.ToArgb().ToString();
        }
        #endregion

        #region Report logic
        private ArrayList GetGameSubmarinesDetails()
        {
            try
            {
                ArrayList list = new ArrayList();
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "SELECT sg.startGameID, s.* , sg.startOrderNum, sg.startSubID, sg.startRow1, sg.startCol1," +
                    "   sg.startRow2, sg.startCol2 " +
                    "FROM tblSubmarines AS s " +
                    "INNER JOIN tblStartGames AS sg " +
                    "ON s.subID = sg.startSubID " +
                    "WHERE sg.startGameID = @gameID " +
                    "ORDER BY sg.startOrderNum";
                datacommand.Parameters.AddWithValue("@gameID", SubmarinesUtils.GetIdFromDetails(gameId.Text));
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    string[] values = new string[12];
                    for (int i = 0; i < values.Length; i++)
                    {
                        if (i == 4)
                        {
                            values[i] = dataReader.GetString(i);
                        }
                        else
                        {
                            values[i] = dataReader.GetInt32(i).ToString();
                        }
                    }
                    list.Add(values);
                }
                dataReader.Close();
                return list;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get game details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return new ArrayList();
            }
        }

        private void EditListView(ArrayList list)
        {
            try
            {                
                if (!(list.Count == 0))
                {
                    string PrevSubID = ".";
                    foreach (string[] arr in list)
                    {
                        string currentSubID = arr[1];
                        if (currentSubID.Equals(PrevSubID))
                        {
                            for (int i = 0; i < 6; i++)
                            {
                                arr[i] = "";
                            }
                        }
                        else
                        {
                            PrevSubID = currentSubID;
                        }
                        ListViewItem item = new ListViewItem(arr);
                        if (saveColor != "")
                            item.ForeColor = Color.FromArgb(int.Parse(saveColor));
                        listView1.Items.Add(item);
                        
                    }
                }
                else
                {
                    MessageBox.Show("לא נמצאו צוללות במשחק הנבחר.", "לא נמצאו צוללות",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit listview failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        private void FormRptSubmarinesInGame_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
