﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormHelpSubFix : Submarines.FormBaseHelp
    {
        public FormHelpSubFix()
        {
            InitializeComponent();
        }
    }
}
