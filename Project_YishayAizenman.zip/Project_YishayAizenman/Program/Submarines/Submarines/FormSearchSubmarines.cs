﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormSearchSubmarines : Submarines.FormBaseSearch
    {
        private OleDbConnection dataConnection;
        public FormSearchSubmarines(OleDbConnection dataConnection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.dataConnection = dataConnection;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM  tblSubmarines WHERE " +
                                           "subID          LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "subRows        LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "subCols        LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "subName        LIKE \"%" + searchStr.Text + "%\"  OR " +
                                           "subSinkPercent LIKE \"%" + searchStr.Text + "%\"     " +
                                     "ORDER BY subID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                if (tbl.Rows.Count == 0)
                {
                    MessageBox.Show("לא נמצאו התאמות", "לא נמצא", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    dataGridView1.DataSource = tbl;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Search tblSubmarines failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void refreshButton_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblSubmarines " +
                                     "ORDER BY subID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh tblSubmarines table failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormSearchSubmarines_Load(object sender, EventArgs e)
        {
            this.tblSubmarinesTableAdapter.Fill(this.dataSetSubmarines.tblSubmarines);

        }

        private void FormSearchSubmarines_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
