﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormUpdateSubmarines : Submarines.FormBaseUpdate
    {
        OleDbConnection dataConnection;
        private int lastRow = 0;
        private string selectedSubName;

        public FormUpdateSubmarines(OleDbConnection dataConnection)
        {
            this.dataConnection = dataConnection;
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            RefreshDataGridView();
            dataGridView1.Rows[0].Selected = true;
            FillSelectedRow();
        }

        private void FormUpdateSubmarines_Load(object sender, EventArgs e)
        {
            this.tblSubmarinesTableAdapter.Fill(this.dataSetSubmarines.tblSubmarines);
        }

        private void FillSelectedRow()
        {
            try
            {
                subId.Text       = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                rows.Text        = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                cols.Text        = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                subName.Text     = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                sinkPercent.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();

                selectedSubName = subName.Text;
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                EnableButtons();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill Selected Row failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            
            if (!Validations.ValidName(subName.Text))
            {
                MessageBox.Show("השם שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            if (subName.Text != selectedSubName && 
                Validations.Exist(dataConnection, "tblSubmarines", "subName", subName.Text))
            {
                MessageBox.Show("שם הצוללת הנבחר כבר קיים במסד הנתונים",
                    "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {                
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = 
                    "UPDATE tblSubmarines \n" +
                    "SET    subRows         =   " + rows.Text        + "   , " +
                            "subCols        =   " + cols.Text        + "   , " +
                            "subName        = \"" + subName.Text     + "\" , " +
                            "subSinkPercent =   " + sinkPercent.Text + "     " +
                    "WHERE  subID = " + subId.Text;
                datacommand.ExecuteNonQuery();
                RefreshDataGridView();
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                MessageBox.Show("Update tblSubmarines ended successfluly");
            }
            catch (Exception err)
            {
                MessageBox.Show("Update tblSubmarines failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT    * " +
                                    "FROM     tblSubmarines " +
                                    "ORDER BY subID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EnableButtons()
        {
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            if (lastRow == 0)
                buttonPrev.Enabled = false;
            if (lastRow == dataGridView1.Rows.Count - 1)
                buttonNext.Enabled = false;
        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = 0;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow++;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = dataGridView1.Rows.Count - 1;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow--;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lastRow = dataGridView1.CurrentRow.Index;
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            FillSelectedRow();
        }

        private void FormUpdateSubmarines_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
