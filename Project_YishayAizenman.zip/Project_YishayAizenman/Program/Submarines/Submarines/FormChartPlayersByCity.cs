﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormChartPlayersByCity : Submarines.FormBaseCharts
    {
        private OleDbConnection dataConnection;
        private int counter;
        private string[] arrCities;
        private int[] arrCounts;

        public FormChartPlayersByCity(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            CountCities();
            arrCities = new string[counter];
            arrCounts = new int[counter];
            FillArrCities();
            FillArrCounts();
            ShowChart();
            EditDataGridView();
        }

        private void CountCities()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT   COUNT(*) " +
                                          "FROM     tblCities";
                counter = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Count tblCities failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrCities()
        {
            try
            {
                int k = 0;
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT cityID, cityName " +
                                          "FROM tblCities " +
                                          "ORDER BY cityID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    arrCities[k] = dataReader.GetInt32(0) + ", " + dataReader.GetString(1);
                    k++;
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select tblCities failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrCounts()
        {
            for (int idx = 0; idx < arrCities.Length; idx++)
                CountPlayers(idx);
        }

        private void CountPlayers(int idx)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT COUNT(*) " +
                                          "FROM tblPlayers " +
                                          "WHERE playerCityID = @cityID";
                datacommand.Parameters.AddWithValue("@cityID", SubmarinesUtils.GetIdFromDetails(arrCities[idx]));
                arrCounts[idx] = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("count players failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ShowChart()
        {
            try
            {
                chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -45;

                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoom(1, 10);
                chart1.ChartAreas["ChartArea1"].CursorX.IsUserSelectionEnabled = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoomable = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.Title = "מספר שחקנים";
                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                chart1.ChartAreas["ChartArea1"].AxisY.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.Interval = 1;
                chart1.ChartAreas["ChartArea1"].AxisX.Title = "ערים";

                chart1.Legends.Clear();
                chart1.Series.Clear();
                chart1.Series.Add("נתונים");


                for (int i = 0; i < arrCities.Length; i++)
                {
                    chart1.Series["נתונים"].Points.AddXY(
                        SubmarinesUtils.StringRightToLeft(arrCities[i]), arrCounts[i]);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Show chart failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EditDataGridView()
        {
            try
            {
                for (int i = 0; i < arrCities.Length; i++)
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
                    row.Cells[0].Value = arrCities[i];
                    row.Cells[1].Value = arrCounts[i].ToString();
                    dataGridView1.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit gridview item failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormChartPlayersByCity_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
