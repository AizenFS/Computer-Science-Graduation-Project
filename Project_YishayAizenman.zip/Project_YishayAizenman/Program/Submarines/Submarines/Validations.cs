﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Submarines
{
    internal class Validations
    {
        public static bool ValidID(string id)
        {
            if (id.Length > 9 || !int.TryParse(id, out _))
                return false;

            int[] arr = new int[9];
            int k = 8;
            int sum = 0;


            for (int i = id.Length - 1; i >= 0; i--)
            {
                arr[k] = id[i] - '0';
                k--;
            }
            for (int i = 1; i < 9; i = i + 2)
            {
                arr[i] = arr[i] * 2;
                arr[i] = arr[i] / 10 + arr[i] % 10;
                sum = sum + arr[i] + arr[i - 1];
            }

            int checksum = sum / 10 * 10;
            if (checksum < sum)
                checksum += 10;
            checksum -= sum;
            return arr[8] == checksum;
        }

        public static bool ValidMail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(email, pattern);
        }

        public static bool ValidName(string name) {
            string Pattern = "^(?=.{2,})[א-תA-Za-z](?:['׳]?[א-תA-Za-z]+)*" +
                              "(?:\\s[א-תA-Za-z](?:['׳]?[א-תA-Za-z]+)*)*$";
            return Regex.IsMatch(name, Pattern);
        }

        public static bool ValidPhone(string phone)
        {
            return Regex.IsMatch(phone, "^[1-9]\\d{6}$") ||       // 1234567
                   Regex.IsMatch(phone, @"^0[1-9][1-9]\d{6}$") ||       // 031234567
                   Regex.IsMatch(phone, @"^0[1-9]-[1-9]\d{6}$") ||       // 03-1234567
                   Regex.IsMatch(phone, @"^0[1-9]\d[1-9]\d{6}$") ||       // 0521234567
                   Regex.IsMatch(phone, @"^0[1-9]\d-[1-9]\d{6}$") ||       // 052-1234567
                   Regex.IsMatch(phone, @"^\+(?:[0-9]{1,3})[0-9]{6,14}$"); // +972526789123
        }

        public static bool Exist(OleDbConnection dataConnection, string table, string field, object value)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT COUNT(*) " +
                                          $"FROM {table} " +
                                          $"WHERE {field} = val";
                datacommand.Parameters.AddWithValue("val", value);
                int i = (int)datacommand.ExecuteScalar();
                return i > 0;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}
