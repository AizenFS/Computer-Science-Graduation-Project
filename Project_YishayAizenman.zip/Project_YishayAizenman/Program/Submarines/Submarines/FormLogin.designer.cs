﻿namespace Submarines
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            this.labelID = new System.Windows.Forms.Label();
            this.labelPassword = new System.Windows.Forms.Label();
            this.loginID = new System.Windows.Forms.TextBox();
            this.loginPassword = new System.Windows.Forms.TextBox();
            this.loginEnter = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.wmp = new AxWMPLib.AxWindowsMediaPlayer();
            this.picBoxFolder = new System.Windows.Forms.PictureBox();
            this.playerNameAndPic1 = new Submarines.playerNameAndPic();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFolder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelID.Location = new System.Drawing.Point(1018, 638);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(44, 29);
            this.labelID.TabIndex = 0;
            this.labelID.Text = "ת\"ז";
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassword.Location = new System.Drawing.Point(987, 706);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(75, 29);
            this.labelPassword.TabIndex = 1;
            this.labelPassword.Text = "סיסמה";
            // 
            // loginID
            // 
            this.loginID.Location = new System.Drawing.Point(855, 643);
            this.loginID.Name = "loginID";
            this.loginID.Size = new System.Drawing.Size(112, 26);
            this.loginID.TabIndex = 0;
            // 
            // loginPassword
            // 
            this.loginPassword.Location = new System.Drawing.Point(855, 712);
            this.loginPassword.Name = "loginPassword";
            this.loginPassword.Size = new System.Drawing.Size(112, 26);
            this.loginPassword.TabIndex = 1;
            // 
            // loginEnter
            // 
            this.loginEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginEnter.Location = new System.Drawing.Point(978, 835);
            this.loginEnter.Name = "loginEnter";
            this.loginEnter.Size = new System.Drawing.Size(84, 43);
            this.loginEnter.TabIndex = 2;
            this.loginEnter.Text = "כניסה";
            this.loginEnter.UseVisualStyleBackColor = true;
            this.loginEnter.Click += new System.EventHandler(this.loginEnter_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(674, 112);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(594, 52);
            this.labelTitle.TabIndex = 8;
            this.labelTitle.Text = "כניסה למערכת - ארגון צוללות";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.wmp);
            this.panel1.Controls.Add(this.picBoxFolder);
            this.panel1.Controls.Add(this.playerNameAndPic1);
            this.panel1.Controls.Add(this.labelTitle);
            this.panel1.Controls.Add(this.labelID);
            this.panel1.Controls.Add(this.loginEnter);
            this.panel1.Controls.Add(this.labelPassword);
            this.panel1.Controls.Add(this.loginPassword);
            this.panel1.Controls.Add(this.loginID);
            this.panel1.Location = new System.Drawing.Point(14, 14);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1898, 1022);
            this.panel1.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(1317, 198);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(237, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "תיקיית תמונות הארגון";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(525, 209);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "סרטון הארגון";
            // 
            // wmp
            // 
            this.wmp.Enabled = true;
            this.wmp.Location = new System.Drawing.Point(191, 151);
            this.wmp.Name = "wmp";
            this.wmp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wmp.OcxState")));
            this.wmp.Size = new System.Drawing.Size(233, 233);
            this.wmp.TabIndex = 3;
            // 
            // picBoxFolder
            // 
            this.picBoxFolder.Location = new System.Drawing.Point(1200, 222);
            this.picBoxFolder.Name = "picBoxFolder";
            this.picBoxFolder.Size = new System.Drawing.Size(350, 349);
            this.picBoxFolder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxFolder.TabIndex = 11;
            this.picBoxFolder.TabStop = false;
            // 
            // playerNameAndPic1
            // 
            this.playerNameAndPic1.firstName = "";
            this.playerNameAndPic1.id = "";
            this.playerNameAndPic1.lastName = "";
            this.playerNameAndPic1.Location = new System.Drawing.Point(850, 226);
            this.playerNameAndPic1.Margin = new System.Windows.Forms.Padding(2);
            this.playerNameAndPic1.Name = "playerNameAndPic1";
            this.playerNameAndPic1.picLocation = "";
            this.playerNameAndPic1.Size = new System.Drawing.Size(212, 337);
            this.playerNameAndPic1.TabIndex = 9;
            this.playerNameAndPic1.Visible = false;
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Size = new System.Drawing.Size(200, 200);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxLogo.TabIndex = 10;
            this.picBoxLogo.TabStop = false;
            this.picBoxLogo.Click += new System.EventHandler(this.picBoxLogo_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.picBoxLogo);
            this.Name = "FormLogin";
            this.Text = "FormLogin";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.Shown += new System.EventHandler(this.FormLogin_Shown);
            this.SizeChanged += new System.EventHandler(this.FormLogin_SizeChanged);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFolder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox loginID;
        private System.Windows.Forms.TextBox loginPassword;
        private System.Windows.Forms.Button loginEnter;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panel1;
        private playerNameAndPic playerNameAndPic1;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.PictureBox picBoxFolder;
        private AxWMPLib.AxWindowsMediaPlayer wmp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

