﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormSubmarineNew : Submarines.FormBaseSubmarine
    {
        private int[,] arrValues;
        bool isDragging;
        OleDbConnection dataConnection;

        public FormSubmarineNew(OleDbConnection connection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            dataConnection = connection;
        }

        #region Initiallizing Buttons

        private void buttonBuild_Click(object sender, EventArgs e)
        {
            foreach (Control control in panel2.Controls)
            {
                control.Dispose();
            }
            panel2.Controls.Clear();
            int r = ((int)rows.Value);
            int c = ((int)cols.Value);
            arrValues = new int[r, c];
            int totalButtonWidth = c * 20 + (c - 1) * 7;
            int totalButtonHeight = r * 20 + (r - 1) * 7;
            int offsetX = (panel2.Width - totalButtonWidth) / 2;
            int offsetY = (panel2.Height - totalButtonHeight) / 2;

            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    AddButton(i, j, offsetX, offsetY);

            buttonSave.Enabled = true;
        }

        private void AddButton(int i, int j, int offsetX, int offsetY)
        {

            int btnSide = 20;
            int X = offsetX + j * (btnSide + 7);
            int Y = offsetY + i * (btnSide + 7);
            string btnRow = i<10 ? $"0{i}" : i.ToString();
            string btnCol = j<10 ? $"0{j}" : j.ToString();
            Button b = new Button() {
               Name = $"btn_{btnRow}_{btnCol}",
               Location = new System.Drawing.Point(X, Y),
               Size = new System.Drawing.Size(btnSide, btnSide),
               TabIndex = i + j,
               Tag = false,
               UseVisualStyleBackColor = true,
               BackColor = arrValues[i, j] == 1 ? Color.Blue : SystemColors.Control
            };
            
            b.Click += new EventHandler(Button_Click);
            this.panel2.Controls.Add(b);
        }
        #endregion

        #region Modifying Buttons

        private void Button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.Tag = false;
            ChangeButtonColorAndValue(btn);                        
        }

        private void ChangeButtonColorAndValue(Button button)
        {
            bool hasBeenProcessed = (bool)button.Tag;

            if (hasBeenProcessed)
            {
                return;
            }

            int[] ij = SubmarinesUtils.GetButtonIndices(button);
            int i = ij[0];
            int j = ij[1];

            if (arrValues[i, j] == 0)
            {
                button.BackColor = Color.Blue;
                arrValues[i, j] = 1;
            }
            else
            {
                button.BackColor = SystemColors.Control;
                arrValues[i, j] = 0;
            }

            button.Tag = true;
        }
        #endregion

        #region Hold Down And Drag Selection Mode
        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
            }
        }
        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
                foreach (Control ctrl in panel2.Controls)
                {
                    if (ctrl is Button button && button.Tag != null)
                    {
                        button.Tag = false;
                    }
                }
            }            
        }
        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                foreach (Control ctrl in panel2.Controls)
                {
                    if (ctrl is Button button && button.ClientRectangle.Contains(
                        button.PointToClient(Cursor.Position)))
                    {
                        ChangeButtonColorAndValue(button);
                    }
                }
            }
        }
        #endregion

        #region Saving To Database
        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (!Validations.ValidName(subName.Text))
            {
                MessageBox.Show("השם שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (panel2.Controls.Count == 0)
            {
                MessageBox.Show("לא נבנתה צורת צוללת", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Validations.Exist(dataConnection, "tblSubmarines", "subName", subName.Text)){
                MessageBox.Show("שם הצוללת הנבחר כבר קיים במסד הנתונים", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }            
            if(subName.Text == "" || sinkPercent.Text == "")
            {
                MessageBox.Show("לא כל פרטי הצוללת מלאים", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!SubmarinesUtils.IsSubArrCompact(arrValues))
            {
                DialogResult res = MessageBox.Show("?הצוללת לא קומפקטית, להפוך אותה לקומפקטית",
                    "צמצום אוטומטי", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res != DialogResult.Yes) {
                    return;
                }
                arrValues = SubmarinesUtils.ShrinkArray(arrValues);
                if (arrValues.GetLength(0) * arrValues.GetLength(1) < 2) {
                    MessageBox.Show("צורת הצוללת קטנה מדי", "שגיאה",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                MessageBox.Show(".הצוללת צומצמה בהצלחה", "הצלחה",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                ShowCompactedSub();
            }
            AddSub();
            AddMarkedSquares();
            MessageBox.Show(".הצוללת נוספה למסד הנתונים בהצלחה", "הצלחה",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void AddSub()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblSubmarines " +
                    "(subRows, subCols, subName, subSinkPercent) " +
                    "VALUES ({0}, {1}, \"{2}\", {3})",
                    arrValues.GetLength(0), arrValues.GetLength(1), subName.Text, sinkPercent.Text);
                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblSubmarines failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void AddMarkedSquares()
        {
            int subID = GetSubId();
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str =
                    "INSERT INTO tblMarkedSquares " +
                    "(msSubID, msRowNum, msColNum) " +
                    "VALUES (@SubId, @i, @j)";
                datacommand.CommandText = str;
                
                for (int i = 0; i < arrValues.GetLength(0); i++) {
                    for (int j = 0; j < arrValues.GetLength(1); j++) {
                        if (arrValues[i,j] == 1)
                        {
                            datacommand.Parameters.Clear();
                            datacommand.Parameters.AddWithValue("@SubId", subID);
                            datacommand.Parameters.AddWithValue("@i", i);
                            datacommand.Parameters.AddWithValue("@j" ,j);
                            datacommand.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblMarkedSquares failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetSubId()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT subID " +
                                          "FROM tblSubmarines " +
                                          "WHERE subName = @subName";
                datacommand.Parameters.AddWithValue("@subName", subName.Text);
                return (int)datacommand.ExecuteScalar();
            }
            catch (Exception err)
            {
                MessageBox.Show("Get SubId failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }

        private void ShowCompactedSub()
        {
            foreach (Control control in panel2.Controls)
            {
                control.Dispose();
            }
            panel2.Controls.Clear();
            int r = arrValues.GetLength(0);
            int c = arrValues.GetLength(1);
            rows.Value = r;
            cols.Value = c;
            int totalButtonWidth = c * 20 + (c - 1) * 7;
            int totalButtonHeight = r * 20 + (r - 1) * 7;
            int offsetX = (panel2.Width - totalButtonWidth) / 2;
            int offsetY = (panel2.Height - totalButtonHeight) / 2;

            for (int i = 0; i < r; i++)
                for (int j = 0; j < c; j++)
                    AddButton(i, j, offsetX, offsetY);

            buttonSave.Enabled = false;
        }

        #endregion

        private void FormSubmarineNew_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }

        private void helpButton_Click(object sender, EventArgs e)
        {
            FormHelpSubNew helpSubNew = new FormHelpSubNew();
            helpSubNew.Height = panel1.Height;
            helpSubNew.ShowDialog();
        }
    }
}
