﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;


namespace Submarines
{
    public partial class FormGameStart : Submarines.FormBaseGame
    {
        private Bitmap[] picLocations = 
        {
            Properties.Resources._1d6,
            Properties.Resources._2d6,
            Properties.Resources._3d6,
            Properties.Resources._4d6,
            Properties.Resources._5d6,
            Properties.Resources._6d6
        };

        private OleDbConnection dataConnection;

        List<Submarine> allSubsList;

        private Random random;
        private int starter;

        private bool p1Chosen, p2Chosen;
        private Player p1, p2;
        private Timer cubeTimer1, cubeTimer2;
        private int throwCount1, throwCount2;
        private int finalCube1, finalCube2;
        private bool cube1Finished, cube2Finished;

        public FormGameStart(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;

            allSubsList = new List<Submarine>();

            FillIdCombo(comboId1);
            FillIdCombo(comboId2);
            FillSubsCheckBoxList();

            cubeTimer1 = new Timer();
            cubeTimer1.Interval = 100;  
            cubeTimer1.Tick += new EventHandler(CubeTimer1_Tick);

            cubeTimer2 = new Timer();
            cubeTimer2.Interval = 100;
            cubeTimer2.Tick += new EventHandler(CubeTimer2_Tick);

            random = new Random();

            ttlBoardSqrs.Text = ((int)bRows.Value * ((int)bCols.Value)).ToString();
            ttlSubSqrs.Text = "0";
        }

        #region Filling combos and list
        private void FillIdCombo(ComboBox combo)
        {
            combo.DropDownStyle = ComboBoxStyle.DropDownList;
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerID, playerFirstName, playerLastName " +
                                          "FROM tblPlayers " +
                                          "ORDER BY playerID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    combo.Items.Add(dataReader.GetInt32(0).ToString() + ", " +
                        dataReader.GetString(1) + " " + dataReader.GetString(2));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarines checklist failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillSubsCheckBoxList()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT * " +
                                          "FROM tblSubmarines " +
                                          "ORDER BY subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    int id = dataReader.GetInt32(0);
                    int rows = dataReader.GetInt32(1);
                    int cols = dataReader.GetInt32(2);
                    string name = dataReader.GetString(3);
                    int sinkP = dataReader.GetInt32(4);
                    Submarine sub = new Submarine(id,name,rows,cols,sinkP);
                    checkListSubs.Items.Add(sub.ExtendedString());
                    allSubsList.Add(sub);
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill sub checkbox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadBotCombo()
        {            
            if (comboBotPlayer.Enabled == false) { return; }
            comboBotPlayer.Items.Clear();
            comboBotPlayer.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBotPlayer.Items.Add("None");
            comboBotPlayer.Items.Add(comboId1.Text);
            comboBotPlayer.Items.Add(comboId2.Text);
            comboBotPlayer.SelectedIndex = 0;
        }
        #endregion

        #region Choosing Players And Colors
        private void btnColor1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            DialogResult res = cd.ShowDialog();
            Color chosenColor = cd.Color;
            if (res == DialogResult.OK)
            {
                ColorDlgClosed(chosenColor, btnColor1, col1);
            }
        }

        private void btnColor2_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            DialogResult res = cd.ShowDialog();
            Color chosenColor = cd.Color;
            if (res == DialogResult.OK) {
                ColorDlgClosed(chosenColor, btnColor2, col2);
            }
        }

        private void ColorDlgClosed(Color color, Button colorButton, TextBox colorBox)
        {
            double brightness = GetBrightness(color);
            if (brightness < 0.206)
            {
                DialogResult res = MessageBox.Show("?הצבע שנבחר כהה מדי, ויצור קושי במהלך המשחק. לבחור צבע אחר",
                    "צבע נבחר כהה מדי", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (res == DialogResult.Yes)
                {
                    colorButton.PerformClick();
                    return;
                }
            }
            if (color == Color.Silver || color == Color.Gainsboro || color == Color.LightGray)
            {
                DialogResult res = MessageBox.Show("?הצבע שנבחר דומה מדי לצבע הרקע, ויפריע להבנת הלוח במשחק. לבחור צבע אחר",
                     "צבע נבחר דומה לרקע", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (res == DialogResult.Yes)
                {
                    colorButton.PerformClick();
                    return;
                }            
            }
            colorButton.BackColor = color;
            colorBox.Text = color.ToArgb().ToString();            
        }

        double GetBrightness(Color c)
        { return (c.R * 0.299 + c.G * 0.587 + c.B * 0.114) / 256; }

        private void comboId1_SelectedIndexChanged(object sender, EventArgs e)
        {

            p1Chosen = true;
            CheckForActivate(sender as ComboBox,1);
            Player p = new Player((sender as ComboBox).Text);
            p1pic.ImageLocation = p.GetPlayerPicLocation(dataConnection);
        }

        private void comboId2_SelectedIndexChanged(object sender, EventArgs e)
        {
            p2Chosen = true;
            CheckForActivate(sender as ComboBox,2);
            Player p = new Player((sender as ComboBox).Text);
            p2pic.ImageLocation = p.GetPlayerPicLocation(dataConnection);           
        }

        private void CheckForActivate(ComboBox sender, int playerNum)
        {
            if (comboId1.Text == comboId2.Text)
            {
                MessageBox.Show(".שחקן אחד נבחר פעמיים","שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);

                int index = sender.SelectedIndex;
                sender.SelectedIndex = index == 0 ? 1 : 0;

                if(playerNum == 1) { p1Chosen = true; }
                if(playerNum == 2) { p2Chosen = true; }
            }
            if (p1Chosen && p2Chosen)
            {               
                vs.Visible = true;
                btnRoll1.Enabled = true;
                btnRoll2.Enabled = true;
                comboBotPlayer.Enabled = true;
                LoadBotCombo();
            }
        }
        #endregion

        #region Rolling cubes
        private bool AreColorsChosen()
        {

            if (col1.Text == "< color selector" || col2.Text == "< color selector")
            {
                MessageBox.Show(".חסרה בחירת צבע", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (col1.Text == col2.Text)
            {
                MessageBox.Show(".צבע אחד נבחר פעמיים", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void btnRoll1_Click(object sender, EventArgs e)
        {
            if (!AreColorsChosen()) { return; }
            throwCount1 = 0;
            cube1Finished = false;
            comboId1.Enabled = false;
            btnColor1.Enabled = false;
            comboBotPlayer.Enabled = false;
            btnRoll1.Enabled = false;
            p1 = new Player(comboId1.Text);
            cubeTimer1.Start();
        }
        
        private void btnRoll2_Click(object sender, EventArgs e)
        {
            if (!AreColorsChosen()) { return; }
            throwCount2 = 0;
            cube2Finished = false;
            comboId2.Enabled = false;
            btnColor2.Enabled = false;
            comboBotPlayer.Enabled = false;
            btnRoll2.Enabled = false;
            p2 = new Player(comboId2.Text);
            cubeTimer2.Start();
        }        

        private void CubeTimer1_Tick(object sender, EventArgs e)
        {
            if (throwCount1 < 10)
            {
                int randomIndex = random.Next(0, picLocations.Length);
                cube1.Image = picLocations[randomIndex];
                throwCount1++;
            }
            else
            {
                cubeTimer1.Stop();
                finalCube1 = random.Next(0, picLocations.Length);
                cube1.Image = picLocations[finalCube1];
                cube1Finished = true;
                CheckForWinner();
            }
        }

        private void CubeTimer2_Tick(object sender, EventArgs e)
        {
            if (throwCount2 < 10)
            {
                int randomIndex = random.Next(0, picLocations.Length);
                cube2.Image = picLocations[randomIndex];
                throwCount2++;
            }
            else
            {
                cubeTimer2.Stop();
                finalCube2 = random.Next(0, picLocations.Length);
                cube2.Image = picLocations[finalCube2];
                cube2Finished = true;
                CheckForWinner();
            }
        }

        private void CheckForWinner()
        {
            if (cube1Finished && cube2Finished)
            {
                if (finalCube1 > finalCube2)
                {
                    bgnMsg.Text += $"\n{comboId1.Text.Split(',')[1]}";
                    bgnMsg.ForeColor = btnColor1.BackColor;
                    bgnMsg.Visible = true;
                    starter = 1;
                }
                else if (finalCube2 > finalCube1)
                {
                    bgnMsg.Text += $"\n{comboId2.Text.Split(',')[1]}";
                    bgnMsg.ForeColor = btnColor2.BackColor;
                    bgnMsg.Visible = true;
                    starter = 2;
                }
                else
                {
                    MessageBox.Show(".תיקו, הקוביות יוטלו עוד פעם", "תיקו",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RerollCubes();
                }
                btnContinue.Visible = true;
            }
        }

        private void RerollCubes()
        {
            throwCount1 = 0;
            throwCount2 = 0;
            cube1Finished = false;
            cube2Finished = false;
            cubeTimer1.Start();
            cubeTimer2.Start();
        }
        #endregion

        #region Submarine checklist ToolTip
        private void checkListSubs_MouseMove(object sender, MouseEventArgs e)
        {
            int index = checkListSubs.IndexFromPoint(e.Location);

            if (index != ListBox.NoMatches)
            {
                Rectangle itemRect = checkListSubs.GetItemRectangle(index);
                bool onCheckSquare = e.X > itemRect.Right - 23;

                if (!onCheckSquare)
                {
                    if ((int?)subPreviewTT.Tag != index)
                    {
                        string pixelArt = GetPixelArt(index);
                        string previewText = ":צורת הצוללת\n\n" + pixelArt;
                        subPreviewTT.Show(previewText, checkListSubs, e.Location);
                        subPreviewTT.Tag = index;
                    }
                }
                else
                {
                    subPreviewTT.Hide(checkListSubs);
                    subPreviewTT.Tag = null;
                }
            }
            else
            {
                subPreviewTT.Hide(checkListSubs);
                subPreviewTT.Tag = null;
            }
        }

        private string GetPixelArt(int index)
        {
            int subID = SubmarinesUtils.GetIdFromDetails(checkListSubs.Items[index].ToString());
            Submarine sub = allSubsList.Find(s => s.subId == subID);

            int[,] msArr = sub.GetMarkedSquaresArray(dataConnection);

            string pixelArt = "";

            for (int i = 0; i < msArr.GetLength(0); i++)
            {
                for (int j = 0; j < msArr.GetLength(1); j++)
                {
                    pixelArt += msArr[i, j] == 1 ? "■" : "   ";
                }
                pixelArt += "\n";
            }
            return pixelArt;
        }
        #endregion

        #region Total board, submarines squares and ratio updates
        private void bRows_ValueChanged(object sender, EventArgs e)
        {
            ttlBoardSqrs.Text = ((int)bRows.Value * ((int)bCols.Value)).ToString();
            int brd = int.Parse(ttlBoardSqrs.Text);
            int subs = int.Parse(ttlSubSqrs.Text);
            double ratio = Math.Round((double)brd / subs,1);
            brdSubRatio.Text =  ratio.ToString();
        }

        private void bCols_ValueChanged(object sender, EventArgs e)
        {
            ttlBoardSqrs.Text = ((int)bRows.Value * ((int)bCols.Value)).ToString();
            int brd = int.Parse(ttlBoardSqrs.Text);
            int subs = int.Parse(ttlSubSqrs.Text);
            double ratio = Math.Round((double)brd / subs, 1);
            brdSubRatio.Text = ratio.ToString();
        }

        private void checkListSubs_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            int totalSurfaceArea = 0;
           
            for (int i = 0; i < checkListSubs.Items.Count; i++)
            {
                bool isChecked = checkListSubs.GetItemChecked(i);
                if (i == e.Index)
                {
                    isChecked = e.NewValue == CheckState.Checked;
                }

                if (isChecked)
                {
                    totalSurfaceArea += allSubsList[i].GetSubArea();
                }
            }

            ttlSubSqrs.Text = totalSurfaceArea.ToString();
            int brd = int.Parse(ttlBoardSqrs.Text);
            int sub = int.Parse(ttlSubSqrs.Text);
            double ratio = Math.Round((double)brd / sub, 1);
            brdSubRatio.Text = ratio.ToString();
        }
        #endregion

        #region Continuing
        private int GetGameID()
        {
            int id = 1;
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT COUNT(*) " +
                                          "FROM tblGames";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                dataReader.Read();
                id = dataReader.GetInt32(0) + 1;
            }
            catch (Exception err)
            {
                MessageBox.Show("getting game id failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return id;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (!AreSettingsValid()) { return; }

            int index = comboBotPlayer.SelectedIndex;
            bool p1Computer = index == 1;
            bool p2Computer = index == 2;

            p1 = new Player(p1, int.Parse(col1.Text), p1Computer);
            p2 = new Player(p2, int.Parse(col2.Text), p2Computer);

            List<Submarine> checkedSubs = new List<Submarine>();
            int[] selectedIndicies = checkListSubs.CheckedIndices.Cast<int>().ToArray();
            foreach(int i in selectedIndicies)
            {
                checkedSubs.Add(allSubsList[i]);
            }
            Game game = new Game(GetGameID(),starter, ((int)bRows.Value), ((int)bCols.Value), p1, p2, checkedSubs);

            this.Hide();
            FormGamePlaceSubs formGamePlace = new FormGamePlaceSubs(dataConnection, game);
            formGamePlace.Show();
            formGamePlace.Disposed += new EventHandler(formPlaceSubs_Disposed);            
        }

        private bool AreSettingsValid()
        {
            if (checkListSubs.CheckedItems.Count < 2)
            {
                MessageBox.Show(".לא נבחרו מספיק צוללות", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (int.Parse(ttlBoardSqrs.Text) <= int.Parse(ttlSubSqrs.Text))
            {
                MessageBox.Show(".הלוח לא יכול להכיל את כל הצוללות שנבחרו", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            double ratio = double.Parse(brdSubRatio.Text);
            if (ratio < 4 || ratio > 6)
            {
                if (ratio < 2)
                {
                    MessageBox.Show("יחס משבצות הלוח למשבצות הצוללות קטן מ2, שנה את גודל הלוח או את בחירת הצוללות כדי להגדיל אותו",
                        "הגדל את יחס המשבצות לצוללות", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                    return false;
                }
                DialogResult res = MessageBox.Show("עבור חויית משחק עדיפה, מומלץ שיחס\n" +
                    ".משבצות הלוח למשבצות הצוללות ייהיה בסביבות 5\n" +
                    $".היחס הנוכחי הוא {brdSubRatio.Text}",
                    "המלצה לחויית משחק עדיפה", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (res != DialogResult.OK) { return false; }
            }
            return true;
        }

        private void formPlaceSubs_Disposed(object sender, EventArgs e)
        {
            if(!SubmarinesUtils.mainGameFormOpen)
            {
                this.Show();
                this.Activate();
            }
        }
        #endregion

        private void FormGameStart_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }

        private void helpButton_Click(object sender, EventArgs e)
        {
            FormHelpGameStart helpGameStart = new FormHelpGameStart();
            helpGameStart.Height = panel1.Height;
            helpGameStart.ShowDialog();
        }
    }
}
