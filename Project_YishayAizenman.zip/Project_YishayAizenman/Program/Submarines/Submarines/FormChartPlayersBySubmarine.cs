﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormChartPlayersBySubmarine : Submarines.FormBaseCharts
    {
        private OleDbConnection dataConnection;
        private int counter;
        private string[] arrSubs;
        private int[] arrCounts;

        public FormChartPlayersBySubmarine(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            CountSubs();
            arrSubs = new string[counter];
            arrCounts = new int[counter];
            FillArrSubs();
            FillArrCounts();
            ShowChart();
            EditDataGridView();
        }

        private void CountSubs()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT   COUNT(*) " +
                                          "FROM     tblSubmarines";
                counter = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Count tblSubmarines failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrSubs()
        {
            try
            {
                int k = 0;
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT subID, subName " +
                                          "FROM tblSubmarines " +
                                          "ORDER BY subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    arrSubs[k] = dataReader.GetInt32(0) + ", " + dataReader.GetString(1);
                    k++;
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select tblSubmarines failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrCounts()
        {
            for (int idx = 0; idx < arrSubs.Length; idx++)
                CountPlayers(idx);
        }

        private void CountPlayers(int idx)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                "SELECT COUNT(*) " +
                "FROM( " +
                "   SELECT DISTINCT p.playerID " +
                "   FROM (((tblSubmarines AS s " +
                "   INNER JOIN tblStartGames AS sg " +
                "       ON s.subID = sg.startSubID) " +
                "   INNER JOIN tblGames AS g " +
                "       ON sg.startGameID = g.gameID)" +
                "   INNER JOIN tblPlayers AS p " +
                "       ON p.playerID = g.gamePlayer1ID OR p.playerID = g.gamePlayer2ID) " +
                "   WHERE s.subID = @subID" +
                ");";
                datacommand.Parameters.AddWithValue("@subID", SubmarinesUtils.GetIdFromDetails(arrSubs[idx]));
                arrCounts[idx] = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("count players failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ShowChart()
        {
            try
            {
                chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -45;

                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoom(1, 10);
                chart1.ChartAreas["ChartArea1"].CursorX.IsUserSelectionEnabled = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoomable = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.Title = "מספר שחקנים";
                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;

                chart1.ChartAreas["ChartArea1"].AxisY.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.Interval = 1;
                chart1.ChartAreas["ChartArea1"].AxisX.Title = "צוללות";

                chart1.Legends.Clear();
                chart1.Series.Clear();
                chart1.Series.Add("נתונים");


                for (int i = 0; i < arrSubs.Length; i++)
                {
                    chart1.Series["נתונים"].Points.AddXY(
                        SubmarinesUtils.StringRightToLeft(arrSubs[i]), arrCounts[i]);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Show chart failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EditDataGridView()
        {
            try
            {
                for (int i = 0; i < arrSubs.Length; i++)
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
                    row.Cells[0].Value = arrSubs[i];
                    row.Cells[1].Value = arrCounts[i].ToString();
                    dataGridView1.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit gridview item failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormChartPlayersBySubmarine_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
