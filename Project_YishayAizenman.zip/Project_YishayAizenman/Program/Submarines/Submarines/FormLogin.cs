﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using AxWMPLib;
using System.Diagnostics;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormLogin : Form
    {
        private OleDbConnection dataConnection;
        private Player player;
        private bool isManager;

        private Random random;
        private Timer picsDirectoryTimer;
        private string[] picFileTypes = { "*.jpg", "*.jpeg", "*.png", "*.bmp" };
        private string[] pics;

        public FormLogin()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.Icon = Properties.Resources.AppIcon;
            loginEnter.Tag = false;

            random = new Random();
            picsDirectoryTimer = new Timer();
            picsDirectoryTimer.Interval = 500;
            picsDirectoryTimer.Tick += PicsDirectoryTimer_Tick;

            wmp.stretchToFit = true;
        }

        private bool OpenDb()
        {
            dataConnection = new OleDbConnection();
            try
            {
                dataConnection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                    "Data Source=C:\\Projects_2025\\Project_YishayAizenman\\Access\\dbSubmarines.accdb";
                dataConnection.Open();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Open data base failed \n" + ex.Message,
                                 "Errors",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                return false;
            }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            loginEnter.Enabled = OpenDb();
            SubmarinesUtils.GlobalOrgData.UpdateFromDB(dataConnection);
        }

        private void FormLogin_Shown(object sender, EventArgs e)
        {
            try
            {
                picBoxLogo.ImageLocation = SubmarinesUtils.GlobalOrgData.orgImageLocation;

                wmp.URL = SubmarinesUtils.GlobalOrgData.orgVidLocation;

                string orgFolder = SubmarinesUtils.GlobalOrgData.orgFolder;
                pics = picFileTypes.SelectMany(
                    fileType => Directory.GetFiles(orgFolder, fileType)).ToArray();
                picsDirectoryTimer.Start();
            }
            catch (Exception err)
            {
                MessageBox.Show("Error in showing the Organization Pictures folder: \n" + err.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void picBoxLogo_Click(object sender, EventArgs e)
        {
            Process.Start(SubmarinesUtils.GlobalOrgData.orgWebAddress);
        }

        private void PicsDirectoryTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                picBoxFolder.Image = Image.FromFile(pics[random.Next(pics.Length)]);
            }
            catch (Exception err)
            {
                MessageBox.Show("Error in showing a picture in the Organization Pictures folder: \n" 
                    + err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loginEnter_Click(object sender, EventArgs e)
        {            
            if(!Validations.Exist(dataConnection, "tblPlayers", "playerID", loginID.Text.ToString())
                || !Validations.ValidID(loginID.Text))
            {
                MessageBox.Show("שם משתמש או סיסמה שגויים", "שגיאה",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT  playerID, playerFirstName, playerLastName, " +
                                          "playerPassword, playerIsManager " +
                                          "FROM    tblPlayers " +
                                          "WHERE   playerID = " + loginID.Text;
                OleDbDataReader dataReader = datacommand.ExecuteReader();     
                
                dataReader.Read();
                int id = dataReader.GetInt32(0);
                string firstName = dataReader.GetString(1);
                string lastName = dataReader.GetString(2);
                string password = dataReader.GetString(3);
                isManager = dataReader.GetBoolean(4);

                player = new Player(id, firstName, lastName);

                if (password == loginPassword.Text)
                {
                    if ((bool)loginEnter.Tag)
                    {
                        picsDirectoryTimer.Stop();
                        this.Hide();
                        FormMenu frMenu = new FormMenu(dataConnection, player ,isManager);
                        frMenu.Show();
                        frMenu.Disposed += new EventHandler(frMenu_Disposed);
                    }
                    else
                    {                      
                        playerNameAndPic1.UpdateProperties(player, dataConnection);
                        playerNameAndPic1.Visible = true;
                        loginEnter.Text = "המשך";
                        loginEnter.Tag = true;
                    }                    
                }                
                else
                {
                    MessageBox.Show("שם משתמש או סיסמה שגויים", "שגיאה",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Select tblPlayers failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }             

        }

        private void FormLogin_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }

        void frMenu_Disposed(object sender, EventArgs e)
        {
            loginID.Text = "";
            loginPassword.Text = "";
            loginEnter.Text = "כניסה";
            playerNameAndPic1.Visible= false;
            loginEnter.Tag = false;
            this.Show();
            this.Activate();
            FormLogin_Shown(null, EventArgs.Empty);
        }      
    }
}
