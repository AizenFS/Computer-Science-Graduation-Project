﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormUpdateStartGame : Submarines.FormBaseUpdate
    {
        OleDbConnection dataConnection;
        int lastRow = 0;
        public FormUpdateStartGame(OleDbConnection dataConnection)
        {
            this.dataConnection = dataConnection;
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            FillSubmarinesCombo();
            RefreshDataGridView();
            dataGridView1.Rows[0].Selected = true;
            FillSelectedRow();
        }

        private void FormUpdateStartGame_Load(object sender, EventArgs e)
        {
            this.tblStartGamesTableAdapter.Fill(this.dataSetStartGames.tblStartGames);

        }

        private void FillSubmarinesCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT subID, subName " +
                                          "FROM tblSubmarines " +
                                          "ORDER BY subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    submarines.Items.Add(dataReader.GetInt32(0).ToString() + ", " + dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarines combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillSelectedRow()
        {
            try
            {
                gameId.Text     = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                subOrder.Text   = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                submarines.Text = SubmarinesUtils.GetDetailsFromID(dataGridView1, submarines, 2);
                p1Row.Text      = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                p1Col.Text      = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                p2Row.Text      = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                p2Col.Text      = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();                

                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                EnableButtons();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill Selected Row \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = 
                    "UPDATE tblStartGames " +
                    "SET    startSubID   = " + SubmarinesUtils.GetIdFromDetails(submarines.Text) + "  , " +
                            "startRow1   = " + p1Row.Text                                        + "  , " +
                            "startCol1   = " + p1Col.Text                                        + "  , " +
                            "startRow2   = " + p2Row.Text                                        + "  , " +
                            "startCol2   = " + p2Col.Text                                        + "    " +
                    "WHERE  startGameID = " + gameId.Text + "AND startOrderNum = " + subOrder.Text;
                datacommand.ExecuteNonQuery();
                RefreshDataGridView();
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                MessageBox.Show("Update tblStartGames ended successfluly");
            }
            catch (Exception err)
            {
                MessageBox.Show("Update tblStartGames failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT    * " +
                                    "FROM     tblStartGames " +
                                    "ORDER BY startGameID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EnableButtons()
        {
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            if (lastRow == 0)
                buttonPrev.Enabled = false;
            if (lastRow == dataGridView1.Rows.Count - 1)
                buttonNext.Enabled = false;
        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = 0;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow++;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = dataGridView1.Rows.Count - 1;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow--;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lastRow = dataGridView1.CurrentRow.Index;
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            FillSelectedRow();
        }

        private void FormUpdateStartGame_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
