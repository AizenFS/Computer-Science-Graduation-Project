﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormGameReplay : Submarines.FormBaseGame
    {
        private int BIGGEST_SUB_ID;
        private enum ButtonAction { Reset, Previous, Next, Last }

        private SubmarinesUtils.GameBoardCreator gameBoardCreator;

        private readonly OleDbConnection dataConnection;
        private readonly Game game;
        private readonly int[,] originalLocations1, originalLocations2;

        private Timer replayTimer;
        private bool isAutoReplaying;

        private List<Step> stepsList;
        private int currentStepIndex;
        private int stepCount;

        private int[] airStrikeCounters;
        private int[] remainingSubsCounters;

        private readonly Player p1, p2;

        private int[,] boardLocations1, boardLocations2;
        private int[] subSinkingIndecies1, subSinkingIndecies2;

        private int currentPlayer;
        private int[,] currentOriginalLocations;
        private int[,] currentLocations;
        private int[] subSinkingIndecies;

        private Panel currentBoard;
        private Label currentAirStrikeCount;
        private TextBox currentRemainingSubs;

        public FormGameReplay(OleDbConnection dataConnection, Game game,
            int[,] originalLocations1, int[,] originalLocations2)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

            this.dataConnection = dataConnection;
            this.game = game;
            this.originalLocations1 = originalLocations1;
            this.originalLocations2 = originalLocations2;

            gameBoardCreator = new SubmarinesUtils.GameBoardCreator(game, (Button b) => { }, false);

            boardLocations1 = new int[game.boardRows, game.boardCols];
            boardLocations2 = new int[game.boardRows, game.boardCols];

            currentStepIndex = -1;
            stepCount = 0;

            stepsList = new List<Step>();

            replayTimer = new Timer();
            replayTimer.Tick += ReplayTimer_Tick;
            isAutoReplaying = false;

            airStrikeCounters = new int[2];
            remainingSubsCounters = new int[2];

            p1 = game.player1;
            p2 = game.player2;
            currentPlayer = 0;
        }
        private void AssignControlVariables(int playerNum)
        {
            currentBoard = playerNum == 1 ? board1 : board2;
            currentAirStrikeCount = playerNum == 1 ? labelAirStrikeCount1 : labelAirStrikeCount2;
            currentRemainingSubs = playerNum == 1 ? rmnSubs1 : rmnSubs2;
            currentLocations = playerNum == 1 ? boardLocations1 : boardLocations2;
            currentOriginalLocations = playerNum == 1 ? originalLocations2 : originalLocations1;
            subSinkingIndecies = playerNum == 1 ? subSinkingIndecies1 : subSinkingIndecies2;
        }

        #region Initiallization
        private void FormGameReplay_Load(object sender, EventArgs e)
        {
            SubmarinesUtils.Copy2dArray(originalLocations2, boardLocations1);
            SubmarinesUtils.Copy2dArray(originalLocations1, boardLocations2);

            BIGGEST_SUB_ID = game.submarines.Max(sub => sub.subId);
            subSinkingIndecies1 = new int[BIGGEST_SUB_ID];
            subSinkingIndecies2 = new int[BIGGEST_SUB_ID];

            SetupPlayerGUIs();

            btnStartStop.BackgroundImage = Properties.Resources.PlayPause;
            replaySpeedBar_ValueChanged(null, EventArgs.Empty);

            gameBoardCreator.CreateBoard(board1);
            gameBoardCreator.CreateBoard(board2);

            LoadStepsList();

            labelCurrPlayerNum.Text = "0";
            labelCurrStep.Text = "0";

            btnPrev.Enabled = false;
            btnReset.Enabled = false;
        }

        private void DetermineComputerPlayer()
        {
            if (p1.isComputer)
            {
                int center = (NP1.Left + NP1.Width / 2) - labelComputerPlayer.Width / 2;
                labelComputerPlayer.Left = center;
            }
            else if (p2.isComputer)
            {
                int center = (NP2.Left + NP2.Width / 2) - labelComputerPlayer.Width / 2;
                labelComputerPlayer.Left = center;
            }
            else
            {
                labelComputerPlayer.Visible = false;
            }
        }

        private void SetupPlayerGUIs()
        {
            Image copy = airStrike2.Image.Clone() as Image;
            copy.RotateFlip(RotateFlipType.RotateNoneFlipX);
            airStrike1.Image = copy;

            NP1.UpdateProperties(p1, dataConnection);
            NP2.UpdateProperties(p2, dataConnection);
            DetermineComputerPlayer();

            rmnSubs1.Text = game.submarines.Count.ToString();
            rmnSubs2.Text = game.submarines.Count.ToString();
            ClickDepthCharge1();
            ClickDepthCharge2();
        }

        private void LoadStepsList()
        {
            int playerStepCount = 1;

            OleDbCommand datacommand = new OleDbCommand();
            datacommand.Connection = dataConnection;
            datacommand.CommandText =
                "SELECT stepOrderNum, stepRow, stepCol, stepPlayer " +
                "FROM tblSteps " +
                "WHERE stepGameID = @gameID " +
                "ORDER BY stepOrderNum";
            datacommand.Parameters.AddWithValue("@gameID", game.gameId);
            OleDbDataReader dataReader = datacommand.ExecuteReader();
            while (dataReader.Read())
            {
                double orderNum = dataReader.GetDouble(0);
                double decimalVal = orderNum - Math.Floor(orderNum);
                bool isAirStrike = decimalVal == 0.5;
                if (decimalVal == 0 || isAirStrike)
                {
                    int r = dataReader.GetInt32(1);
                    int c = dataReader.GetInt32(2);
                    int player = dataReader.GetInt32(3);
                    if (orderNum > 2)
                    {
                        int lastPlayer = stepsList.Last().playerNum;
                        if (player != lastPlayer) { playerStepCount++; }
                    }
                    stepsList.Add(new Step((int)orderNum, r, c, player, isAirStrike));
                }
            }
            labelTotalSteps.Text = playerStepCount.ToString();
        }
        #endregion

        #region  Update and Reset HUD Items
        private void UpdateHUDItems(Step currentStep, ButtonAction btnAction)
        {
            UpdateSteps(btnAction, currentStep);
            AssignControlVariables(currentPlayer);

            if (currentStep.isAirStrike)
            {
                if (currentPlayer == 1) { ClickAirStrike1(); }
                if (currentPlayer == 2) { ClickAirStrike2(); }
            }
            else
            {
                if (currentPlayer == 1) { ClickDepthCharge1(); }
                if (currentPlayer == 2) { ClickDepthCharge2(); }
            }
        }

        private void UpdateSteps(ButtonAction btnAction, Step currentStep)
        {
            if (currentPlayer != currentStep.playerNum)
            {
                switch (btnAction)
                {
                    case ButtonAction.Previous:
                        stepCount--;
                        break;
                    case ButtonAction.Next:
                        stepCount++;
                        break;
                    case ButtonAction.Last:
                        stepCount = int.Parse(labelTotalSteps.Text);
                        break;
                }
                labelCurrStep.Text = stepCount.ToString();
                currentPlayer = currentStep.playerNum;
                labelCurrPlayerNum.Text = currentPlayer.ToString();
            }
        }

        private void labelCurrPlayerNum_TextChanged(object sender, EventArgs e)
        {
            int argb = Color.Black.ToArgb();
            argb = currentPlayer == 1 ? p1.playerColorArgb : p2.playerColorArgb;
            labelCurrPlayerNum.ForeColor = Color.FromArgb(argb);
            labelCurrPlayer.ForeColor = Color.FromArgb(argb);
        }

        private void ResetBoard(int playerNum)
        {
            AssignControlVariables(playerNum);
            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b)
                {
                    int r = SubmarinesUtils.GetButtonIndices(b)[0];
                    b.BackColor = (r % 2 == 0) 
                        ? Properties.Settings.Default.DefaultButtonColor1 
                        : Properties.Settings.Default.DefaultButtonColor2;
                    b.BackgroundImage = null;
                }
            }
        }

        private void ResetBoardsAndLocations()
        {
            SubmarinesUtils.Copy2dArray(originalLocations2, boardLocations1);
            SubmarinesUtils.Copy2dArray(originalLocations1, boardLocations2);
            ResetBoard(1);
            ResetBoard(2);
        }

        private void ResetTopLabels()
        {
            labelCurrStep.Text = "0";
            labelCurrPlayerNum.Text = "0";
            labelCurrPlayer.ForeColor = SystemColors.ControlText;
            labelCurrPlayerNum.ForeColor = SystemColors.ControlText;
        }
        #endregion

        #region Weapon controls
        private void ClickDepthCharge2()
        {
            depthCharge2.BackColor = Color.FromArgb(p2.playerColorArgb);
            labelAirStrikeCount2.BackColor = Color.DarkGray;
            airStrike2.BackColor = Color.DarkGray;
        }

        private void ClickAirStrike2()
        {
            airStrike2.BackColor = Color.FromArgb(p2.playerColorArgb);
            labelAirStrikeCount2.BackColor = Color.FromArgb(p2.playerColorArgb);
            depthCharge2.BackColor = Color.DarkGray;
        }

        private void ClickAirStrike1()
        {
            airStrike1.BackColor = Color.FromArgb(p1.playerColorArgb);
            labelAirStrikeCount1.BackColor = Color.FromArgb(p1.playerColorArgb);
            depthCharge1.BackColor = Color.DarkGray;
        }

        private void ClickDepthCharge1()
        {
            depthCharge1.BackColor = Color.FromArgb(p1.playerColorArgb);
            labelAirStrikeCount1.BackColor = Color.DarkGray;
            airStrike1.BackColor = Color.DarkGray;
        }
        #endregion

        #region Hitting and Sinking, Endgame Revealing
        private bool HitSquare(int row, int col, Button button = null)
        {
            if (currentLocations[row, col] == 0)
            {
                button?.Invoke(new Action(() => button.BackColor = SystemColors.Control));
                currentLocations[row, col] = -999;
                return false;
            }
            else
            {
                button?.Invoke(new Action(() => button.BackColor = Color.Red));
                currentLocations[row, col] = -Math.Abs(currentLocations[row, col]);
                return true;
            }
        }

        private bool CheckAndSink(int subId, bool makeVisibleChanges)
        {
            Submarine selectedSub = game.submarines.FirstOrDefault(sub => sub.subId == subId);
            if (selectedSub == null) { return false; }

            int remainingSquares = currentLocations.Cast<int>().Count(val => val == subId);
            bool sunk = selectedSub.IsSunk(dataConnection, remainingSquares);
            if (!sunk) { return false; }

            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b)
                {
                    int[] indices = SubmarinesUtils.GetButtonIndices(b);
                    int r = indices[0];
                    int c = indices[1];

                    if (Math.Abs(currentLocations[r, c]) == subId)
                    {
                        if (makeVisibleChanges)
                        {
                            b.BackgroundImage = Properties.Resources.DestroyedX;
                        }
                        currentLocations[r, c] = -subId;
                    }
                }
            }
            return true;
        }

        private void btnReveal_VisibleChanged(object sender, EventArgs e)
        {
            int argb = currentPlayer == 1 ? p1.playerColorArgb : p2.playerColorArgb;
            btnReveal.BackColor = Color.FromArgb(argb);
            btnReveal.Enabled = true;
        }

        private void buttonReveal_Click(object sender, EventArgs e)
        {
            btnReveal.Enabled = false;
            AssignControlVariables(currentPlayer == 1 ? 2 : 1);
            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b && b.BackColor != SystemColors.Control)
                {
                    int[] indices = SubmarinesUtils.GetButtonIndices(b);
                    int r = indices[0];
                    int c = indices[1];

                    if (currentLocations[r, c] != 0)
                    {
                        b.BackgroundImage = Properties.Resources.DestroyedX;
                    }
                }
            }
        }
        #endregion

        #region Replaying Logic
        private void RerunLocationsUpToStep(int targetStepIndex, ButtonAction buttonAction)
        {
            if (buttonAction == ButtonAction.Next)
            {
                ResetBoard(currentPlayer);
                SubmarinesUtils.Copy2dArray(currentOriginalLocations, currentLocations);
                remainingSubsCounters[currentPlayer - 1] = game.submarines.Count;
                airStrikeCounters[currentPlayer - 1] = 1;
            }
            else
            {
                remainingSubsCounters = new int[2] { game.submarines.Count, game.submarines.Count };
                airStrikeCounters = new int[2] { 1, 1 };
                ResetBoardsAndLocations();
            }

            for (int i = 0; i <= targetStepIndex; i++)
            {
                Step step = stepsList[i];
                AssignControlVariables(step.playerNum);
                LoadNextStepToLocations(step);
            }
        }

        private void LoadNextStepToLocations(Step nextStep)
        {
            int bRow = nextStep.row;
            int bCol = nextStep.col;

            if (!nextStep.isAirStrike)
            {
                int subId = currentLocations[bRow, bCol];
                if (HitSquare(bRow, bCol))
                {
                    if (CheckAndSink(subId, false))
                    {
                        if (subSinkingIndecies[subId - 1] == 0)
                        {
                            subSinkingIndecies[subId - 1] = nextStep.orderNum - 1;
                        }
                        remainingSubsCounters[nextStep.playerNum - 1] -= 1;
                        airStrikeCounters[nextStep.playerNum - 1] += 1;
                    }
                }
            }
            else
            {
                airStrikeCounters[nextStep.playerNum - 1] -= 1;
                foreach (Control ctrl in currentBoard.Controls)
                {
                    if (ctrl is Button btn)
                    {
                        int[] indices = SubmarinesUtils.GetButtonIndices(btn);
                        int r = indices[0];
                        int c = indices[1];

                        if (Math.Abs(r - bRow) <= 1 && Math.Abs(c - bCol) <= 1)
                        {
                            int subId = currentLocations[r, c];
                            if (currentLocations[r, c] == 0)
                            {
                                currentLocations[r, c] = -999;
                            }
                            else if (currentLocations[r, c] > 0)
                            {
                                currentLocations[r, c] = -subId;
                                if (CheckAndSink(subId, false))
                                {
                                    if (subSinkingIndecies[subId - 1] == 0)
                                    {
                                        subSinkingIndecies[subId - 1] = nextStep.orderNum - 1;
                                    }
                                    remainingSubsCounters[nextStep.playerNum - 1] -= 1;
                                    airStrikeCounters[nextStep.playerNum - 1] += 1;
                                }
                            }
                        }
                    }
                }
            }
        }

        private void LoadToBoardFromLocations(int playerNum, ButtonAction btnAction)
        {
            bool displaySinkMsg = false;
            AssignControlVariables(playerNum);
            for (int i = 0; i < game.submarines.Count; i++)
            {
                int id = game.submarines[i].subId;
                if (CheckAndSink(id, true) && subSinkingIndecies[id - 1] == currentStepIndex)
                {
                    displaySinkMsg = true;
                }
            }
            HitRemainingSquares();
            currentRemainingSubs.Text = remainingSubsCounters[playerNum - 1].ToString();
            currentAirStrikeCount.Text = airStrikeCounters[playerNum - 1].ToString();
            if (!isAutoReplaying && displaySinkMsg && btnAction != ButtonAction.Last)
            {
                MessageBox.Show($"שחקן {currentPlayer} הטביע צוללת אויב!", "!הטבעה",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void HitRemainingSquares()
        {
            foreach (Control ctrl in currentBoard.Controls)
            {
                if (ctrl is Button b)
                {
                    int[] indices = SubmarinesUtils.GetButtonIndices(b);
                    int r = indices[0];
                    int c = indices[1];
                    int value = currentLocations[r, c];

                    if (value < 0)
                    {
                        b.BackColor = value == -999 ? SystemColors.Control : Color.Red;
                    }
                }
            }
        }
        #endregion

        #region Step Control Buttons
        private void btnReset_Click(object sender, EventArgs e)
        {
            btnStartStop.Enabled = true;
            btnLast.Enabled = true;
            btnNext.Enabled = true;
            btnPrev.Enabled = false;
            btnReset.Enabled = false;
            btnReveal.Visible = false;

            currentPlayer = 0;
            ResetTopLabels();

            rmnSubs1.Text = game.submarines.Count.ToString();
            rmnSubs2.Text = game.submarines.Count.ToString();

            currentStepIndex = -1;
            stepCount = 0;

            ResetBoardsAndLocations();

            labelAirStrikeCount1.Text = 1.ToString();
            labelAirStrikeCount2.Text = 1.ToString();

            subSinkingIndecies1 = new int[BIGGEST_SUB_ID];
            subSinkingIndecies2 = new int[BIGGEST_SUB_ID];

            ClickDepthCharge1();
            ClickDepthCharge2();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            currentStepIndex++;

            if (currentStepIndex == stepsList.Count) { currentStepIndex--; return; }
            if (currentStepIndex == stepsList.Count - 1)
            {
                btnNext.Enabled = false;
                btnLast.Enabled = false;
                btnReveal.Visible = true;
            }
            if (!isAutoReplaying)
            {
                btnPrev.Enabled = true;
                btnReset.Enabled = true;
            }

            Step currStep = stepsList[currentStepIndex];
            UpdateHUDItems(currStep, ButtonAction.Next);

            RerunLocationsUpToStep(currentStepIndex, ButtonAction.Next);
            LoadToBoardFromLocations(currentPlayer, ButtonAction.Next);

        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            currentStepIndex--;
            if (currentStepIndex < -1) { return; }
            if (currentStepIndex == -1)
            {
                btnReset_Click(null, EventArgs.Empty);
                return;
            }
            btnNext.Enabled = true;
            btnLast.Enabled = true;
            btnStartStop.Enabled = true;
            btnReveal.Visible = false;

            Step currStep = stepsList[currentStepIndex];
            UpdateHUDItems(currStep, ButtonAction.Previous);

            RerunLocationsUpToStep(currentStepIndex, ButtonAction.Previous);
            LoadToBoardFromLocations(1, ButtonAction.Previous);
            LoadToBoardFromLocations(2, ButtonAction.Previous);
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            btnStartStop.Enabled = false;
            btnLast.Enabled = false;
            btnNext.Enabled = false;
            btnPrev.Enabled = true;
            btnReset.Enabled = true;

            currentStepIndex = stepsList.Count - 1;
            Step currStep = stepsList[currentStepIndex];
            UpdateHUDItems(currStep, ButtonAction.Last);

            RerunLocationsUpToStep(currentStepIndex, ButtonAction.Last);
            LoadToBoardFromLocations(1, ButtonAction.Last);
            LoadToBoardFromLocations(2, ButtonAction.Last);

            btnReveal.Visible = true;
        }
        #endregion

        #region Auto Replay Controls
        private void replaySpeedBar_ValueChanged(object sender, EventArgs e)
        {
            switch (replaySpeedBar.Value)
            {
                case 0: replayTimer.Interval = 800; break;
                case 1: replayTimer.Interval = 550; break;
                case 2: replayTimer.Interval = 300; break;
            }
        }

        private void btnStartStop_Click(object sender, EventArgs e)
        {
            if (isAutoReplaying)
            {
                btnNext.Enabled = true;
                btnPrev.Enabled = true;
                btnReset.Enabled = true;
                btnLast.Enabled = true;

                replayTimer.Stop();

            }
            else
            {
                btnNext.Enabled = false;
                btnPrev.Enabled = false;
                btnReset.Enabled = false;
                btnLast.Enabled = false;

                replayTimer.Start();
            }
            isAutoReplaying = !isAutoReplaying;
        }

        private void ReplayTimer_Tick(object sender, EventArgs e)
        {
            if (currentStepIndex < stepsList.Count - 1)
            {
                btnNext_Click(null, EventArgs.Empty);
            }
            else
            {
                btnStartStop_Click(null, EventArgs.Empty);
                btnStartStop.Enabled = false;
            }
        }
        #endregion

        private void helpButton_Click(object sender, EventArgs e)
        {
            if (isAutoReplaying) { btnStartStop_Click(null, EventArgs.Empty); }

            FormHelpGameReplay helpGameReplay = new FormHelpGameReplay();
            helpGameReplay.Height = panel1.Height;
            helpGameReplay.Show();
        }

        private void FormGameReplay_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
