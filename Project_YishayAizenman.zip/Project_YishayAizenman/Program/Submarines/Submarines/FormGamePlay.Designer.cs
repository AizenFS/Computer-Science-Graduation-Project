﻿namespace Submarines
{
    partial class FormGamePlay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonReveal = new System.Windows.Forms.Button();
            this.labelComputerPlayer = new System.Windows.Forms.Label();
            this.labelCurrPlayerNum = new System.Windows.Forms.Label();
            this.labelCurrPlayer = new System.Windows.Forms.Label();
            this.rmnSubs2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rmnSubs1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.airStrikeCount2 = new System.Windows.Forms.Label();
            this.airStrikeCount1 = new System.Windows.Forms.Label();
            this.airStrike1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.depthCharge1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.airStrike2 = new System.Windows.Forms.PictureBox();
            this.depthCharge2 = new System.Windows.Forms.PictureBox();
            this.helpButton = new System.Windows.Forms.Button();
            this.NP1 = new Submarines.playerNameAndPic();
            this.labelP2 = new System.Windows.Forms.Label();
            this.NP2 = new Submarines.playerNameAndPic();
            this.labelP1 = new System.Windows.Forms.Label();
            this.board2 = new System.Windows.Forms.Panel();
            this.board1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.buttonReveal);
            this.panel1.Controls.Add(this.labelComputerPlayer);
            this.panel1.Controls.Add(this.labelCurrPlayerNum);
            this.panel1.Controls.Add(this.labelCurrPlayer);
            this.panel1.Controls.Add(this.rmnSubs2);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.rmnSubs1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.airStrikeCount2);
            this.panel1.Controls.Add(this.airStrikeCount1);
            this.panel1.Controls.Add(this.airStrike1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.depthCharge1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.airStrike2);
            this.panel1.Controls.Add(this.depthCharge2);
            this.panel1.Controls.Add(this.helpButton);
            this.panel1.Controls.Add(this.NP1);
            this.panel1.Controls.Add(this.labelP2);
            this.panel1.Controls.Add(this.NP2);
            this.panel1.Controls.Add(this.labelP1);
            this.panel1.Controls.Add(this.board2);
            this.panel1.Controls.Add(this.board1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1900, 1026);
            this.panel1.TabIndex = 12;
            // 
            // buttonReveal
            // 
            this.buttonReveal.BackColor = System.Drawing.Color.Tomato;
            this.buttonReveal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.buttonReveal.Location = new System.Drawing.Point(866, 228);
            this.buttonReveal.Name = "buttonReveal";
            this.buttonReveal.Size = new System.Drawing.Size(215, 44);
            this.buttonReveal.TabIndex = 113;
            this.buttonReveal.Text = "חשוף את כל הצוללות";
            this.buttonReveal.UseVisualStyleBackColor = false;
            this.buttonReveal.Visible = false;
            this.buttonReveal.Click += new System.EventHandler(this.buttonReveal_Click);
            // 
            // labelComputerPlayer
            // 
            this.labelComputerPlayer.AutoSize = true;
            this.labelComputerPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelComputerPlayer.Location = new System.Drawing.Point(62, 248);
            this.labelComputerPlayer.Name = "labelComputerPlayer";
            this.labelComputerPlayer.Size = new System.Drawing.Size(163, 37);
            this.labelComputerPlayer.TabIndex = 111;
            this.labelComputerPlayer.Text = "שחקן מחשב";
            // 
            // labelCurrPlayerNum
            // 
            this.labelCurrPlayerNum.AutoSize = true;
            this.labelCurrPlayerNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrPlayerNum.Location = new System.Drawing.Point(844, 171);
            this.labelCurrPlayerNum.Name = "labelCurrPlayerNum";
            this.labelCurrPlayerNum.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelCurrPlayerNum.Size = new System.Drawing.Size(36, 37);
            this.labelCurrPlayerNum.TabIndex = 100;
            this.labelCurrPlayerNum.Text = "0";
            this.labelCurrPlayerNum.TextChanged += new System.EventHandler(this.labelCurrPlayerNum_TextChanged);
            // 
            // labelCurrPlayer
            // 
            this.labelCurrPlayer.AutoSize = true;
            this.labelCurrPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCurrPlayer.Location = new System.Drawing.Point(874, 171);
            this.labelCurrPlayer.Name = "labelCurrPlayer";
            this.labelCurrPlayer.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelCurrPlayer.Size = new System.Drawing.Size(198, 37);
            this.labelCurrPlayer.TabIndex = 99;
            this.labelCurrPlayer.Text = "השחקן הנוכחי:";
            // 
            // rmnSubs2
            // 
            this.rmnSubs2.Enabled = false;
            this.rmnSubs2.Location = new System.Drawing.Point(50, 946);
            this.rmnSubs2.Name = "rmnSubs2";
            this.rmnSubs2.Size = new System.Drawing.Size(49, 26);
            this.rmnSubs2.TabIndex = 98;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(107, 932);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(145, 40);
            this.label9.TabIndex = 97;
            this.label9.Text = "מספר צוללות אויב\r\nשנותרו:";
            // 
            // rmnSubs1
            // 
            this.rmnSubs1.Enabled = false;
            this.rmnSubs1.Location = new System.Drawing.Point(1635, 946);
            this.rmnSubs1.Name = "rmnSubs1";
            this.rmnSubs1.Size = new System.Drawing.Size(49, 26);
            this.rmnSubs1.TabIndex = 96;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1705, 932);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(145, 40);
            this.label8.TabIndex = 95;
            this.label8.Text = "מספר צוללות אויב\r\nשנותרו:";
            // 
            // airStrikeCount2
            // 
            this.airStrikeCount2.AutoSize = true;
            this.airStrikeCount2.Enabled = false;
            this.airStrikeCount2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.airStrikeCount2.Location = new System.Drawing.Point(236, 865);
            this.airStrikeCount2.Name = "airStrikeCount2";
            this.airStrikeCount2.Size = new System.Drawing.Size(27, 29);
            this.airStrikeCount2.TabIndex = 94;
            this.airStrikeCount2.Text = "1";
            this.airStrikeCount2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // airStrikeCount1
            // 
            this.airStrikeCount1.AutoSize = true;
            this.airStrikeCount1.Enabled = false;
            this.airStrikeCount1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.airStrikeCount1.Location = new System.Drawing.Point(1630, 865);
            this.airStrikeCount1.Name = "airStrikeCount1";
            this.airStrikeCount1.Size = new System.Drawing.Size(27, 29);
            this.airStrikeCount1.TabIndex = 93;
            this.airStrikeCount1.Text = "1";
            this.airStrikeCount1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // airStrike1
            // 
            this.airStrike1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.airStrike1.Location = new System.Drawing.Point(1625, 714);
            this.airStrike1.Name = "airStrike1";
            this.airStrike1.Size = new System.Drawing.Size(148, 184);
            this.airStrike1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.airStrike1.TabIndex = 90;
            this.airStrike1.TabStop = false;
            this.airStrike1.Click += new System.EventHandler(this.airStrike1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1655, 658);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(101, 40);
            this.label5.TabIndex = 91;
            this.label5.Text = "הפגזה אווירית\r\nפגיעה: 3 על 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1785, 658);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(101, 40);
            this.label7.TabIndex = 88;
            this.label7.Text = "פצצת עומק\r\nפגיעה: 1 על 1";
            // 
            // depthCharge1
            // 
            this.depthCharge1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.depthCharge1.Image = global::Submarines.Properties.Resources.DepthChargeTurned;
            this.depthCharge1.Location = new System.Drawing.Point(1788, 714);
            this.depthCharge1.Name = "depthCharge1";
            this.depthCharge1.Size = new System.Drawing.Size(94, 184);
            this.depthCharge1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.depthCharge1.TabIndex = 89;
            this.depthCharge1.TabStop = false;
            this.depthCharge1.Click += new System.EventHandler(this.depthCharge1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(151, 658);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(101, 40);
            this.label3.TabIndex = 85;
            this.label3.Text = "הפגזה אווירית\r\nפגיעה: 3 על 3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 658);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(101, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "פצצת עומק\r\nפגיעה: 1 על 1";
            // 
            // airStrike2
            // 
            this.airStrike2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.airStrike2.Image = global::Submarines.Properties.Resources.AirStrike;
            this.airStrike2.Location = new System.Drawing.Point(121, 714);
            this.airStrike2.Name = "airStrike2";
            this.airStrike2.Size = new System.Drawing.Size(148, 184);
            this.airStrike2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.airStrike2.TabIndex = 84;
            this.airStrike2.TabStop = false;
            this.airStrike2.Click += new System.EventHandler(this.airStrike2_Click);
            // 
            // depthCharge2
            // 
            this.depthCharge2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.depthCharge2.Image = global::Submarines.Properties.Resources.DepthChargeTurned;
            this.depthCharge2.Location = new System.Drawing.Point(12, 714);
            this.depthCharge2.Name = "depthCharge2";
            this.depthCharge2.Size = new System.Drawing.Size(94, 184);
            this.depthCharge2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.depthCharge2.TabIndex = 83;
            this.depthCharge2.TabStop = false;
            this.depthCharge2.Click += new System.EventHandler(this.depthCharge2_Click);
            // 
            // helpButton
            // 
            this.helpButton.BackColor = System.Drawing.SystemColors.Control;
            this.helpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(1785, 37);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(81, 34);
            this.helpButton.TabIndex = 82;
            this.helpButton.Text = "עזרה";
            this.helpButton.UseVisualStyleBackColor = false;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // NP1
            // 
            this.NP1.firstName = "";
            this.NP1.id = "";
            this.NP1.lastName = "";
            this.NP1.Location = new System.Drawing.Point(1651, 307);
            this.NP1.Name = "NP1";
            this.NP1.picLocation = "";
            this.NP1.Size = new System.Drawing.Size(210, 331);
            this.NP1.TabIndex = 76;
            // 
            // labelP2
            // 
            this.labelP2.AutoSize = true;
            this.labelP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP2.Location = new System.Drawing.Point(554, 248);
            this.labelP2.Name = "labelP2";
            this.labelP2.Size = new System.Drawing.Size(109, 37);
            this.labelP2.TabIndex = 78;
            this.labelP2.Text = "שחקן 2";
            // 
            // NP2
            // 
            this.NP2.firstName = "";
            this.NP2.id = "";
            this.NP2.lastName = "";
            this.NP2.Location = new System.Drawing.Point(50, 307);
            this.NP2.Name = "NP2";
            this.NP2.picLocation = "";
            this.NP2.Size = new System.Drawing.Size(210, 331);
            this.NP2.TabIndex = 77;
            // 
            // labelP1
            // 
            this.labelP1.AutoSize = true;
            this.labelP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP1.Location = new System.Drawing.Point(1223, 248);
            this.labelP1.Name = "labelP1";
            this.labelP1.Size = new System.Drawing.Size(107, 37);
            this.labelP1.TabIndex = 73;
            this.labelP1.Text = "שחקן 1";
            // 
            // board2
            // 
            this.board2.BackColor = System.Drawing.Color.Transparent;
            this.board2.BackgroundImage = global::Submarines.Properties.Resources.GameBackround;
            this.board2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.board2.Location = new System.Drawing.Point(296, 302);
            this.board2.Name = "board2";
            this.board2.Size = new System.Drawing.Size(656, 694);
            this.board2.TabIndex = 67;
            // 
            // board1
            // 
            this.board1.BackgroundImage = global::Submarines.Properties.Resources.GameBackround;
            this.board1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.board1.Location = new System.Drawing.Point(958, 302);
            this.board1.Name = "board1";
            this.board1.Size = new System.Drawing.Size(656, 694);
            this.board1.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(835, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 52);
            this.label2.TabIndex = 65;
            this.label2.Text = "משחק צוללות";
            // 
            // FormGamePlay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormGamePlay";
            this.Text = "FormGamePlay";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormGamePlay_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormGamePlay_FormClosed);
            this.Load += new System.EventHandler(this.FormGamePlay_Load);
            this.SizeChanged += new System.EventHandler(this.FormGamePlay_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.airStrike2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.depthCharge2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button helpButton;
        private playerNameAndPic NP1;
        private System.Windows.Forms.Label labelP2;
        private playerNameAndPic NP2;
        private System.Windows.Forms.Label labelP1;
        private System.Windows.Forms.Panel board2;
        private System.Windows.Forms.Panel board1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox depthCharge2;
        private System.Windows.Forms.PictureBox airStrike2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox depthCharge1;
        private System.Windows.Forms.PictureBox airStrike1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label airStrikeCount1;
        private System.Windows.Forms.Label airStrikeCount2;
        private System.Windows.Forms.TextBox rmnSubs1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox rmnSubs2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelCurrPlayer;
        private System.Windows.Forms.Label labelCurrPlayerNum;
        private System.Windows.Forms.Label labelComputerPlayer;
        private System.Windows.Forms.Button buttonReveal;
    }
}
