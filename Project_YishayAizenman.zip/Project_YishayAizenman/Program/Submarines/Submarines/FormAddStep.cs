﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormAddStep : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        public FormAddStep(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillGameIdCombo();
        }

        private void FillGameIdCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT g.gameID, g.gameDate, " +
                                             "p1.playerFirstName + ' ' + p1.playerLastName AS Player1Name, " +
                                             "p2.playerFirstName + ' ' + p2.playerLastName AS Player2Name " +
                                          "FROM (tblGames g " +
                                          "LEFT JOIN tblPlayers p1 ON g.gamePlayer1ID = p1.playerID) " +
                                          "LEFT JOIN tblPlayers p2 ON g.gamePlayer2ID = p2.playerID " +
                                          "ORDER BY g.gameID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    int gameID = dataReader.GetInt32(0);
                    string gameDate = dataReader.GetDateTime(1).ToString("yyyy/MM/dd");
                    string player1Name = dataReader.GetString(2);
                    string player2Name = dataReader.GetString(3);

                    string comboItem = $"{gameID}, {gameDate}, {player1Name} נגד {player2Name}";
                    gameId.Items.Add(comboItem);
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill game ID combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddStep_Load(object sender, EventArgs e)
        {
            this.tblStepsTableAdapter.Fill(this.dataSetSteps.tblSteps);
            dataGridView1.AllowUserToAddRows = false;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblSteps " +
                    "(stepGameID, stepOrderNum, stepPlayer, stepRow, stepCol) " +
                    "VALUES ({0}, {1}, {2}, {3}, {4})",
                    SubmarinesUtils.GetIdFromDetails(gameId.Text), orderNum.Text,
                    playerNum.Text, row.Text, col.Text);                    
                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblSteps ended successfully");
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblSteps failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM tblSteps ";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddStep_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
