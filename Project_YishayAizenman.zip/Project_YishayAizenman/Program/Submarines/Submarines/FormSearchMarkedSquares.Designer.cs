﻿namespace Submarines
{
    partial class FormSearchMarkedSquares
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.msSubIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msRowNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.msColNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblMarkedSquaresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetMarkedSquares = new Submarines.DataSetMarkedSquares();
            this.refreshButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.searchStr = new System.Windows.Forms.TextBox();
            this.tblMarkedSquaresTableAdapter = new Submarines.DataSetMarkedSquaresTableAdapters.tblMarkedSquaresTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMarkedSquaresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetMarkedSquares)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.refreshButton);
            this.panel1.Controls.Add(this.searchButton);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.searchStr);
            this.panel1.Location = new System.Drawing.Point(97, 53);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1778, 913);
            this.panel1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(625, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(471, 38);
            this.label2.TabIndex = 18;
            this.label2.Text = "חיפוש בטבלת משבצות מסומנות";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.msSubIDDataGridViewTextBoxColumn,
            this.msRowNumDataGridViewTextBoxColumn,
            this.msColNumDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblMarkedSquaresBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(632, 381);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(464, 520);
            this.dataGridView1.TabIndex = 15;
            // 
            // msSubIDDataGridViewTextBoxColumn
            // 
            this.msSubIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.msSubIDDataGridViewTextBoxColumn.DataPropertyName = "msSubID";
            this.msSubIDDataGridViewTextBoxColumn.HeaderText = "קוד צוללת";
            this.msSubIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msSubIDDataGridViewTextBoxColumn.Name = "msSubIDDataGridViewTextBoxColumn";
            this.msSubIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.msSubIDDataGridViewTextBoxColumn.Width = 114;
            // 
            // msRowNumDataGridViewTextBoxColumn
            // 
            this.msRowNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.msRowNumDataGridViewTextBoxColumn.DataPropertyName = "msRowNum";
            this.msRowNumDataGridViewTextBoxColumn.HeaderText = "שורה";
            this.msRowNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msRowNumDataGridViewTextBoxColumn.Name = "msRowNumDataGridViewTextBoxColumn";
            this.msRowNumDataGridViewTextBoxColumn.ReadOnly = true;
            this.msRowNumDataGridViewTextBoxColumn.Width = 79;
            // 
            // msColNumDataGridViewTextBoxColumn
            // 
            this.msColNumDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.msColNumDataGridViewTextBoxColumn.DataPropertyName = "msColNum";
            this.msColNumDataGridViewTextBoxColumn.HeaderText = "עמודה";
            this.msColNumDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.msColNumDataGridViewTextBoxColumn.Name = "msColNumDataGridViewTextBoxColumn";
            this.msColNumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblMarkedSquaresBindingSource
            // 
            this.tblMarkedSquaresBindingSource.DataMember = "tblMarkedSquares";
            this.tblMarkedSquaresBindingSource.DataSource = this.dataSetMarkedSquares;
            // 
            // dataSetMarkedSquares
            // 
            this.dataSetMarkedSquares.DataSetName = "DataSetMarkedSquares";
            this.dataSetMarkedSquares.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // refreshButton
            // 
            this.refreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Location = new System.Drawing.Point(556, 249);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(133, 53);
            this.refreshButton.TabIndex = 3;
            this.refreshButton.Text = "רענן";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Location = new System.Drawing.Point(719, 249);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(133, 53);
            this.searchButton.TabIndex = 2;
            this.searchButton.Text = "חפש";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1075, 269);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "טקסט לחיפוש:";
            // 
            // searchStr
            // 
            this.searchStr.Location = new System.Drawing.Point(906, 266);
            this.searchStr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.searchStr.Name = "searchStr";
            this.searchStr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchStr.Size = new System.Drawing.Size(148, 26);
            this.searchStr.TabIndex = 1;
            // 
            // tblMarkedSquaresTableAdapter
            // 
            this.tblMarkedSquaresTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(908, 353);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(188, 25);
            this.label4.TabIndex = 36;
            this.label4.Text = "טבלת משבצות מסומנות";
            // 
            // FormSearchMarkedSquares
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormSearchMarkedSquares";
            this.Text = "FormSearchMarkedSquares";
            this.Load += new System.EventHandler(this.FormSearchMarkedSquares_Load);
            this.SizeChanged += new System.EventHandler(this.FormSearchMarkedSquares_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMarkedSquaresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetMarkedSquares)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox searchStr;
        private System.Windows.Forms.Label label2;
        private DataSetMarkedSquares dataSetMarkedSquares;
        private System.Windows.Forms.BindingSource tblMarkedSquaresBindingSource;
        private DataSetMarkedSquaresTableAdapters.tblMarkedSquaresTableAdapter tblMarkedSquaresTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn msSubIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn msRowNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn msColNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label4;
    }
}
