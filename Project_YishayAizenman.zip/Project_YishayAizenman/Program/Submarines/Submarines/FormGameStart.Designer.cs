﻿namespace Submarines
{
    partial class FormGameStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.brdSubRatio = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.helpButton = new System.Windows.Forms.Button();
            this.ttlSubSqrs = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ttlBoardSqrs = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.bCols = new System.Windows.Forms.NumericUpDown();
            this.bRows = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.checkListSubs = new System.Windows.Forms.CheckedListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBotPlayer = new System.Windows.Forms.ComboBox();
            this.btnContinue = new System.Windows.Forms.Button();
            this.bgnMsg = new System.Windows.Forms.Label();
            this.vs = new System.Windows.Forms.Label();
            this.p2pic = new System.Windows.Forms.PictureBox();
            this.p1pic = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRoll2 = new System.Windows.Forms.Button();
            this.btnRoll1 = new System.Windows.Forms.Button();
            this.cube2 = new System.Windows.Forms.PictureBox();
            this.cube1 = new System.Windows.Forms.PictureBox();
            this.btnColor2 = new System.Windows.Forms.Button();
            this.col2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboId2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnColor1 = new System.Windows.Forms.Button();
            this.col1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboId1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.subPreviewTT = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bCols)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bRows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cube2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cube1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.brdSubRatio);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.helpButton);
            this.panel1.Controls.Add(this.ttlSubSqrs);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.ttlBoardSqrs);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.bCols);
            this.panel1.Controls.Add(this.bRows);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.checkListSubs);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.comboBotPlayer);
            this.panel1.Controls.Add(this.btnContinue);
            this.panel1.Controls.Add(this.bgnMsg);
            this.panel1.Controls.Add(this.vs);
            this.panel1.Controls.Add(this.p2pic);
            this.panel1.Controls.Add(this.p1pic);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnRoll2);
            this.panel1.Controls.Add(this.btnRoll1);
            this.panel1.Controls.Add(this.cube2);
            this.panel1.Controls.Add(this.cube1);
            this.panel1.Controls.Add(this.btnColor2);
            this.panel1.Controls.Add(this.col2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.comboId2);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.btnColor1);
            this.panel1.Controls.Add(this.col1);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.comboId1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(50, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1836, 989);
            this.panel1.TabIndex = 11;
            // 
            // brdSubRatio
            // 
            this.brdSubRatio.Enabled = false;
            this.brdSubRatio.Location = new System.Drawing.Point(1383, 922);
            this.brdSubRatio.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.brdSubRatio.Name = "brdSubRatio";
            this.brdSubRatio.Size = new System.Drawing.Size(100, 26);
            this.brdSubRatio.TabIndex = 85;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1526, 908);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 40);
            this.label1.TabIndex = 84;
            this.label1.Text = "יחס משבצות לוח \r\nלמשבצות צוללות";
            // 
            // helpButton
            // 
            this.helpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(1752, 3);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(81, 34);
            this.helpButton.TabIndex = 83;
            this.helpButton.Text = "עזרה";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // ttlSubSqrs
            // 
            this.ttlSubSqrs.Enabled = false;
            this.ttlSubSqrs.Location = new System.Drawing.Point(1383, 869);
            this.ttlSubSqrs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ttlSubSqrs.Name = "ttlSubSqrs";
            this.ttlSubSqrs.Size = new System.Drawing.Size(100, 26);
            this.ttlSubSqrs.TabIndex = 82;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1516, 857);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(137, 40);
            this.label14.TabIndex = 81;
            this.label14.Text = "סכום משבצות כולל \r\nשל צוללות שנבחרו";
            // 
            // ttlBoardSqrs
            // 
            this.ttlBoardSqrs.Enabled = false;
            this.ttlBoardSqrs.Location = new System.Drawing.Point(1383, 819);
            this.ttlBoardSqrs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ttlBoardSqrs.Name = "ttlBoardSqrs";
            this.ttlBoardSqrs.Size = new System.Drawing.Size(100, 26);
            this.ttlBoardSqrs.TabIndex = 80;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1511, 805);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label13.Size = new System.Drawing.Size(142, 40);
            this.label13.TabIndex = 79;
            this.label13.Text = "מספר משבצות כולל \r\nבלוח\r\n";
            // 
            // bCols
            // 
            this.bCols.Location = new System.Drawing.Point(1385, 763);
            this.bCols.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.bCols.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.bCols.Name = "bCols";
            this.bCols.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bCols.Size = new System.Drawing.Size(92, 26);
            this.bCols.TabIndex = 9;
            this.bCols.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.bCols.ValueChanged += new System.EventHandler(this.bCols_ValueChanged);
            // 
            // bRows
            // 
            this.bRows.Location = new System.Drawing.Point(1385, 719);
            this.bRows.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.bRows.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.bRows.Name = "bRows";
            this.bRows.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bRows.Size = new System.Drawing.Size(92, 26);
            this.bRows.TabIndex = 8;
            this.bRows.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.bRows.ValueChanged += new System.EventHandler(this.bRows_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1555, 765);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 20);
            this.label11.TabIndex = 76;
            this.label11.Text = "מספר עמודות";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1564, 721);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 20);
            this.label12.TabIndex = 75;
            this.label12.Text = "מספר שורות";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1385, 609);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label10.Size = new System.Drawing.Size(275, 40);
            this.label10.TabIndex = 74;
            this.label10.Text = "בחירת גודל לוח:";
            // 
            // checkListSubs
            // 
            this.checkListSubs.FormattingEnabled = true;
            this.checkListSubs.Location = new System.Drawing.Point(117, 673);
            this.checkListSubs.Name = "checkListSubs";
            this.checkListSubs.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.checkListSubs.Size = new System.Drawing.Size(418, 280);
            this.checkListSubs.TabIndex = 10;
            this.checkListSubs.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkListSubs_ItemCheck);
            this.checkListSubs.MouseMove += new System.Windows.Forms.MouseEventHandler(this.checkListSubs_MouseMove);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(293, 609);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(249, 40);
            this.label9.TabIndex = 72;
            this.label9.Text = "בחירת צוללות:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(993, 445);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 20);
            this.label8.TabIndex = 71;
            this.label8.Text = "שחקן אוטומטי - מחשב";
            // 
            // comboBotPlayer
            // 
            this.comboBotPlayer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBotPlayer.Enabled = false;
            this.comboBotPlayer.FormattingEnabled = true;
            this.comboBotPlayer.Location = new System.Drawing.Point(742, 442);
            this.comboBotPlayer.Name = "comboBotPlayer";
            this.comboBotPlayer.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBotPlayer.Size = new System.Drawing.Size(227, 28);
            this.comboBotPlayer.TabIndex = 5;
            // 
            // btnContinue
            // 
            this.btnContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinue.Location = new System.Drawing.Point(864, 876);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(144, 77);
            this.btnContinue.TabIndex = 11;
            this.btnContinue.Text = "המשך";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Visible = false;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // bgnMsg
            // 
            this.bgnMsg.AutoSize = true;
            this.bgnMsg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bgnMsg.Location = new System.Drawing.Point(1044, 876);
            this.bgnMsg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bgnMsg.Name = "bgnMsg";
            this.bgnMsg.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bgnMsg.Size = new System.Drawing.Size(87, 29);
            this.bgnMsg.TabIndex = 68;
            this.bgnMsg.Text = "מתחיל:";
            this.bgnMsg.Visible = false;
            // 
            // vs
            // 
            this.vs.AutoSize = true;
            this.vs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vs.Location = new System.Drawing.Point(937, 288);
            this.vs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.vs.Name = "vs";
            this.vs.Size = new System.Drawing.Size(44, 29);
            this.vs.TabIndex = 67;
            this.vs.Text = "נגד";
            this.vs.Visible = false;
            // 
            // p2pic
            // 
            this.p2pic.Location = new System.Drawing.Point(683, 215);
            this.p2pic.Name = "p2pic";
            this.p2pic.Size = new System.Drawing.Size(187, 187);
            this.p2pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p2pic.TabIndex = 66;
            this.p2pic.TabStop = false;
            // 
            // p1pic
            // 
            this.p1pic.Location = new System.Drawing.Point(1051, 215);
            this.p1pic.Name = "p1pic";
            this.p1pic.Size = new System.Drawing.Size(187, 187);
            this.p1pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p1pic.TabIndex = 65;
            this.p1pic.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(793, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 52);
            this.label2.TabIndex = 64;
            this.label2.Text = "הגדרות משחק";
            // 
            // btnRoll2
            // 
            this.btnRoll2.Enabled = false;
            this.btnRoll2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoll2.Location = new System.Drawing.Point(329, 497);
            this.btnRoll2.Name = "btnRoll2";
            this.btnRoll2.Size = new System.Drawing.Size(188, 65);
            this.btnRoll2.TabIndex = 7;
            this.btnRoll2.Text = "הטל קובייה";
            this.btnRoll2.UseVisualStyleBackColor = true;
            this.btnRoll2.Click += new System.EventHandler(this.btnRoll2_Click);
            // 
            // btnRoll1
            // 
            this.btnRoll1.Enabled = false;
            this.btnRoll1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoll1.Location = new System.Drawing.Point(1408, 497);
            this.btnRoll1.Name = "btnRoll1";
            this.btnRoll1.Size = new System.Drawing.Size(187, 65);
            this.btnRoll1.TabIndex = 6;
            this.btnRoll1.Text = "הטל קובייה";
            this.btnRoll1.UseVisualStyleBackColor = true;
            this.btnRoll1.Click += new System.EventHandler(this.btnRoll1_Click);
            // 
            // cube2
            // 
            this.cube2.Location = new System.Drawing.Point(683, 497);
            this.cube2.Name = "cube2";
            this.cube2.Size = new System.Drawing.Size(187, 187);
            this.cube2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cube2.TabIndex = 60;
            this.cube2.TabStop = false;
            // 
            // cube1
            // 
            this.cube1.Location = new System.Drawing.Point(1051, 497);
            this.cube1.Name = "cube1";
            this.cube1.Size = new System.Drawing.Size(187, 187);
            this.cube1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cube1.TabIndex = 59;
            this.cube1.TabStop = false;
            // 
            // btnColor2
            // 
            this.btnColor2.Location = new System.Drawing.Point(320, 359);
            this.btnColor2.Name = "btnColor2";
            this.btnColor2.Size = new System.Drawing.Size(35, 35);
            this.btnColor2.TabIndex = 4;
            this.btnColor2.Text = "...";
            this.btnColor2.UseVisualStyleBackColor = true;
            this.btnColor2.Click += new System.EventHandler(this.btnColor2_Click);
            // 
            // col2
            // 
            this.col2.Enabled = false;
            this.col2.Location = new System.Drawing.Point(357, 363);
            this.col2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.col2.Name = "col2";
            this.col2.Size = new System.Drawing.Size(178, 26);
            this.col2.TabIndex = 57;
            this.col2.Text = "< color selector";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(557, 368);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 20);
            this.label6.TabIndex = 56;
            this.label6.Text = "צבע שחקן 2";
            // 
            // comboId2
            // 
            this.comboId2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboId2.FormattingEnabled = true;
            this.comboId2.Location = new System.Drawing.Point(320, 285);
            this.comboId2.Name = "comboId2";
            this.comboId2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboId2.Size = new System.Drawing.Size(215, 28);
            this.comboId2.TabIndex = 2;
            this.comboId2.SelectedIndexChanged += new System.EventHandler(this.comboId2_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(569, 288);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 54;
            this.label7.Text = "תז שחקן 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(429, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(219, 40);
            this.label5.TabIndex = 53;
            this.label5.Text = "פרטי שחקן 2";
            // 
            // btnColor1
            // 
            this.btnColor1.Location = new System.Drawing.Point(1278, 359);
            this.btnColor1.Name = "btnColor1";
            this.btnColor1.Size = new System.Drawing.Size(35, 35);
            this.btnColor1.TabIndex = 3;
            this.btnColor1.Text = "...";
            this.btnColor1.UseVisualStyleBackColor = true;
            this.btnColor1.Click += new System.EventHandler(this.btnColor1_Click);
            // 
            // col1
            // 
            this.col1.Enabled = false;
            this.col1.Location = new System.Drawing.Point(1315, 362);
            this.col1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.col1.Name = "col1";
            this.col1.Size = new System.Drawing.Size(178, 26);
            this.col1.TabIndex = 51;
            this.col1.Text = "< color selector";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1504, 366);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 20);
            this.label15.TabIndex = 50;
            this.label15.Text = "צבע שחקן 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1376, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(219, 40);
            this.label4.TabIndex = 49;
            this.label4.Text = "פרטי שחקן 1";
            // 
            // comboId1
            // 
            this.comboId1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboId1.FormattingEnabled = true;
            this.comboId1.Location = new System.Drawing.Point(1278, 285);
            this.comboId1.Name = "comboId1";
            this.comboId1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboId1.Size = new System.Drawing.Size(215, 28);
            this.comboId1.TabIndex = 1;
            this.comboId1.SelectedIndexChanged += new System.EventHandler(this.comboId1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1516, 288);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 20);
            this.label3.TabIndex = 47;
            this.label3.Text = "תז שחקן 1";
            // 
            // FormGameStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormGameStart";
            this.Text = "FormGameStart";
            this.SizeChanged += new System.EventHandler(this.FormGameStart_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bCols)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bRows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p1pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cube2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cube1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboId1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnColor2;
        private System.Windows.Forms.TextBox col2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboId2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox col1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox cube1;
        private System.Windows.Forms.Button btnRoll2;
        private System.Windows.Forms.Button btnRoll1;
        private System.Windows.Forms.PictureBox cube2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox p1pic;
        private System.Windows.Forms.Label vs;
        private System.Windows.Forms.PictureBox p2pic;
        private System.Windows.Forms.Label bgnMsg;
        private System.Windows.Forms.Button btnColor1;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.ComboBox comboBotPlayer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckedListBox checkListSubs;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown bCols;
        private System.Windows.Forms.NumericUpDown bRows;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox ttlBoardSqrs;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox ttlSubSqrs;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.TextBox brdSubRatio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolTip subPreviewTT;
    }
}
