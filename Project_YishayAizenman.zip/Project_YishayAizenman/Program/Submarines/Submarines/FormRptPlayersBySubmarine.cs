﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormRptPlayersBySubmarine : Submarines.FormBaseReport
    {
        private OleDbConnection dataConnection;
        private string saveColor = "";

        public FormRptPlayersBySubmarine(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillSubmarinesCombo();
            listView1.FullRowSelect = true;
        }

        private void FillSubmarinesCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT subID, subName " +
                                          "FROM tblSubmarines " +
                                          "ORDER BY subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    subId.Items.Add(dataReader.GetInt32(0).ToString() + ", " + dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarines combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #region Button evets
        private void buttonClear_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            subId.Items.Clear();
            playerNameAndPic1.Visible = false;
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            try
            {
                if (subId.Text != "")
                {
                    EditListView(GetPlayerDetails());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("showing report failed " +
                    ex.Message, "Errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            buttonColor.ForeColor = cd.Color;
            saveColor = buttonColor.ForeColor.ToArgb().ToString();
        }
        #endregion

        #region Report logic
        private ArrayList GetPlayerDetails()
        {
            try
            {
                ArrayList list = new ArrayList();

                

                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                "SELECT s.subID, s.subName, p.playerID, p.playerFirstName, p.playerLastName," +
                "       p.playerAddress, p.playerCityID, p.playerIsManager, p.playerIsActive," +
                "       p.playerPhone, p.playerMail, p.playerPicture  " +
                "FROM (((tblSubmarines AS s " +
                "INNER JOIN tblStartGames AS sg " +
                "   ON s.subID = sg.startSubID) " +
                "INNER JOIN tblGames AS g " +
                "   ON sg.startGameID = g.gameID)" +
                "INNER JOIN tblPlayers AS p " +
                "   ON p.playerID = g.gamePlayer1ID OR p.playerID = g.gamePlayer2ID) " +
                "WHERE s.subID = @subID";
                datacommand.Parameters.AddWithValue("@subID", SubmarinesUtils.GetIdFromDetails(subId.Text));

                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    string[] values = new string[12];
                    for (int i = 0; i < values.Length; i++)
                    {
                        if (i == 0 || i == 2 || i == 6)
                        {
                            values[i] = dataReader.GetInt32(i).ToString();
                            
                        }
                        else if (i == 7 || i == 8)
                        {
                            values[i] = dataReader.GetBoolean(i) ? "כן" : "לא";
                        }
                        else
                        {
                            values[i] = dataReader.GetString(i);
                        }
                    }
                    list.Add(values);
                }
                dataReader.Close();
                return list;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get player details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return new ArrayList();
            }
        }

        private void EditListView(ArrayList list)
        {
            try
            {
                int rowCount = 0;
                if (!(list.Count == 0))
                {
                    foreach (string[] arr in list)
                    {
                        if (rowCount != 0)
                        {
                            arr[0] = "";
                            arr[1] = "";
                        }
                        ListViewItem item = new ListViewItem(arr);
                        if (saveColor != "")
                            item.ForeColor = Color.FromArgb(int.Parse(saveColor));
                        listView1.Items.Add(item);
                        rowCount++;
                    }
                }
                else
                {
                    MessageBox.Show("No recorded players for selected submarine.", "Not Found",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit listview item failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                ListViewItem selectedRow = listView1.SelectedItems[0];
                
                string id = selectedRow.SubItems[2].Text;
                string firstName = selectedRow.SubItems[3].Text;
                string lastName = selectedRow.SubItems[4].Text;
                string picLocation = selectedRow.SubItems[11].Text;
                playerNameAndPic1.UpdateProperties(id, firstName, lastName, picLocation);
                playerNameAndPic1.Visible = true;
            }
        }

        private void FormRptPlayersBySubmarine_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
