﻿namespace Submarines
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.tablesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.gamesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.stepsDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.submarinesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.markedSquaresDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.cityDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.organizationDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.playersDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.startGamesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addPlayerDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addStartGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addMarkedSquareDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addCityDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addSubmarinesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addStepDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.addOrganizationDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.updatePlayerDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateCityDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateOrganizationDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateStartGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateStepsDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.updateSubmarinesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.subMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.subCreateDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.submarineFixDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.rptGamesByPlayerDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.rptGamesByPeriodDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.rptSubsByGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.rptMarkedSquaresBySubmarinesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.rptPlayersByCityDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.rptSubmarinesByPlayerDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.rptPlayerBySubmarineDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.chartsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.chartsGamesAmountByPlayerDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.chartSubsPerGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.chartMarkedSquaresPerSubDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.chartPlayersPerCityDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.chartSubsPerPlayerDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.chartPlayersPerSubDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.searchPlayersDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchGamesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchCitiesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchSubmarinesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchMaekdSquaresDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchStepsDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchOrganizationsDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.searchStartGamesDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.gameMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.continueGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.replayGameDropDown = new System.Windows.Forms.ToolStripMenuItem();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReplayGame = new System.Windows.Forms.Button();
            this.btnContinueGame = new System.Windows.Forms.Button();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.btnUpdateSub = new System.Windows.Forms.Button();
            this.labelManager = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.playerNameAndPic1 = new Submarines.playerNameAndPic();
            this.btnAddSub = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tablesMenu,
            this.addMenu,
            this.updateMenu,
            this.subMenu,
            this.reportsMenu,
            this.chartsMenu,
            this.searchMenu,
            this.gameMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip.Size = new System.Drawing.Size(1924, 33);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // tablesMenu
            // 
            this.tablesMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gamesDropDown,
            this.stepsDropDown,
            this.submarinesDropDown,
            this.markedSquaresDropDown,
            this.cityDropDown,
            this.organizationDropDown,
            this.playersDropDown,
            this.startGamesDropDown});
            this.tablesMenu.Name = "tablesMenu";
            this.tablesMenu.Size = new System.Drawing.Size(89, 29);
            this.tablesMenu.Text = "טבלאות";
            // 
            // gamesDropDown
            // 
            this.gamesDropDown.Name = "gamesDropDown";
            this.gamesDropDown.Size = new System.Drawing.Size(364, 34);
            this.gamesDropDown.Text = "משחקים";
            this.gamesDropDown.Click += new System.EventHandler(this.gamesDropDown_Click);
            // 
            // stepsDropDown
            // 
            this.stepsDropDown.Name = "stepsDropDown";
            this.stepsDropDown.Size = new System.Drawing.Size(364, 34);
            this.stepsDropDown.Text = "מהלכים";
            this.stepsDropDown.Click += new System.EventHandler(this.stepsDropDown_Click);
            // 
            // submarinesDropDown
            // 
            this.submarinesDropDown.Name = "submarinesDropDown";
            this.submarinesDropDown.Size = new System.Drawing.Size(364, 34);
            this.submarinesDropDown.Text = "צוללות";
            this.submarinesDropDown.Click += new System.EventHandler(this.submarinesDropDown_Click);
            // 
            // markedSquaresDropDown
            // 
            this.markedSquaresDropDown.Name = "markedSquaresDropDown";
            this.markedSquaresDropDown.Size = new System.Drawing.Size(364, 34);
            this.markedSquaresDropDown.Text = "משבצות מסומנות בצוללות";
            this.markedSquaresDropDown.Click += new System.EventHandler(this.markedSquaresDropDown_Click);
            // 
            // cityDropDown
            // 
            this.cityDropDown.Name = "cityDropDown";
            this.cityDropDown.Size = new System.Drawing.Size(364, 34);
            this.cityDropDown.Text = "ערים";
            this.cityDropDown.Click += new System.EventHandler(this.cityDropDown_Click);
            // 
            // organizationDropDown
            // 
            this.organizationDropDown.Name = "organizationDropDown";
            this.organizationDropDown.Size = new System.Drawing.Size(364, 34);
            this.organizationDropDown.Text = "ארגון";
            this.organizationDropDown.Click += new System.EventHandler(this.organizationDropDown_Click);
            // 
            // playersDropDown
            // 
            this.playersDropDown.Name = "playersDropDown";
            this.playersDropDown.Size = new System.Drawing.Size(364, 34);
            this.playersDropDown.Text = "שחקנים";
            this.playersDropDown.Click += new System.EventHandler(this.playersDropDown_Click);
            // 
            // startGamesDropDown
            // 
            this.startGamesDropDown.Name = "startGamesDropDown";
            this.startGamesDropDown.Size = new System.Drawing.Size(364, 34);
            this.startGamesDropDown.Text = "מיקומי צוללות בתחילת משחקים";
            this.startGamesDropDown.Click += new System.EventHandler(this.startGamesDropDown_Click);
            // 
            // addMenu
            // 
            this.addMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPlayerDropDown,
            this.addGameDropDown,
            this.addStartGameDropDown,
            this.addMarkedSquareDropDown,
            this.addCityDropDown,
            this.addSubmarinesDropDown,
            this.addStepDropDown,
            this.addOrganizationDropDown});
            this.addMenu.Name = "addMenu";
            this.addMenu.Size = new System.Drawing.Size(80, 29);
            this.addMenu.Text = "הוספה";
            // 
            // addPlayerDropDown
            // 
            this.addPlayerDropDown.Name = "addPlayerDropDown";
            this.addPlayerDropDown.Size = new System.Drawing.Size(407, 34);
            this.addPlayerDropDown.Text = "הוספת שחקן";
            this.addPlayerDropDown.Click += new System.EventHandler(this.addPlayerDropDown_Click);
            // 
            // addGameDropDown
            // 
            this.addGameDropDown.Name = "addGameDropDown";
            this.addGameDropDown.Size = new System.Drawing.Size(407, 34);
            this.addGameDropDown.Text = "הוספת משחק";
            this.addGameDropDown.Click += new System.EventHandler(this.addGameDropDown_Click);
            // 
            // addStartGameDropDown
            // 
            this.addStartGameDropDown.Name = "addStartGameDropDown";
            this.addStartGameDropDown.Size = new System.Drawing.Size(407, 34);
            this.addStartGameDropDown.Text = "הוספת מיקום צוללת בתחילת המשחק";
            this.addStartGameDropDown.Click += new System.EventHandler(this.addStartGameDropDown_Click);
            // 
            // addMarkedSquareDropDown
            // 
            this.addMarkedSquareDropDown.Name = "addMarkedSquareDropDown";
            this.addMarkedSquareDropDown.Size = new System.Drawing.Size(407, 34);
            this.addMarkedSquareDropDown.Text = "הוספת משבצת בצוללת";
            this.addMarkedSquareDropDown.Click += new System.EventHandler(this.addMarkedSquareDropDown_Click);
            // 
            // addCityDropDown
            // 
            this.addCityDropDown.Name = "addCityDropDown";
            this.addCityDropDown.Size = new System.Drawing.Size(407, 34);
            this.addCityDropDown.Text = "הוספת עיר";
            this.addCityDropDown.Click += new System.EventHandler(this.addCityDropDown_Click);
            // 
            // addSubmarinesDropDown
            // 
            this.addSubmarinesDropDown.Name = "addSubmarinesDropDown";
            this.addSubmarinesDropDown.Size = new System.Drawing.Size(407, 34);
            this.addSubmarinesDropDown.Text = "הוספת צוללת";
            this.addSubmarinesDropDown.Click += new System.EventHandler(this.addSubmarinesDropDown_Click);
            // 
            // addStepDropDown
            // 
            this.addStepDropDown.Name = "addStepDropDown";
            this.addStepDropDown.Size = new System.Drawing.Size(407, 34);
            this.addStepDropDown.Text = "הוספת מהלך";
            this.addStepDropDown.Click += new System.EventHandler(this.addStepDropDown_Click);
            // 
            // addOrganizationDropDown
            // 
            this.addOrganizationDropDown.Name = "addOrganizationDropDown";
            this.addOrganizationDropDown.Size = new System.Drawing.Size(407, 34);
            this.addOrganizationDropDown.Text = "הוספת ארגון";
            this.addOrganizationDropDown.Click += new System.EventHandler(this.addOrganizationDropDown_Click);
            // 
            // updateMenu
            // 
            this.updateMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updatePlayerDropDown,
            this.updateCityDropDown,
            this.updateGameDropDown,
            this.updateOrganizationDropDown,
            this.updateStartGameDropDown,
            this.updateStepsDropDown,
            this.updateSubmarinesDropDown});
            this.updateMenu.Name = "updateMenu";
            this.updateMenu.Size = new System.Drawing.Size(68, 29);
            this.updateMenu.Text = "עדכון";
            // 
            // updatePlayerDropDown
            // 
            this.updatePlayerDropDown.Name = "updatePlayerDropDown";
            this.updatePlayerDropDown.Size = new System.Drawing.Size(387, 34);
            this.updatePlayerDropDown.Text = "עדכון פרטי שחקן";
            this.updatePlayerDropDown.Click += new System.EventHandler(this.updatePlayerDropDown_Click);
            // 
            // updateCityDropDown
            // 
            this.updateCityDropDown.Name = "updateCityDropDown";
            this.updateCityDropDown.Size = new System.Drawing.Size(387, 34);
            this.updateCityDropDown.Text = "עדכון פרטי עיר";
            this.updateCityDropDown.Click += new System.EventHandler(this.updateCityDropDown_Click);
            // 
            // updateGameDropDown
            // 
            this.updateGameDropDown.Name = "updateGameDropDown";
            this.updateGameDropDown.Size = new System.Drawing.Size(387, 34);
            this.updateGameDropDown.Text = "עדכון פרטי משחק";
            this.updateGameDropDown.Click += new System.EventHandler(this.updateGameDropDown_Click);
            // 
            // updateOrganizationDropDown
            // 
            this.updateOrganizationDropDown.Name = "updateOrganizationDropDown";
            this.updateOrganizationDropDown.Size = new System.Drawing.Size(387, 34);
            this.updateOrganizationDropDown.Text = "עדכון פרטי ארגון";
            this.updateOrganizationDropDown.Click += new System.EventHandler(this.updateOrganizationDropDown_Click);
            // 
            // updateStartGameDropDown
            // 
            this.updateStartGameDropDown.Name = "updateStartGameDropDown";
            this.updateStartGameDropDown.Size = new System.Drawing.Size(387, 34);
            this.updateStartGameDropDown.Text = "עדכון מיקום צוללות בתחילת משחק";
            this.updateStartGameDropDown.Click += new System.EventHandler(this.updateStartGameDropDown_Click);
            // 
            // updateStepsDropDown
            // 
            this.updateStepsDropDown.Name = "updateStepsDropDown";
            this.updateStepsDropDown.Size = new System.Drawing.Size(387, 34);
            this.updateStepsDropDown.Text = "עדכון פרטי מהלך";
            this.updateStepsDropDown.Click += new System.EventHandler(this.updateStepsDropDown_Click);
            // 
            // updateSubmarinesDropDown
            // 
            this.updateSubmarinesDropDown.Name = "updateSubmarinesDropDown";
            this.updateSubmarinesDropDown.Size = new System.Drawing.Size(387, 34);
            this.updateSubmarinesDropDown.Text = "עדכון פרטי צוללת";
            this.updateSubmarinesDropDown.Click += new System.EventHandler(this.updateSubmarinesDropDown_Click);
            // 
            // subMenu
            // 
            this.subMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.subCreateDropDown,
            this.submarineFixDropDown});
            this.subMenu.Name = "subMenu";
            this.subMenu.Size = new System.Drawing.Size(77, 29);
            this.subMenu.Text = "צוללת";
            // 
            // subCreateDropDown
            // 
            this.subCreateDropDown.Name = "subCreateDropDown";
            this.subCreateDropDown.Size = new System.Drawing.Size(213, 34);
            this.subCreateDropDown.Text = "יצירת צוללת";
            this.subCreateDropDown.Click += new System.EventHandler(this.subCreateDropDown_Click);
            // 
            // submarineFixDropDown
            // 
            this.submarineFixDropDown.Name = "submarineFixDropDown";
            this.submarineFixDropDown.Size = new System.Drawing.Size(213, 34);
            this.submarineFixDropDown.Text = "תיקון צוללות";
            this.submarineFixDropDown.Click += new System.EventHandler(this.submarineFixDropDown_Click);
            // 
            // reportsMenu
            // 
            this.reportsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rptGamesByPlayerDropDown,
            this.rptGamesByPeriodDropDown,
            this.rptSubsByGameDropDown,
            this.rptMarkedSquaresBySubmarinesDropDown,
            this.rptPlayersByCityDropDown,
            this.rptSubmarinesByPlayerDropDown,
            this.rptPlayerBySubmarineDropDown});
            this.reportsMenu.Name = "reportsMenu";
            this.reportsMenu.Size = new System.Drawing.Size(72, 29);
            this.reportsMenu.Text = "דוחות";
            // 
            // rptGamesByPlayerDropDown
            // 
            this.rptGamesByPlayerDropDown.Name = "rptGamesByPlayerDropDown";
            this.rptGamesByPlayerDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptGamesByPlayerDropDown.Text = "דוח משחקים לפי שחקן";
            this.rptGamesByPlayerDropDown.Click += new System.EventHandler(this.rptGamesByPlayerDropDown_Click);
            // 
            // rptGamesByPeriodDropDown
            // 
            this.rptGamesByPeriodDropDown.Name = "rptGamesByPeriodDropDown";
            this.rptGamesByPeriodDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptGamesByPeriodDropDown.Text = "דוח משחקים לפי תקופה";
            this.rptGamesByPeriodDropDown.Click += new System.EventHandler(this.rptGamesByPeriodDropDown_Click);
            // 
            // rptSubsByGameDropDown
            // 
            this.rptSubsByGameDropDown.Name = "rptSubsByGameDropDown";
            this.rptSubsByGameDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptSubsByGameDropDown.Text = "דוח צוללות לפי משחק";
            this.rptSubsByGameDropDown.Click += new System.EventHandler(this.rptSubsByGameDropDown_Click);
            // 
            // rptMarkedSquaresBySubmarinesDropDown
            // 
            this.rptMarkedSquaresBySubmarinesDropDown.Name = "rptMarkedSquaresBySubmarinesDropDown";
            this.rptMarkedSquaresBySubmarinesDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptMarkedSquaresBySubmarinesDropDown.Text = "דוח משבצות מסומנות לפי צוללת";
            this.rptMarkedSquaresBySubmarinesDropDown.Click += new System.EventHandler(this.rptMarkedSquaresBySubmarinesDropDown_Click);
            // 
            // rptPlayersByCityDropDown
            // 
            this.rptPlayersByCityDropDown.Name = "rptPlayersByCityDropDown";
            this.rptPlayersByCityDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptPlayersByCityDropDown.Text = "דוח שחקנים לפי עיר";
            this.rptPlayersByCityDropDown.Click += new System.EventHandler(this.rptPlayersByCityDropDown_Click);
            // 
            // rptSubmarinesByPlayerDropDown
            // 
            this.rptSubmarinesByPlayerDropDown.Name = "rptSubmarinesByPlayerDropDown";
            this.rptSubmarinesByPlayerDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptSubmarinesByPlayerDropDown.Text = "דוח צוללות לפי שחקן";
            this.rptSubmarinesByPlayerDropDown.Click += new System.EventHandler(this.rptSubmarinesByPlayerDropDown_Click);
            // 
            // rptPlayerBySubmarineDropDown
            // 
            this.rptPlayerBySubmarineDropDown.Name = "rptPlayerBySubmarineDropDown";
            this.rptPlayerBySubmarineDropDown.Size = new System.Drawing.Size(366, 34);
            this.rptPlayerBySubmarineDropDown.Text = "דוח שחקנים לפי צוללות";
            this.rptPlayerBySubmarineDropDown.Click += new System.EventHandler(this.rptPlayerBySubmarineDropDown_Click);
            // 
            // chartsMenu
            // 
            this.chartsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chartsGamesAmountByPlayerDropDown,
            this.chartSubsPerGameDropDown,
            this.chartMarkedSquaresPerSubDropDown,
            this.chartPlayersPerCityDropDown,
            this.chartSubsPerPlayerDropDown,
            this.chartPlayersPerSubDropDown});
            this.chartsMenu.Name = "chartsMenu";
            this.chartsMenu.Size = new System.Drawing.Size(99, 29);
            this.chartsMenu.Text = "תרשימים";
            // 
            // chartsGamesAmountByPlayerDropDown
            // 
            this.chartsGamesAmountByPlayerDropDown.Name = "chartsGamesAmountByPlayerDropDown";
            this.chartsGamesAmountByPlayerDropDown.Size = new System.Drawing.Size(418, 34);
            this.chartsGamesAmountByPlayerDropDown.Text = "תרשים כמות משחקים לשחקן";
            this.chartsGamesAmountByPlayerDropDown.Click += new System.EventHandler(this.chartsGamesAmountByPlayerDropDown_Click);
            // 
            // chartSubsPerGameDropDown
            // 
            this.chartSubsPerGameDropDown.Name = "chartSubsPerGameDropDown";
            this.chartSubsPerGameDropDown.Size = new System.Drawing.Size(418, 34);
            this.chartSubsPerGameDropDown.Text = "תרשים כמות צוללות למשחק";
            this.chartSubsPerGameDropDown.Click += new System.EventHandler(this.chartSubsPerGameDropDown_Click);
            // 
            // chartMarkedSquaresPerSubDropDown
            // 
            this.chartMarkedSquaresPerSubDropDown.Name = "chartMarkedSquaresPerSubDropDown";
            this.chartMarkedSquaresPerSubDropDown.Size = new System.Drawing.Size(418, 34);
            this.chartMarkedSquaresPerSubDropDown.Text = "תרשים כמות משבצות מסומנות לצוללת";
            this.chartMarkedSquaresPerSubDropDown.Click += new System.EventHandler(this.chartMarkedSquaresPerSubDropDown_Click);
            // 
            // chartPlayersPerCityDropDown
            // 
            this.chartPlayersPerCityDropDown.Name = "chartPlayersPerCityDropDown";
            this.chartPlayersPerCityDropDown.Size = new System.Drawing.Size(418, 34);
            this.chartPlayersPerCityDropDown.Text = "תרשים כמות שחקנים לעיר";
            this.chartPlayersPerCityDropDown.Click += new System.EventHandler(this.chartPlayersPerCityDropDown_Click);
            // 
            // chartSubsPerPlayerDropDown
            // 
            this.chartSubsPerPlayerDropDown.Name = "chartSubsPerPlayerDropDown";
            this.chartSubsPerPlayerDropDown.Size = new System.Drawing.Size(418, 34);
            this.chartSubsPerPlayerDropDown.Text = "תרשים כמות צוללות לשחקן";
            this.chartSubsPerPlayerDropDown.Click += new System.EventHandler(this.chartSubsPerPlayerDropDown_Click);
            // 
            // chartPlayersPerSubDropDown
            // 
            this.chartPlayersPerSubDropDown.Name = "chartPlayersPerSubDropDown";
            this.chartPlayersPerSubDropDown.Size = new System.Drawing.Size(418, 34);
            this.chartPlayersPerSubDropDown.Text = "תרשים כמות שחקנים לצוללת";
            this.chartPlayersPerSubDropDown.Click += new System.EventHandler(this.chartPlayersPerSubDropDown_Click);
            // 
            // searchMenu
            // 
            this.searchMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchPlayersDropDown,
            this.searchGamesDropDown,
            this.searchCitiesDropDown,
            this.searchSubmarinesDropDown,
            this.searchMaekdSquaresDropDown,
            this.searchStepsDropDown,
            this.searchOrganizationsDropDown,
            this.searchStartGamesDropDown});
            this.searchMenu.Name = "searchMenu";
            this.searchMenu.Size = new System.Drawing.Size(75, 29);
            this.searchMenu.Text = "חיפוש";
            // 
            // searchPlayersDropDown
            // 
            this.searchPlayersDropDown.Name = "searchPlayersDropDown";
            this.searchPlayersDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchPlayersDropDown.Text = "חיפוש בטבלת שחקנים";
            this.searchPlayersDropDown.Click += new System.EventHandler(this.searchPlayersDropDown_Click);
            // 
            // searchGamesDropDown
            // 
            this.searchGamesDropDown.Name = "searchGamesDropDown";
            this.searchGamesDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchGamesDropDown.Text = "חיפוש בטבלת משחקים";
            this.searchGamesDropDown.Click += new System.EventHandler(this.searchGamesDropDown_Click);
            // 
            // searchCitiesDropDown
            // 
            this.searchCitiesDropDown.Name = "searchCitiesDropDown";
            this.searchCitiesDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchCitiesDropDown.Text = "חיפוש בטבלת ערים";
            this.searchCitiesDropDown.Click += new System.EventHandler(this.searchCitiesDropDown_Click);
            // 
            // searchSubmarinesDropDown
            // 
            this.searchSubmarinesDropDown.Name = "searchSubmarinesDropDown";
            this.searchSubmarinesDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchSubmarinesDropDown.Text = "חיפוש בטבלת צוללות ";
            this.searchSubmarinesDropDown.Click += new System.EventHandler(this.searchSubmarinesDropDown_Click);
            // 
            // searchMaekdSquaresDropDown
            // 
            this.searchMaekdSquaresDropDown.Name = "searchMaekdSquaresDropDown";
            this.searchMaekdSquaresDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchMaekdSquaresDropDown.Text = "חיפוש בטבלת משבצות מסומנות";
            this.searchMaekdSquaresDropDown.Click += new System.EventHandler(this.searchMaekdSquaresDropDown_Click);
            // 
            // searchStepsDropDown
            // 
            this.searchStepsDropDown.Name = "searchStepsDropDown";
            this.searchStepsDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchStepsDropDown.Text = "חיפוש בטבלת מהלכים";
            this.searchStepsDropDown.Click += new System.EventHandler(this.searchStepsDropDown_Click);
            // 
            // searchOrganizationsDropDown
            // 
            this.searchOrganizationsDropDown.Name = "searchOrganizationsDropDown";
            this.searchOrganizationsDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchOrganizationsDropDown.Text = "חיפוש בטבלת ארגון";
            this.searchOrganizationsDropDown.Click += new System.EventHandler(this.searchOrganizationsDropDown_Click);
            // 
            // searchStartGamesDropDown
            // 
            this.searchStartGamesDropDown.Name = "searchStartGamesDropDown";
            this.searchStartGamesDropDown.Size = new System.Drawing.Size(459, 34);
            this.searchStartGamesDropDown.Text = "חיפוש בטבלת מיקומי צוללות בתחילת משחק";
            this.searchStartGamesDropDown.Click += new System.EventHandler(this.searchStartGamesDropDown_Click);
            // 
            // gameMenu
            // 
            this.gameMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameDropDown,
            this.continueGameDropDown,
            this.replayGameDropDown});
            this.gameMenu.Name = "gameMenu";
            this.gameMenu.Size = new System.Drawing.Size(78, 29);
            this.gameMenu.Text = "משחק";
            // 
            // newGameDropDown
            // 
            this.newGameDropDown.Name = "newGameDropDown";
            this.newGameDropDown.Size = new System.Drawing.Size(274, 34);
            this.newGameDropDown.Text = "משחק חדש";
            this.newGameDropDown.Click += new System.EventHandler(this.newGameDropDown_Click);
            // 
            // continueGameDropDown
            // 
            this.continueGameDropDown.Name = "continueGameDropDown";
            this.continueGameDropDown.Size = new System.Drawing.Size(274, 34);
            this.continueGameDropDown.Text = "המשך משחק";
            this.continueGameDropDown.Click += new System.EventHandler(this.continueGameDropDown_Click);
            // 
            // replayGameDropDown
            // 
            this.replayGameDropDown.Name = "replayGameDropDown";
            this.replayGameDropDown.Size = new System.Drawing.Size(274, 34);
            this.replayGameDropDown.Text = "צפייה חוזרת במשחק";
            this.replayGameDropDown.Click += new System.EventHandler(this.replayGameDropDown_Click);
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.Location = new System.Drawing.Point(0, 0);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Size = new System.Drawing.Size(200, 200);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxLogo.TabIndex = 11;
            this.picBoxLogo.TabStop = false;
            this.picBoxLogo.Click += new System.EventHandler(this.picBoxLogo_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btnReplayGame);
            this.panel1.Controls.Add(this.btnContinueGame);
            this.panel1.Controls.Add(this.btnNewGame);
            this.panel1.Controls.Add(this.btnUpdateSub);
            this.panel1.Controls.Add(this.labelManager);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.playerNameAndPic1);
            this.panel1.Controls.Add(this.btnAddSub);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1934, 1061);
            this.panel1.TabIndex = 1;
            // 
            // btnReplayGame
            // 
            this.btnReplayGame.BackColor = System.Drawing.Color.DarkGray;
            this.btnReplayGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReplayGame.Location = new System.Drawing.Point(281, 388);
            this.btnReplayGame.Name = "btnReplayGame";
            this.btnReplayGame.Size = new System.Drawing.Size(201, 111);
            this.btnReplayGame.TabIndex = 2;
            this.btnReplayGame.Text = "צפייה מחדש\r\nבמשחק";
            this.btnReplayGame.UseVisualStyleBackColor = false;
            this.btnReplayGame.Click += new System.EventHandler(this.btnReplayGame_Click);
            // 
            // btnContinueGame
            // 
            this.btnContinueGame.BackColor = System.Drawing.Color.DarkGray;
            this.btnContinueGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinueGame.Location = new System.Drawing.Point(544, 388);
            this.btnContinueGame.Name = "btnContinueGame";
            this.btnContinueGame.Size = new System.Drawing.Size(201, 111);
            this.btnContinueGame.TabIndex = 1;
            this.btnContinueGame.Text = "המשך\r\nמשחק";
            this.btnContinueGame.UseVisualStyleBackColor = false;
            this.btnContinueGame.Click += new System.EventHandler(this.btnContinueGame_Click);
            // 
            // btnNewGame
            // 
            this.btnNewGame.BackColor = System.Drawing.Color.DarkGray;
            this.btnNewGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewGame.Location = new System.Drawing.Point(796, 388);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(201, 111);
            this.btnNewGame.TabIndex = 0;
            this.btnNewGame.Text = "משחק\r\nחדש";
            this.btnNewGame.UseVisualStyleBackColor = false;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // btnUpdateSub
            // 
            this.btnUpdateSub.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnUpdateSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateSub.Location = new System.Drawing.Point(401, 595);
            this.btnUpdateSub.Name = "btnUpdateSub";
            this.btnUpdateSub.Size = new System.Drawing.Size(201, 111);
            this.btnUpdateSub.TabIndex = 4;
            this.btnUpdateSub.Text = "עדכון פרטי\r\nוצורת צוללת";
            this.btnUpdateSub.UseVisualStyleBackColor = false;
            this.btnUpdateSub.Click += new System.EventHandler(this.btnUpdateSub_Click);
            // 
            // labelManager
            // 
            this.labelManager.AutoSize = true;
            this.labelManager.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelManager.Location = new System.Drawing.Point(1473, 307);
            this.labelManager.Name = "labelManager";
            this.labelManager.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelManager.Size = new System.Drawing.Size(73, 32);
            this.labelManager.TabIndex = 4;
            this.labelManager.Text = "מנהל";
            this.labelManager.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.label2.Location = new System.Drawing.Point(591, 242);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(722, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "כדי להמשיך לתהליכי המערכת, בחרו מהתפריט או מהכפתורים!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playerNameAndPic1
            // 
            this.playerNameAndPic1.firstName = "";
            this.playerNameAndPic1.id = "";
            this.playerNameAndPic1.lastName = "";
            this.playerNameAndPic1.Location = new System.Drawing.Point(1395, 388);
            this.playerNameAndPic1.Name = "playerNameAndPic1";
            this.playerNameAndPic1.picLocation = "";
            this.playerNameAndPic1.Size = new System.Drawing.Size(217, 349);
            this.playerNameAndPic1.TabIndex = 2;
            // 
            // btnAddSub
            // 
            this.btnAddSub.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnAddSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSub.Location = new System.Drawing.Point(674, 595);
            this.btnAddSub.Name = "btnAddSub";
            this.btnAddSub.Size = new System.Drawing.Size(201, 111);
            this.btnAddSub.TabIndex = 3;
            this.btnAddSub.Text = "הוספת צוללת\r\nחדשה";
            this.btnAddSub.UseVisualStyleBackColor = false;
            this.btnAddSub.Click += new System.EventHandler(this.btnAddSub_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SteelBlue;
            this.label1.Location = new System.Drawing.Point(281, 155);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(1342, 64);
            this.label1.TabIndex = 0;
            this.label1.Text = "ברוכים הבאים לתוכנת המחשב של מועדון משחק הצוללות!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.picBoxLogo);
            this.Controls.Add(this.menuStrip);
            this.DoubleBuffered = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "FormMenu";
            this.Text = "FormMenu";
            this.Shown += new System.EventHandler(this.FormMenu_Shown);
            this.SizeChanged += new System.EventHandler(this.FormMenu_SizeChanged);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem tablesMenu;
        private System.Windows.Forms.ToolStripMenuItem gamesDropDown;
        private System.Windows.Forms.ToolStripMenuItem stepsDropDown;
        private System.Windows.Forms.ToolStripMenuItem submarinesDropDown;
        private System.Windows.Forms.ToolStripMenuItem markedSquaresDropDown;
        private System.Windows.Forms.ToolStripMenuItem cityDropDown;
        private System.Windows.Forms.ToolStripMenuItem organizationDropDown;
        private System.Windows.Forms.ToolStripMenuItem playersDropDown;
        private System.Windows.Forms.ToolStripMenuItem startGamesDropDown;
        private System.Windows.Forms.ToolStripMenuItem addMenu;
        private System.Windows.Forms.ToolStripMenuItem addPlayerDropDown;
        private System.Windows.Forms.ToolStripMenuItem addGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem addStartGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem addMarkedSquareDropDown;
        private System.Windows.Forms.ToolStripMenuItem addCityDropDown;
        private System.Windows.Forms.ToolStripMenuItem addSubmarinesDropDown;
        private System.Windows.Forms.ToolStripMenuItem addStepDropDown;
        private System.Windows.Forms.ToolStripMenuItem addOrganizationDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateMenu;
        private System.Windows.Forms.ToolStripMenuItem updatePlayerDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateCityDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateOrganizationDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateStartGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateStepsDropDown;
        private System.Windows.Forms.ToolStripMenuItem updateSubmarinesDropDown;
        private System.Windows.Forms.ToolStripMenuItem reportsMenu;
        private System.Windows.Forms.ToolStripMenuItem rptGamesByPlayerDropDown;
        private System.Windows.Forms.ToolStripMenuItem rptGamesByPeriodDropDown;
        private System.Windows.Forms.ToolStripMenuItem rptSubsByGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem rptMarkedSquaresBySubmarinesDropDown;
        private System.Windows.Forms.ToolStripMenuItem rptPlayersByCityDropDown;
        private System.Windows.Forms.ToolStripMenuItem rptSubmarinesByPlayerDropDown;
        private System.Windows.Forms.ToolStripMenuItem rptPlayerBySubmarineDropDown;
        private System.Windows.Forms.ToolStripMenuItem chartsMenu;
        private System.Windows.Forms.ToolStripMenuItem chartsGamesAmountByPlayerDropDown;
        private System.Windows.Forms.ToolStripMenuItem chartSubsPerGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem chartMarkedSquaresPerSubDropDown;
        private System.Windows.Forms.ToolStripMenuItem chartPlayersPerCityDropDown;
        private System.Windows.Forms.ToolStripMenuItem chartSubsPerPlayerDropDown;
        private System.Windows.Forms.ToolStripMenuItem chartPlayersPerSubDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchMenu;
        private System.Windows.Forms.ToolStripMenuItem searchPlayersDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchGamesDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchCitiesDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchSubmarinesDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchMaekdSquaresDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchStepsDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchOrganizationsDropDown;
        private System.Windows.Forms.ToolStripMenuItem searchStartGamesDropDown;
        private System.Windows.Forms.ToolStripMenuItem subMenu;
        private System.Windows.Forms.ToolStripMenuItem subCreateDropDown;
        private System.Windows.Forms.ToolStripMenuItem submarineFixDropDown;
        private System.Windows.Forms.ToolStripMenuItem gameMenu;
        private System.Windows.Forms.ToolStripMenuItem newGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem continueGameDropDown;
        private System.Windows.Forms.ToolStripMenuItem replayGameDropDown;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Panel panel1;
        private playerNameAndPic playerNameAndPic1;
        private System.Windows.Forms.Button btnAddSub;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelManager;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnReplayGame;
        private System.Windows.Forms.Button btnContinueGame;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Button btnUpdateSub;
    }
}