﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormChartSubmarinesByPlayer : Submarines.FormBaseCharts
    {
        private OleDbConnection dataConnection;
        private int counter;
        private string[] arrPlayers;
        private int[] arrCounts;

        public FormChartSubmarinesByPlayer(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            CountPlayers();
            arrPlayers = new string[counter];
            arrCounts = new int[counter];
            FillArrPlayers();
            FillArrCounts();
            ShowChart();
            EditDataGridView();
        }

        private void CountPlayers()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT   COUNT(*) " +
                                          "FROM     tblPlayers";
                counter = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Count tblPlayers failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrPlayers()
        {
            try
            {
                int k = 0;
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT   playerID, playerFirstName, playerLastName " +
                                          "FROM     tblPlayers " +
                                          "ORDER BY playerID ";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    arrPlayers[k] = dataReader.GetInt32(0).ToString() + ", " +
                        dataReader.GetString(1) + " " + dataReader.GetString(2);
                    k++;
                }
                dataReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select tblPlayers failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillArrCounts()
        {
            for (int idx = 0; idx < arrPlayers.Length; idx++)
                CountSubmarines(idx);
        }

        private void CountSubmarines(int idx)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                "SELECT COUNT(*) " +
                "FROM(" +
                "   SELECT DISTINCT s.subID" +
                "   FROM (((tblPlayers AS p " +
                "   INNER JOIN tblGames AS g " +
                "    ON p.playerID = g.gamePlayer1ID OR p.playerID = g.gamePlayer2ID) " +
                "   INNER JOIN tblStartGames AS sg " +
                "       ON g.gameID = sg.startGameID) " +
                "   INNER JOIN tblSubmarines AS s " +
                "       ON sg.startSubID = s.subID) " +
                "   WHERE p.playerID = @playerID" +
                ");";
                datacommand.Parameters.AddWithValue("@playerID", SubmarinesUtils.GetIdFromDetails(arrPlayers[idx]));
                arrCounts[idx] = (int)datacommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("count submarines failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowChart()
        {
            try
            {
                chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -45;

                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoom(1, 10);
                chart1.ChartAreas["ChartArea1"].CursorX.IsUserSelectionEnabled = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoomable = true;
                chart1.ChartAreas["ChartArea1"].AxisX.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.ScrollBar.IsPositionedInside = true;
                chart1.ChartAreas["ChartArea1"].AxisY.Interval = 1;
                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;


                chart1.Legends.Clear();

                chart1.ChartAreas["ChartArea1"].AxisX.Title = "שחקנים";
                chart1.ChartAreas["ChartArea1"].AxisY.Title = "מספר צוללות";

                chart1.Series.Clear();
                chart1.Series.Add("נתונים");


                for (int i = 0; i < arrPlayers.Length; i++)
                {
                    chart1.Series["נתונים"].Points.AddXY(
                        SubmarinesUtils.StringRightToLeft(arrPlayers[i]), arrCounts[i]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Show chart failed " +
                                 ex.Message, "Errors",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EditDataGridView()
        {
            try
            {
                for (int i = 0; i < arrPlayers.Length; i++)
                {
                    DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
                    row.Cells[0].Value = arrPlayers[i];
                    row.Cells[1].Value = arrCounts[i].ToString();
                    dataGridView1.Rows.Add(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit gridview item failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormChartSubmarinesByPlayer_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
