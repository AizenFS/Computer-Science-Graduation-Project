﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormRptGamesByPlayer : Submarines.FormBaseReport
    {
        private OleDbConnection dataConnection;
        private string saveColor = "";


        public FormRptGamesByPlayer(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillIdCombo(playerCombo);
            listView1.FullRowSelect = true;
        }

        private void FillIdCombo(ComboBox combo)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerID, playerFirstName, playerLastName " +
                                          "FROM tblPlayers " +
                                          "ORDER BY playerID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    combo.Items.Add(dataReader.GetInt32(0).ToString() + ", " +
                        dataReader.GetString(1) + " " + dataReader.GetString(2));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill player ID combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #region Button events
        private void buttonShow_Click(object sender, EventArgs e)
        {
            try
            {
                if(playerCombo.Text != "")
                {
                    EditListView(GetGameDetails());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select tblPlayers failed " +
                    ex.Message, "Errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            playerCombo.Text = "";
            playerNameAndPic1.Visible = false;
            playerNameAndPic2.Visible = false;
            labelSelected.Visible = false;
            labelOpponent.Visible = false;
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            buttonColor.ForeColor = cd.Color;
            saveColor = buttonColor.ForeColor.ToArgb().ToString();
        }
        #endregion

        #region Report logic
        private ArrayList GetGameDetails()
        {
            try
            {
                ArrayList list = new ArrayList();
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                "SELECT p.playerID, p.playerFirstName, p.playerLastName, g.* " +
                "FROM tblPlayers AS p " +
                "INNER JOIN tblGames AS g " +
                "ON p.playerID = g.gamePlayer1ID OR p.playerID = g.gamePlayer2ID " +
                "WHERE p.playerID = @playerID";
                datacommand.Parameters.AddWithValue("@playerID", SubmarinesUtils.GetIdFromDetails(playerCombo.Text));
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    string[] values = new string[16];
                    for (int i = 0; i < values.Length; i++)
                    {
                        if (i == 10)
                        {
                            values[i] = dataReader.GetDateTime(i).ToString("dd-MM-yyyy");
                        }
                        else if (i == 11)
                        {
                            values[i] = dataReader.GetDateTime(i).ToString("HH:mm:ss");
                        }
                        else {
                            values[i] = dataReader[i].ToString();
                        }
                    }
                    if (values[3] != null)
                    {
                        list.Add(values);
                    }
                }
                dataReader.Close();
                return list;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get game details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return new ArrayList();
            }
        }

        private void EditListView(ArrayList list)
        {
            try
            {
                int rowCount = 0;
                if(!(list.Count == 0))
                {
                    foreach (string[] arr in list)
                    {
                        if(rowCount != 0)
                        {
                            arr[0] = "";
                            arr[1] = "";
                            arr[2] = "";
                        }
                        ListViewItem item = new ListViewItem(arr);
                        if (saveColor != "")
                            item.ForeColor = Color.FromArgb(int.Parse(saveColor));
                        listView1.Items.Add(item);
                        rowCount++;
                    }
                }
                else
                {
                    MessageBox.Show("לא נמצאו משחקים עבור השחקן הנבחר", "לא נמצא",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit listview item failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Player display
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedIndices.Count > 0)
                {
                    ListViewItem selectedRow = listView1.SelectedItems[0];
                    int index = selectedRow.Index;
                    while (selectedRow.SubItems[0].Text == "")
                    {
                        selectedRow = listView1.Items[--index];
                    }
                    UpdatePlayerNameAndPic(true, selectedRow, playerNameAndPic1);
                    UpdatePlayerNameAndPic(false, selectedRow, playerNameAndPic2);

                }
            }
            catch (Exception err)
            {
                MessageBox.Show("list view row click failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Player GetPlayerFromID(int id)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerFirstName, PlayerLastName " +
                                          "FROM tblPlayers " +
                                          "WHERE playerID = @playerID";
                datacommand.Parameters.AddWithValue("@playerID", id);

                OleDbDataReader dataReader = datacommand.ExecuteReader();
                dataReader.Read();
                return new Player(id, dataReader.GetString(0), dataReader.GetString(1));
            }
            catch (Exception err)
            {
                MessageBox.Show("Get player details form id failed failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void UpdatePlayerNameAndPic(bool isSelectedPlayer, ListViewItem selectedRow, playerNameAndPic nameAndPic)
        {
            try
            {
                string id_str = SubmarinesUtils.GetIdFromDetails(playerCombo.Text).ToString();
                if (!isSelectedPlayer)
                {
                    labelOpponent.Visible = true;
                    if (selectedRow.SubItems[6].Text.Equals(id_str)) { id_str = selectedRow.SubItems[8].Text; }
                    else { id_str = selectedRow.SubItems[6].Text; }
                }
                else { labelSelected.Visible = true; }
                int id = int.Parse(id_str);

                nameAndPic.UpdateProperties(GetPlayerFromID(id), dataConnection);
                nameAndPic.Visible = true;
            }
            catch(Exception err) {
                MessageBox.Show($"update name and pic, selected: {isSelectedPlayer}, failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        private void FormRptGamesByPlayer_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
