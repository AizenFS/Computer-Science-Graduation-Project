﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormRptMarkedSquaresBySubmarines : Submarines.FormBaseReport
    {
        private OleDbConnection dataConnection;
        string saveColor = "";
        public FormRptMarkedSquaresBySubmarines(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillSubmarinesCombo();
        }

        private void FillSubmarinesCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT * " +
                                          "FROM tblSubmarines " +
                                          "ORDER BY subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    string id = dataReader.GetInt32(0).ToString();
                    string rows = dataReader.GetInt32(1).ToString();
                    string cols = dataReader.GetInt32(2).ToString();
                    string name = dataReader.GetString(3);
                    string percent = dataReader.GetInt32(4).ToString();
                    string data = $"{id}, {name}, {rows} שורות, {cols} עמודות, {percent} אחוז להטבעה";
                    subID.Items.Add(data);
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarines combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #region Button events
        private void buttonShow_Click(object sender, EventArgs e)
        {
            EditListView(GetMarkedSquaresDetails());
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            subID.Text = "";
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            buttonColor.ForeColor = cd.Color;
            saveColor = buttonColor.ForeColor.ToArgb().ToString();
        }
        #endregion

        #region Report logic
        private void EditListView(ArrayList list)
        {
            try
            {
                int counter = 0;
                if (!(list.Count == 0))
                {
                    foreach (string[] arr in list)
                    {
                        if (counter != 0)
                        {
                            arr[0] = "";
                            arr[1] = "";
                        }
                        ListViewItem item = new ListViewItem(arr);
                        if (saveColor != "")
                            item.ForeColor = Color.FromArgb(int.Parse(saveColor));
                        listView1.Items.Add(item);
                        counter++;
                    }
                }
                else
                {
                    MessageBox.Show("לא נמצאו משבצות מסומנות עבור הצוללת הנבחרת.",
                        "לא נמצאו משבצות", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit listview failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private ArrayList GetMarkedSquaresDetails()
        {
            try
            {
                ArrayList list = new ArrayList();
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "SELECT s.subID, s.subName, ms.msRowNum, ms.msColNum " +
                    "FROM tblSubmarines AS s " +
                    "INNER JOIN tblMarkedSquares AS ms " +
                    "ON s.subID = ms.msSubID " +
                    "WHERE s.subID = @subID ";
                datacommand.Parameters.AddWithValue("@subID", SubmarinesUtils.GetIdFromDetails(subID.Text));
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    string[] values = new string[4];
                    for (int i = 0; i < values.Length; i++)
                    {
                        if (i == 1)
                        {
                            values[i] = dataReader.GetString(i);
                        }
                        else
                        {
                            values[i] = dataReader.GetInt32(i).ToString();
                        }
                    }
                    list.Add(values);
                }
                dataReader.Close();
                return list;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get marked squares details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return new ArrayList();
            }
        }
        #endregion

        private void FormRptMarkedSquaresBySubmarines_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
