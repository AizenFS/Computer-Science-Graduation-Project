﻿namespace Submarines
{
    partial class FormTblOrganization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.orgNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgCityIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgDirectorIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPictureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgPicturesFolderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgClipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orgSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblOrganizationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetOrganization = new Submarines.DataSetOrganization();
            this.tblOrganizationTableAdapter = new Submarines.DataSetOrganizationTableAdapters.tblOrganizationTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(796, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 37);
            this.label2.TabIndex = 4;
            this.label2.Text = "טבלת ארגון";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.saveButton);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(58, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1763, 1028);
            this.panel1.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(1650, 295);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 35;
            this.label3.Text = "טבלת ארגון";
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(814, 920);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(133, 53);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "שמור";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orgNameDataGridViewTextBoxColumn,
            this.orgAddressDataGridViewTextBoxColumn,
            this.orgCityIDDataGridViewTextBoxColumn,
            this.orgDirectorIDDataGridViewTextBoxColumn,
            this.orgPictureDataGridViewTextBoxColumn,
            this.orgPicturesFolderDataGridViewTextBoxColumn,
            this.orgClipDataGridViewTextBoxColumn,
            this.orgSite});
            this.dataGridView1.DataSource = this.tblOrganizationBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(49, 323);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(1711, 519);
            this.dataGridView1.TabIndex = 0;
            // 
            // orgNameDataGridViewTextBoxColumn
            // 
            this.orgNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgNameDataGridViewTextBoxColumn.DataPropertyName = "orgName";
            this.orgNameDataGridViewTextBoxColumn.HeaderText = "שם ארגון";
            this.orgNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgNameDataGridViewTextBoxColumn.Name = "orgNameDataGridViewTextBoxColumn";
            this.orgNameDataGridViewTextBoxColumn.Width = 155;
            // 
            // orgAddressDataGridViewTextBoxColumn
            // 
            this.orgAddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.orgAddressDataGridViewTextBoxColumn.DataPropertyName = "orgAddress";
            this.orgAddressDataGridViewTextBoxColumn.HeaderText = "כתובת";
            this.orgAddressDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgAddressDataGridViewTextBoxColumn.Name = "orgAddressDataGridViewTextBoxColumn";
            this.orgAddressDataGridViewTextBoxColumn.Width = 87;
            // 
            // orgCityIDDataGridViewTextBoxColumn
            // 
            this.orgCityIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgCityIDDataGridViewTextBoxColumn.DataPropertyName = "orgCityID";
            this.orgCityIDDataGridViewTextBoxColumn.HeaderText = "קוד עיר";
            this.orgCityIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgCityIDDataGridViewTextBoxColumn.Name = "orgCityIDDataGridViewTextBoxColumn";
            this.orgCityIDDataGridViewTextBoxColumn.Width = 50;
            // 
            // orgDirectorIDDataGridViewTextBoxColumn
            // 
            this.orgDirectorIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgDirectorIDDataGridViewTextBoxColumn.DataPropertyName = "orgDirectorID";
            this.orgDirectorIDDataGridViewTextBoxColumn.HeaderText = "תז מנהל";
            this.orgDirectorIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgDirectorIDDataGridViewTextBoxColumn.Name = "orgDirectorIDDataGridViewTextBoxColumn";
            this.orgDirectorIDDataGridViewTextBoxColumn.Width = 50;
            // 
            // orgPictureDataGridViewTextBoxColumn
            // 
            this.orgPictureDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPictureDataGridViewTextBoxColumn.DataPropertyName = "orgPicture";
            this.orgPictureDataGridViewTextBoxColumn.HeaderText = "תמונת ארגון";
            this.orgPictureDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPictureDataGridViewTextBoxColumn.Name = "orgPictureDataGridViewTextBoxColumn";
            this.orgPictureDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgPicturesFolderDataGridViewTextBoxColumn
            // 
            this.orgPicturesFolderDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgPicturesFolderDataGridViewTextBoxColumn.DataPropertyName = "orgPicturesFolder";
            this.orgPicturesFolderDataGridViewTextBoxColumn.HeaderText = "תיקיית תמונות";
            this.orgPicturesFolderDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgPicturesFolderDataGridViewTextBoxColumn.Name = "orgPicturesFolderDataGridViewTextBoxColumn";
            this.orgPicturesFolderDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgClipDataGridViewTextBoxColumn
            // 
            this.orgClipDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.orgClipDataGridViewTextBoxColumn.DataPropertyName = "orgClip";
            this.orgClipDataGridViewTextBoxColumn.HeaderText = "סרטון ארגון";
            this.orgClipDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.orgClipDataGridViewTextBoxColumn.Name = "orgClipDataGridViewTextBoxColumn";
            this.orgClipDataGridViewTextBoxColumn.Width = 200;
            // 
            // orgSite
            // 
            this.orgSite.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.orgSite.DataPropertyName = "orgSite";
            this.orgSite.HeaderText = "כתובת אתר";
            this.orgSite.MinimumWidth = 8;
            this.orgSite.Name = "orgSite";
            // 
            // tblOrganizationBindingSource
            // 
            this.tblOrganizationBindingSource.DataMember = "tblOrganization";
            this.tblOrganizationBindingSource.DataSource = this.dataSetOrganization;
            // 
            // dataSetOrganization
            // 
            this.dataSetOrganization.DataSetName = "DataSetOrganization";
            this.dataSetOrganization.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblOrganizationTableAdapter
            // 
            this.tblOrganizationTableAdapter.ClearBeforeFill = true;
            // 
            // FormTblOrganization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1868, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormTblOrganization";
            this.Text = "FormTblOrganization";
            this.Load += new System.EventHandler(this.FormTblOrganization_Load);
            this.SizeChanged += new System.EventHandler(this.FormTblOrganization_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblOrganizationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetOrganization)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSetOrganization dataSetOrganization;
        private System.Windows.Forms.BindingSource tblOrganizationBindingSource;
        private DataSetOrganizationTableAdapters.tblOrganizationTableAdapter tblOrganizationTableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgCityIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgDirectorIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPictureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgPicturesFolderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgClipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orgSite;
    }
}
