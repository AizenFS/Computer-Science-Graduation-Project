﻿namespace Submarines
{
    partial class FormSubmarineFix
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.helpButton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonShow = new System.Windows.Forms.Button();
            this.submarines = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.sinkPercent = new System.Windows.Forms.TextBox();
            this.subName = new System.Windows.Forms.TextBox();
            this.cols = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rows = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.helpButton);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.buttonSave);
            this.panel1.Controls.Add(this.buttonShow);
            this.panel1.Controls.Add(this.submarines);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.sinkPercent);
            this.panel1.Controls.Add(this.subName);
            this.panel1.Controls.Add(this.cols);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.rows);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(77, 63);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1786, 913);
            this.panel1.TabIndex = 35;
            // 
            // helpButton
            // 
            this.helpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(1686, 14);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(81, 34);
            this.helpButton.TabIndex = 7;
            this.helpButton.Text = "עזרה";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(902, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(168, 37);
            this.label11.TabIndex = 36;
            this.label11.Text = "תיקון צוללת";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(257, 197);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(636, 636);
            this.panel2.TabIndex = 68;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseMove);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseUp);
            // 
            // buttonSave
            // 
            this.buttonSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSave.Location = new System.Drawing.Point(1161, 488);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(154, 44);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "שמור שינויים";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonShow
            // 
            this.buttonShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShow.Location = new System.Drawing.Point(1161, 362);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(154, 44);
            this.buttonShow.TabIndex = 5;
            this.buttonShow.Text = "הצג צוללת";
            this.buttonShow.UseVisualStyleBackColor = true;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // submarines
            // 
            this.submarines.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.submarines.FormattingEnabled = true;
            this.submarines.Location = new System.Drawing.Point(1408, 312);
            this.submarines.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.submarines.Name = "submarines";
            this.submarines.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.submarines.Size = new System.Drawing.Size(110, 28);
            this.submarines.TabIndex = 0;
            this.submarines.SelectedIndexChanged += new System.EventHandler(this.submarines_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1660, 312);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 64;
            this.label3.Text = " צוללת";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1626, 526);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "מספר שורות";
            // 
            // sinkPercent
            // 
            this.sinkPercent.Enabled = false;
            this.sinkPercent.Location = new System.Drawing.Point(1407, 453);
            this.sinkPercent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sinkPercent.Name = "sinkPercent";
            this.sinkPercent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.sinkPercent.Size = new System.Drawing.Size(110, 26);
            this.sinkPercent.TabIndex = 2;
            // 
            // subName
            // 
            this.subName.Enabled = false;
            this.subName.Location = new System.Drawing.Point(1408, 383);
            this.subName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.subName.Name = "subName";
            this.subName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.subName.Size = new System.Drawing.Size(110, 26);
            this.subName.TabIndex = 1;
            // 
            // cols
            // 
            this.cols.Enabled = false;
            this.cols.Location = new System.Drawing.Point(1408, 598);
            this.cols.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cols.Name = "cols";
            this.cols.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cols.Size = new System.Drawing.Size(110, 26);
            this.cols.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1617, 601);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "מספר עמודות";
            // 
            // rows
            // 
            this.rows.Enabled = false;
            this.rows.Location = new System.Drawing.Point(1408, 523);
            this.rows.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rows.Name = "rows";
            this.rows.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.rows.Size = new System.Drawing.Size(110, 26);
            this.rows.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1640, 386);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "שם צוללת";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1557, 456);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "אחוז משבצות להטבעה";
            // 
            // FormSubmarineFix
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormSubmarineFix";
            this.Text = "FormSubmarineFix";
            this.SizeChanged += new System.EventHandler(this.FormSubmarineFix_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox subName;
        private System.Windows.Forms.TextBox cols;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox rows;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox submarines;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.TextBox sinkPercent;
        private System.Windows.Forms.Label label7;
    }
}
