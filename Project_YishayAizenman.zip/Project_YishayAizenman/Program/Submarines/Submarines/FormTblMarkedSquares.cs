﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormTblMarkedSquares : Submarines.FormBaseTables
    {
        public FormTblMarkedSquares()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void FormTblMarkedSquares_Load(object sender, EventArgs e)
        {
            this.tblMarkedSquaresTableAdapter.Fill(this.dataSetMarkedSquares.tblMarkedSquares);

        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataSetMarkedSquares changes = (DataSetMarkedSquares)dataSetMarkedSquares.GetChanges();
                if (changes == null)
                    return;

                DataTable dt = changes.tblMarkedSquares.GetChanges();
                DataRow[] badRows = dt.GetErrors();
                if (badRows.Length > 0)
                {
                    string errorMsg = "";
                    foreach (DataRow row in badRows)
                    {
                        foreach (DataColumn col in row.GetColumnsInError())
                        {
                            errorMsg = errorMsg + row.GetColumnsInError() + "\n";
                        }
                    }
                    MessageBox.Show("Errors in data: " + errorMsg,
                    "Please fix", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                int numRows = tblMarkedSquaresTableAdapter.Update(changes);
                MessageBox.Show("Updated " + numRows + " rows", "Success");
                dataSetMarkedSquares.AcceptChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Erros",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                dataSetMarkedSquares.RejectChanges();
            }
        }

        private void FormTblMarkedSquares_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}


