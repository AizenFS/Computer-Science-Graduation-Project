﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormUpdatePlayer : Submarines.FormBaseUpdate
    {
        private OleDbConnection dataConnection;
        private int lastRow = 0;
        public FormUpdatePlayer(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillCityCombo();
            RefreshDataGridView();
            dataGridView1.Rows[0].Selected = true;
            FillSelectedRow();
        }

        private void FormUpdatePlayer_Load(object sender, EventArgs e)
        {
            this.tblPlayersTableAdapter.Fill(this.dataSetPlayers.tblPlayers);

        }

        private void FillCityCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT cityID, cityName " +
                                          "FROM tblCities " +
                                          "ORDER BY cityID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    comboCity.Items.Add(dataReader.GetInt32(0).ToString() + ", " + dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill cities combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillSelectedRow()
        {
            try
            {
                idBox.Text                = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                firstNameBox.Text         = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                lastNameBox.Text          = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                addressBox.Text           = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                comboCity.Text            = SubmarinesUtils.GetDetailsFromID(dataGridView1, comboCity, 4);
                passwordBox.Text          = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                isManager.Checked         = dataGridView1.SelectedRows[0].Cells[6].Value.ToString() == "True";
                isActive.Checked          = dataGridView1.SelectedRows[0].Cells[7].Value.ToString() == "True";
                phoneBox.Text             = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
                mailBox.Text              = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
                pictureLocation.Text      = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
                pictureBox1.ImageLocation = pictureLocation.Text;
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                EnableButtons();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill Selected Row \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            if (!Validations.ValidMail(mailBox.Text))
            {
                MessageBox.Show("כתובת המייל שנבחרה לא חוקית", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!Validations.ValidName(firstNameBox.Text) || !Validations.ValidName(lastNameBox.Text))
            {
                MessageBox.Show("השם שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!Validations.ValidPhone(phoneBox.Text))
            {
                MessageBox.Show("מספר הטלפון שנבחר לא חוקי", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "UPDATE tblPlayers " +
                    "SET    playerFirstName  = \"" + firstNameBox.Text                                + "\" , " +
                            "playerLastName  = \"" + lastNameBox.Text                                 + "\" , " +
                            "playerAddress   = \"" + addressBox.Text                                  + "\" , " +
                            "playerCityID    =   " + SubmarinesUtils.GetIdFromDetails(comboCity.Text) + "   , " +
                            "playerPassword  = \"" + passwordBox.Text                                 + "\" , " +
                            "playerIsManager =   " + isManager.Checked                                + "   , " +
                            "playerIsActive  =   " + isActive.Checked                                 + "   , " +
                            "playerPhone     =   " + phoneBox.Text                                    + "   , " +
                            "playerMail      = \"" + mailBox.Text                                     + "\" , " +
                            "playerPicture   = \"" + pictureLocation.Text                             + "\"   " +
                    "WHERE  playerID = " + idBox.Text;
                datacommand.ExecuteNonQuery();
                RefreshDataGridView();
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                MessageBox.Show("Update tblPlayers ended successfluly");
            }
            catch (Exception err)
            {
                MessageBox.Show("Update tblPlayers failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblPlayers " +
                                     "ORDER BY playerID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EnableButtons()
        {
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            if (lastRow == 0)
                buttonPrev.Enabled = false;
            if (lastRow == dataGridView1.Rows.Count - 1)
                buttonNext.Enabled = false;
        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = 0;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow++;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = dataGridView1.Rows.Count - 1;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow--;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            DialogResult dlgResult = openFileDialog1.ShowDialog();
            string pictureFileName = openFileDialog1.FileName;
            pictureBox1.ImageLocation = pictureFileName;
            pictureLocation.Text = pictureFileName;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lastRow = dataGridView1.CurrentRow.Index;
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            FillSelectedRow();
        }

        private void FormUpdatePlayer_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            string fileName = ShowSelfieDialog();
            if (!string.IsNullOrEmpty(fileName))
            {
                pictureLocation.Text = fileName;
                pictureBox1.Image = Image.FromFile(fileName);
            }
        }

        private string ShowSelfieDialog()
        {
            using (FormCaptureSelfie captureDialog = new FormCaptureSelfie())
            {
                captureDialog.Height = 1000;
                if (captureDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    return captureDialog.saveFileName;
                }
                else { return null; }
            }
        }
    }
}
