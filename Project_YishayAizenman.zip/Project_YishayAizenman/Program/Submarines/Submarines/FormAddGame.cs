﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Submarines
{
    public partial class FormAddGame : Submarines.FormBaseAdd
    {
        private OleDbConnection dataConnection;

        public FormAddGame(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            FillIdCombo(comboId1);
            FillIdCombo(comboId2);
        }

        private void FillIdCombo(System.Windows.Forms.ComboBox combo)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerID, playerFirstName, playerLastName " +
                                          "FROM tblPlayers " +
                                          "ORDER BY playerID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    combo.Items.Add(dataReader.GetInt32(0).ToString() + ", " +
                        dataReader.GetString(1) + " " +dataReader.GetString(2));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill player ID combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddGame_Load(object sender, EventArgs e)
        {
            this.tblGamesTableAdapter.Fill(this.dataSetGames.tblGames);
            SubmarinesUtils.SetDataGridViewTimeFormat(dataGridView1,8);
            dataGridView1.AllowUserToAddRows = false;
        }

        private void btnColor1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            btnColor1.BackColor = cd.Color;
            string saveColor = btnColor1.BackColor.ToArgb().ToString();
            col1.Text = saveColor;
        }

        private void btnColor2_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            btnColor2.BackColor = cd.Color;
            string saveColor = btnColor2.BackColor.ToArgb().ToString();
            col2.Text = saveColor;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {          
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string str = string.Format(
                    "INSERT INTO tblGames " +
                    "(gameBoardRows, gameBoardCols, gamePlayer1ID, gameType1, gamePlayer2ID, gameType2," +
                    "   gameDate, gameTime, gameMinutes, gameMoves, gameColor1, gameColor2) " +
                    "VALUES ({0}, {1}, {2}, {3}, {4}, {5}, #{6}#, #{7}#, {8}, {9}, {10}, {11})",
                     rowsBox.Text,colsBox.Text,SubmarinesUtils.GetIdFromDetails(comboId1.Text),p1Type.Text,
                     SubmarinesUtils.GetIdFromDetails(comboId2.Text),p2Type.Text, gameDate.Value.ToString("dd/MM/yyyy"),
                     gameTime.Text,gameMinutes.Text,stepsNumber.Text,col1.Text,col2.Text);
                datacommand.CommandText = str;
                datacommand.ExecuteNonQuery();
                MessageBox.Show("Insert into tblGames ended successfully", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGridView();
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblGames failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT * " +
                                     "FROM  tblGames ";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                dataGridView1.AllowUserToAddRows = false;
                SubmarinesUtils.SetDataGridViewTimeFormat(dataGridView1, 8);
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormAddGame_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
