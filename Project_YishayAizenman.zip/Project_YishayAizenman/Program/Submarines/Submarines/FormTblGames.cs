﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormTblGames : Submarines.FormBaseTables
    {
        public FormTblGames()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

        }

        private void FormTblGames_Load(object sender, EventArgs e)
        {
            this.tblGamesTableAdapter.Fill(this.dataSetGames.tblGames);
            SubmarinesUtils.SetDataGridViewTimeFormat(dataGridView1, 8);            
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataSetGames changes = (DataSetGames)dataSetGames.GetChanges();
                if (changes == null)
                    return;
                DataTable dt = changes.tblGames.GetChanges();
                DataRow[] badRows = dt.GetErrors();

                if (badRows.Length > 0)
                {
                    string errorMsg = "";
                    foreach (DataRow row in badRows)
                    {
                        foreach (DataColumn col in row.GetColumnsInError())
                        {
                            errorMsg = errorMsg + row.GetColumnsInError() + "\n";
                        }
                    }
                    MessageBox.Show("Errors in data: " + errorMsg,
                    "Please fix", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                int numRows = tblGamesTableAdapter.Update(changes);
                MessageBox.Show("Updated " + numRows + " rows", "Success");
                dataSetGames.AcceptChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Erros",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                dataSetGames.RejectChanges();
            }
        }

        private void FormTblGames_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
