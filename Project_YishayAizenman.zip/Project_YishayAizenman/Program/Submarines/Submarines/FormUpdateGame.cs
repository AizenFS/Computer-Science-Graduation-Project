﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormUpdateGame : Submarines.FormBaseUpdate
    {
        OleDbConnection dataConnection;
        int lastRow = 0;
        public FormUpdateGame(OleDbConnection dataConnection)
        {
            this.dataConnection = dataConnection;
            InitializeComponent();
            FillIdCombo(comboId1);
            FillIdCombo(comboId2);
            WindowState = FormWindowState.Maximized;
            RefreshDataGridView();
            dataGridView1.Rows[0].Selected = true;
            FillSelectedRow();
        }

        private void FormUpdateGame_Load(object sender, EventArgs e)
        {
            this.tblGamesTableAdapter.Fill(this.dataSetGames.tblGames);

        }

        private void FillIdCombo(System.Windows.Forms.ComboBox combo)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerID, playerFirstName, playerLastName " +
                                          "FROM tblPlayers " +
                                          "ORDER BY playerID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    combo.Items.Add(dataReader.GetInt32(0).ToString() + ", " + 
                        dataReader.GetString(1) + " " + dataReader.GetString(2));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill player ID combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FillSelectedRow()
        {
            try
            {
                gameId.Text      = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                rowsBox.Text     = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                colsBox.Text     = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                comboId1.Text    = SubmarinesUtils.GetDetailsFromID(dataGridView1,comboId1,3);
                p1Type.Text      = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                comboId2.Text    = SubmarinesUtils.GetDetailsFromID(dataGridView1, comboId2, 5);
                p2Type.Text      = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                gameDate.Text    = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
                gameTime.Text    = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
                gameMinutes.Text = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
                stepsNumber.Text = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
                col1.Text        = dataGridView1.SelectedRows[0].Cells[11].Value.ToString();
                col2.Text        = dataGridView1.SelectedRows[0].Cells[12].Value.ToString();

                colorB1.BackColor = Color.FromArgb(int.Parse(col1.Text));
                colorB2.BackColor = Color.FromArgb(int.Parse(col2.Text));
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                EnableButtons();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill Selected Row \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = 
                    "UPDATE tblGames " +
                    "SET    gameBoardRows   =     " + rowsBox.Text                                    + "  , " +
                           "gameBoardCols   =     " + colsBox.Text                                    + "  , " +
                           "gamePlayer1ID   =     " + SubmarinesUtils.GetIdFromDetails(comboId1.Text) + "  , " +
                           "gameType1       =     " + p1Type.Text                                     + "  , " +
                           "gamePlayer2ID   =     " + SubmarinesUtils.GetIdFromDetails(comboId2.Text) + "  , " +
                           "gameType2       =     " + p2Type.Text                                     + "  , " +
                           "gameDate        =    #" + gameDate.Value.ToString("dd/MM/yyyy")           + "# , " +
                           "gameTime        =    #" + gameTime.Text                                   + "# , " +
                           "gameMinutes     =     " + gameMinutes.Text                                + "  , " +
                           "gameMoves       =     " + stepsNumber.Text                                + "  , " +
                           "gameColor1      =     " + col1.Text                                       + "  , " +
                           "gameColor2      =     " + col2.Text                                       + "    " +
                    "WHERE  gameID = " + gameId.Text;
                datacommand.ExecuteNonQuery();
                RefreshDataGridView();
                dataGridView1.CurrentCell = dataGridView1[0, lastRow];
                MessageBox.Show("Update tblGames ended successfluly");
            }
            catch (Exception err)
            {
                MessageBox.Show("Update tblGames failed \n" + err.Message, "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshDataGridView()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                string sqlCommand = "SELECT   * " +
                                     "FROM     tblGames " +
                                     "ORDER BY gameID";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlCommand, dataConnection);
                DataTable tbl = new DataTable();
                dataAdapter.Fill(tbl);
                dataGridView1.DataSource = tbl;
                SubmarinesUtils.SetDataGridViewTimeFormat(dataGridView1, 8);
            }
            catch (Exception err)
            {
                MessageBox.Show("Refresh dataGridView failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EnableButtons()
        {
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            if (lastRow == 0)
                buttonPrev.Enabled = false;
            if (lastRow == dataGridView1.Rows.Count - 1)
                buttonNext.Enabled = false;
        }

        private void buttonFirst_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = 0;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow++;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonLast_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow = dataGridView1.Rows.Count - 1;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void buttonPrev_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows[lastRow].Selected = false;
            lastRow--;
            dataGridView1.Rows[lastRow].Selected = true;
            FillSelectedRow();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lastRow = dataGridView1.CurrentRow.Index;
            buttonPrev.Enabled = true;
            buttonNext.Enabled = true;
            FillSelectedRow();
        }

        private void colorB1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            colorB1.BackColor = cd.Color;
            string saveColor = colorB1.BackColor.ToArgb().ToString();
            col1.Text = saveColor;
        }

        private void colorB2_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            colorB2.BackColor = cd.Color;
            string saveColor = colorB2.BackColor.ToArgb().ToString();
            col2.Text = saveColor;
        }

        private void FormUpdateGame_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
