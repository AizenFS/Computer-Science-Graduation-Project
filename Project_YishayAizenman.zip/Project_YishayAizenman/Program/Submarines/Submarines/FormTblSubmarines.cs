﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Submarines
{
    public partial class FormTblSubmarines : Submarines.FormBaseTables
    {
        public FormTblSubmarines()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void FormTblSubmarines_Load(object sender, EventArgs e)
        {
            this.tblSubmarinesTableAdapter.Fill(this.dataSetSubmarines.tblSubmarines);
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataSetSubmarines changes = (DataSetSubmarines)dataSetSubmarines.GetChanges();
                if (changes == null)
                    return;
                DataTable dt = changes.tblSubmarines.GetChanges();
                DataRow[] badRows = dt.GetErrors();

                if (badRows.Length > 0)
                {
                    string errorMsg = "";
                    foreach (DataRow row in badRows)
                    {
                        foreach (DataColumn col in row.GetColumnsInError())
                        {
                            errorMsg = errorMsg + row.GetColumnsInError() + "\n";
                        }
                    }
                    MessageBox.Show("Errors in data: " + errorMsg,
                    "Please fix", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                int numRows = tblSubmarinesTableAdapter.Update(changes);
                MessageBox.Show("Updated " + numRows + " rows", "Success");
                dataSetSubmarines.AcceptChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Erros",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                dataSetSubmarines.RejectChanges();
            }
        }

        private void FormTblSubmarines_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
