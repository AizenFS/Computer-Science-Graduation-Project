﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormSubmarineFix : Submarines.FormBaseSubmarine
    {
        OleDbConnection dataConnection;
        private int[,] arrValues;
        private bool isDragging;
        private int subID;
        private string selectedSubName;


        public FormSubmarineFix(OleDbConnection connection)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            dataConnection = connection;
            FillSubmarinesCombo();
        }

        #region Choosing submarine
        private void FillSubmarinesCombo()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT s.subID, s.subName " +
                                          "FROM tblSubmarines AS s " +
                                          "WHERE s.subID NOT IN (SELECT startSubID FROM tblStartGames) " +
                                          "ORDER BY s.subID";
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    submarines.Items.Add(dataReader.GetInt32(0).ToString() + ", " + dataReader.GetString(1));
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarines combobox failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void submarines_SelectedIndexChanged(object sender, EventArgs e)
        {
            subID = SubmarinesUtils.GetIdFromDetails(submarines.Text);
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT subRows, subCols, subName, subSinkPercent " +
                                            "FROM tblSubmarines " +
                                            "WHERE subID = @id";
                datacommand.Parameters.AddWithValue("@id", subID);
                OleDbDataReader dataReader = datacommand.ExecuteReader();
                if (dataReader.Read())
                {
                    rows.Text = dataReader.GetInt32(0).ToString();
                    cols.Text = dataReader.GetInt32(1).ToString();
                    subName.Text = dataReader.GetString(2);
                    selectedSubName = subName.Text;
                    sinkPercent.Text = dataReader.GetInt32(3).ToString();
                }
                dataReader.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show("Fill submarine details failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            subName.Enabled = true;
            sinkPercent.Enabled = true;
        }
        #endregion

        #region initiallizing buttons
        private int[,] GetMarkedSquaresArray(int subID)
        {
            int r = int.Parse(rows.Text);
            int c = int.Parse(cols.Text);
            Submarine sub = new Submarine(subID, "", r, c, 1);            
            return sub.GetMarkedSquaresArray(dataConnection);
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            try
            {
                arrValues = GetMarkedSquaresArray(subID);
                foreach (Control control in panel2.Controls)
                {
                    control.Dispose();
                }
                panel2.Controls.Clear();
                int r = int.Parse(rows.Text);
                int c = int.Parse(cols.Text);
                int totalButtonWidth = c * 20 + (c - 1) * 7;
                int totalButtonHeight = r * 20 + (r - 1) * 7;
                int offsetX = (panel2.Width - totalButtonWidth) / 2;
                int offsetY = (panel2.Height - totalButtonHeight) / 2;

                for (int i = 0; i < r; i++)
                    for (int j = 0; j < c; j++)
                        AddButton(i, j, offsetX, offsetY);
            }
            catch (Exception err)
            {
                MessageBox.Show("show button grid failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddButton(int i, int j, int offsetX, int offsetY)
        {

            int btnSide = 20;
            int X = offsetX + j * (btnSide + 7);
            int Y = offsetY + i * (btnSide + 7);
            string btnRow = i < 10 ? $"0{i}" : i.ToString();
            string btnCol = j < 10 ? $"0{j}" : j.ToString();
            Button b = new Button()
            {
                Name = $"btn_{btnRow}_{btnCol}",
                Location = new System.Drawing.Point(X, Y),
                Size = new System.Drawing.Size(btnSide, btnSide),
                TabIndex = i + j,
                Tag = false,
                UseVisualStyleBackColor = true,
                BackColor = arrValues[i, j] == 1 ? Color.Blue : SystemColors.Control
            };
            b.Click += new EventHandler(Button_Click);
            this.panel2.Controls.Add(b);
        }
        #endregion

        #region modifying buttons
        private void Button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.Tag = false;
            ChangeButtonColorAndValue(btn);
        }

        private void ChangeButtonColorAndValue(Button button)
        {
            bool hasBeenProcessed = (bool)button.Tag;
            int[] ij = SubmarinesUtils.GetButtonIndices(button);
            int i = ij[0];
            int j = ij[1];

            if (hasBeenProcessed)
            {
                return;
            }

            if (arrValues[i, j] == 0)
            {
                button.BackColor = Color.Blue;
                arrValues[i, j] = 1;
            }
            else
            {
                button.BackColor = SystemColors.Control;
                arrValues[i, j] = 0;
            }

            button.Tag = true;
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
            }
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                foreach (Control ctrl in panel2.Controls)
                {
                    if (ctrl is Button button && button.ClientRectangle.Contains(
                        button.PointToClient(Cursor.Position)))
                    {
                        ChangeButtonColorAndValue(button);
                    }
                }
            }
        }

        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
            foreach (Control ctrl in panel2.Controls)
            {
                if (ctrl is Button button && button.Tag != null)
                {
                    button.Tag = false;
                }
            }
        }


        #endregion

        #region saving to database
        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (panel2.Controls.Count == 0)
            {
                DialogResult res = MessageBox.Show("?לא בוצעו שינויים לצורת הצוללת, לשמור בכל זאת",
                    "וידוא שמירה", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res != DialogResult.Yes) {
                    MessageBox.Show(".השמירה בוטלה");
                    return;
                }
            }
            if (!Validations.ValidName(subName.Text))
            {
                MessageBox.Show("השם שנבחר לא חוקי", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (subName.Text != selectedSubName && 
                Validations.Exist(dataConnection, "tblSubmarines", "subName", subName.Text))
            {
                MessageBox.Show("שם הצוללת הנבחר כבר קיים במסד הנתונים", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (subName.Text == "" || sinkPercent.Text == "")
            {
                MessageBox.Show("לא כל פרטי הצוללת מלאים", "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!SubmarinesUtils.IsSubArrCompact(arrValues))
            {
                MessageBox.Show(".הצוללת לא קומפקטית, בשביל שינוי מידות צור צוללת חדשה",
                    "צוללת לא קומפקטית", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateSub();
            InsertMarkedSquares();
            MessageBox.Show(".השינויים נשמרו", "הצלחה",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void UpdateSub()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "UPDATE tblSubmarines " +
                                          "SET subName = @name, subSinkPercent = @sinkP " +
                                          "WHERE subID = @id";
                datacommand.Parameters.AddWithValue("@id", subID);
                datacommand.Parameters.AddWithValue("@name", subName.Text);
                datacommand.Parameters.AddWithValue("@sinkP", sinkPercent.Text);
                datacommand.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("update tblSubmarines failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeletePrevMarkedSquares()
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "DELETE FROM tblMarkedSquares WHERE msSubID = @id";
                datacommand.Parameters.AddWithValue("@id", subID);
                datacommand.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                MessageBox.Show("delete marked squares failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InsertMarkedSquares()
        {
            DeletePrevMarkedSquares();
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "INSERT INTO tblMarkedSquares " +
                    "(msSubID, msRowNum, msColNum) " +
                    "VALUES (@id, @r, @c)";
                for (int i = 0; i < arrValues.GetLength(0); i++)
                {
                    for (int j = 0; j < arrValues.GetLength(1); j++)
                    {
                        if (arrValues[i, j] == 1)
                        {
                            datacommand.Parameters.Clear();
                            datacommand.Parameters.AddWithValue("@id", subID);
                            datacommand.Parameters.AddWithValue("@r", i);
                            datacommand.Parameters.AddWithValue("@c", j);
                            datacommand.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception err)
            {
                MessageBox.Show("Insert into tblMarkedSquares failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        private void FormSubmarineFix_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }

        private void helpButton_Click(object sender, EventArgs e)
        {
            FormHelpSubFix helpSubFix = new FormHelpSubFix();
            helpSubFix.Height = panel1.Height;
            helpSubFix.Show();
        }   
    }
}
