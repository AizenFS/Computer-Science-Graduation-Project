﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows.Markup;
using static Submarines.SubmarinesDataStructures;

namespace Submarines
{
    public partial class FormRptGamesByPeriod : Submarines.FormBaseReport
    {
        private OleDbConnection dataConnection;
        private string saveColor = "";

        public FormRptGamesByPeriod(OleDbConnection dataConnection)
        {
            InitializeComponent();
            this.dataConnection = dataConnection;
            WindowState = FormWindowState.Maximized;
            listView1.FullRowSelect = true;
        }

        #region Button events
        private void buttonShow_Click(object sender, EventArgs e)
        {
            try
            {
                if (fromDate.Value <= toDate.Value)
                {
                    EditListView(GetGamesDetails());
                }
                else
                {
                    MessageBox.Show("התאריך המוקדם מאוחר יותר מהתאריך המאוחר", "סדר תאריכים הפוך",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select tblGames failed " +
                    ex.Message, "Errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            buttonColor.ForeColor = cd.Color;
            saveColor = buttonColor.ForeColor.ToArgb().ToString();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            playerNameAndPic1.Visible = false;
            playerNameAndPic2.Visible = false;
            labelP1.Visible = false;
            labelP2.Visible = false;
        }
        #endregion

        #region Report logic
        private void EditListView(ArrayList list)
        {
            try
            {
                int rowCount = 0;
                if (!(list.Count == 0))
                {
                    foreach (string[] arr in list)
                    {
                        if (rowCount != 0)
                        {
                            arr[0] = "";
                            arr[1] = "";
                        }
                        ListViewItem item = new ListViewItem(arr);
                        if (saveColor != "")
                            item.ForeColor = Color.FromArgb(int.Parse(saveColor));
                        listView1.Items.Add(item);
                        rowCount++;
                    }
                }
                else
                {
                    MessageBox.Show("לא נמצאו משחקים עבור התקופה שנבחרה", "לא נמצא",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Edit listview failed " + ex.Message, "Errors",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private ArrayList GetGamesDetails()
        {
            try
            {
                ArrayList list = new ArrayList();
                string from = fromDate.Value.ToString("dd/MM/yyyy");
                string to = toDate.Value.ToString("dd/MM/yyyy");

                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText =
                    "SELECT * " +
                    "FROM tblGames " +
                    "WHERE gameDate BETWEEN @fromDate AND @toDate";
                datacommand.Parameters.AddWithValue("@fromDate", from);
                datacommand.Parameters.AddWithValue("@toDate", to);

                OleDbDataReader dataReader = datacommand.ExecuteReader();
                while (dataReader.Read())
                {
                    string[] values = new string[15];
                    values[0] = from;
                    values[1] = to;
                    for (int i = 2; i < values.Length; i++)
                    {
                        if (i == 9)
                        {
                            values[i] = dataReader.GetDateTime(i-2).ToString("dd/MM/yyyy");
                        }
                        else if (i == 10)
                        {
                            values[i] = dataReader.GetDateTime(i-2).ToString("HH:mm:ss");
                        }
                        else
                        {
                            values[i] = dataReader[i-2].ToString();
                        }
                    }
                    if (values[2] != null)
                    {
                        list.Add(values);
                    }
                }
                dataReader.Close();
                return list;
            }
            catch (Exception err)
            {
                MessageBox.Show("Get games failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return new ArrayList();
            }
        }
        #endregion

        #region Player display
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                ListViewItem selectedRow = listView1.SelectedItems[0];
                UpdatePlayerNameAndPic(1, selectedRow, playerNameAndPic1);
                UpdatePlayerNameAndPic(2, selectedRow, playerNameAndPic2);
            }
        }

        private void UpdatePlayerNameAndPic(int playerNum, ListViewItem selectedRow, playerNameAndPic nameAndPic)
        {
            string id_str = selectedRow.SubItems[5].Text;
            if (playerNum == 2)
            {
                labelP2.Visible = true;
                id_str = selectedRow.SubItems[7].Text;
            }
            else
            {
                labelP1.Visible = true;
            }
            int id = int.Parse(id_str);

            nameAndPic.UpdateProperties(GetPlayerFromID(id), dataConnection);
            nameAndPic.Visible = true;
        }

        private Player GetPlayerFromID(int id)
        {
            try
            {
                OleDbCommand datacommand = new OleDbCommand();
                datacommand.Connection = dataConnection;
                datacommand.CommandText = "SELECT playerFirstName, PlayerLastName " +
                                          "FROM tblPlayers " +
                                          "WHERE playerID = @playerID";
                datacommand.Parameters.AddWithValue("@playerID", id);

                OleDbDataReader dataReader = datacommand.ExecuteReader();
                dataReader.Read();
                return new Player(id, dataReader.GetString(0), dataReader.GetString(1));
            }
            catch (Exception err)
            {
                MessageBox.Show("Get player details form id failed failed \n" + err.Message, "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
        #endregion

        private void FormRptGamesByPeriod_SizeChanged(object sender, EventArgs e)
        {
            panel1.Left = (ClientSize.Width - panel1.Width) / 2;
            panel1.Top = (ClientSize.Height - panel1.Height) / 2;
            panel1.SendToBack();
        }
    }
}
