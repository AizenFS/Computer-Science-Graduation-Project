﻿namespace Submarines
{
    partial class FormGamePlaceSubs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.helpButton = new System.Windows.Forms.Button();
            this.reset1 = new System.Windows.Forms.Button();
            this.listSubs2 = new System.Windows.Forms.ListBox();
            this.listSubs1 = new System.Windows.Forms.ListBox();
            this.btnContinue = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.NP1 = new Submarines.playerNameAndPic();
            this.label4 = new System.Windows.Forms.Label();
            this.NP2 = new Submarines.playerNameAndPic();
            this.reset2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.gameProgress = new System.Windows.Forms.Label();
            this.board2 = new System.Windows.Forms.Panel();
            this.board1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.helpButton);
            this.panel1.Controls.Add(this.reset1);
            this.panel1.Controls.Add(this.listSubs2);
            this.panel1.Controls.Add(this.listSubs1);
            this.panel1.Controls.Add(this.btnContinue);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.NP1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.NP2);
            this.panel1.Controls.Add(this.reset2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.gameProgress);
            this.panel1.Controls.Add(this.board2);
            this.panel1.Controls.Add(this.board1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(1, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1900, 1026);
            this.panel1.TabIndex = 11;
            // 
            // helpButton
            // 
            this.helpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(1757, 42);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(81, 34);
            this.helpButton.TabIndex = 82;
            this.helpButton.Text = "עזרה";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // reset1
            // 
            this.reset1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.reset1.Location = new System.Drawing.Point(1721, 901);
            this.reset1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.reset1.Name = "reset1";
            this.reset1.Size = new System.Drawing.Size(91, 40);
            this.reset1.TabIndex = 79;
            this.reset1.Text = "אתחל";
            this.reset1.UseVisualStyleBackColor = true;
            this.reset1.Click += new System.EventHandler(this.reset1_Click);
            // 
            // listSubs2
            // 
            this.listSubs2.FormattingEnabled = true;
            this.listSubs2.ItemHeight = 20;
            this.listSubs2.Location = new System.Drawing.Point(52, 685);
            this.listSubs2.Name = "listSubs2";
            this.listSubs2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listSubs2.Size = new System.Drawing.Size(215, 184);
            this.listSubs2.TabIndex = 74;
            this.listSubs2.SelectedIndexChanged += new System.EventHandler(this.listSubs2_SelectedIndexChanged);
            // 
            // listSubs1
            // 
            this.listSubs1.FormattingEnabled = true;
            this.listSubs1.ItemHeight = 20;
            this.listSubs1.Location = new System.Drawing.Point(1653, 685);
            this.listSubs1.Name = "listSubs1";
            this.listSubs1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listSubs1.Size = new System.Drawing.Size(215, 184);
            this.listSubs1.TabIndex = 71;
            this.listSubs1.SelectedIndexChanged += new System.EventHandler(this.listSubs1_SelectedIndexChanged);
            // 
            // btnContinue
            // 
            this.btnContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnContinue.Location = new System.Drawing.Point(860, 958);
            this.btnContinue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnContinue.Size = new System.Drawing.Size(170, 54);
            this.btnContinue.TabIndex = 81;
            this.btnContinue.Text = "המשך למשחק!";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1721, 629);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(92, 29);
            this.label3.TabIndex = 72;
            this.label3.Text = "צוללות:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(103, 629);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(92, 29);
            this.label5.TabIndex = 75;
            this.label5.Text = "צוללות:";
            // 
            // NP1
            // 
            this.NP1.firstName = "";
            this.NP1.id = "";
            this.NP1.lastName = "";
            this.NP1.Location = new System.Drawing.Point(1653, 252);
            this.NP1.Name = "NP1";
            this.NP1.picLocation = null;
            this.NP1.Size = new System.Drawing.Size(210, 331);
            this.NP1.TabIndex = 76;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(556, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 37);
            this.label4.TabIndex = 78;
            this.label4.Text = "שחקן 2";
            // 
            // NP2
            // 
            this.NP2.firstName = "";
            this.NP2.id = "";
            this.NP2.lastName = "";
            this.NP2.Location = new System.Drawing.Point(52, 252);
            this.NP2.Name = "NP2";
            this.NP2.picLocation = null;
            this.NP2.Size = new System.Drawing.Size(210, 331);
            this.NP2.TabIndex = 77;
            // 
            // reset2
            // 
            this.reset2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.reset2.Location = new System.Drawing.Point(103, 901);
            this.reset2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.reset2.Name = "reset2";
            this.reset2.Size = new System.Drawing.Size(87, 40);
            this.reset2.TabIndex = 80;
            this.reset2.Text = "אתחל";
            this.reset2.UseVisualStyleBackColor = true;
            this.reset2.Click += new System.EventHandler(this.reset2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1225, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 37);
            this.label6.TabIndex = 73;
            this.label6.Text = "שחקן 1";
            // 
            // gameProgress
            // 
            this.gameProgress.AutoSize = true;
            this.gameProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameProgress.Location = new System.Drawing.Point(829, 138);
            this.gameProgress.Name = "gameProgress";
            this.gameProgress.Size = new System.Drawing.Size(247, 37);
            this.gameProgress.TabIndex = 68;
            this.gameProgress.Text = "שלב מיקום צוללות";
            // 
            // board2
            // 
            this.board2.Location = new System.Drawing.Point(291, 252);
            this.board2.Name = "board2";
            this.board2.Size = new System.Drawing.Size(650, 689);
            this.board2.TabIndex = 67;
            // 
            // board1
            // 
            this.board1.Location = new System.Drawing.Point(966, 252);
            this.board1.Name = "board1";
            this.board1.Size = new System.Drawing.Size(650, 689);
            this.board1.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(828, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 52);
            this.label2.TabIndex = 65;
            this.label2.Text = "משחק צוללות";
            // 
            // FormGamePlaceSubs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormGamePlaceSubs";
            this.Text = "FormGamePlaceSubs";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormGamePlaceSubs_FormClosing);
            this.Load += new System.EventHandler(this.FormGamePlaceSubs_Load);
            this.Shown += new System.EventHandler(this.FormGamePlaceSubs_Shown);
            this.SizeChanged += new System.EventHandler(this.FormGamePlaceSubs_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel board1;
        private System.Windows.Forms.Panel board2;
        private System.Windows.Forms.Label gameProgress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listSubs2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listSubs1;
        private System.Windows.Forms.Label label4;
        private playerNameAndPic NP2;
        private playerNameAndPic NP1;
        private System.Windows.Forms.Button reset2;
        private System.Windows.Forms.Button reset1;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Button helpButton;
    }
}
