﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Video;
using AForge.Video.DirectShow;

namespace Submarines
{
    public partial class FormCaptureSelfie : Form
    {
        private string pictureFolderPath = "";
        public string saveFileName {  get; private set; }
        

        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoCaptureDevice;

        public FormCaptureSelfie()
        {
            InitializeComponent();
            this.Icon = Properties.Resources.AppIcon;
            folderPathBox.BackColor = SystemColors.Window;
            LoadDevicesCombo();
        }

        private void LoadDevicesCombo()
        {
            ComboBoxDevices.Items.Clear();
            videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            if (videoDevices.Count == 0) {
                MessageBox.Show("לא אותרו מצלמות", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            foreach (FilterInfo device in videoDevices) {
                if (!ComboBoxDevices.Items.Contains(device.Name))
                {
                    ComboBoxDevices.Items.Add(device.Name);
                }
            }

            ComboBoxDevices.SelectedIndex = 0;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadDevicesCombo();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {            
            if (ComboBoxDevices.SelectedIndex != -1)
            {
                btnCapture.Enabled = true;
                btnCapture.Focus();
                if (videoCaptureDevice != null && videoCaptureDevice.IsRunning)
                {
                    videoCaptureDevice.SignalToStop();
                    videoCaptureDevice.WaitForStop();
                }
                string deviceString = videoDevices[ComboBoxDevices.SelectedIndex].MonikerString;
                videoCaptureDevice = new VideoCaptureDevice(deviceString);
                videoCaptureDevice.NewFrame += VideoCaptureDevice_NewFrame;
                videoCaptureDevice.Start();
            }
            else
            {
                MessageBox.Show(".לא נבחרה מצלמה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void VideoCaptureDevice_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
            bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
            videoBox.Image = CropImageToCenterSquare(bitmap, videoBox.Width);
        }

        private Bitmap CropImageToCenterSquare(Bitmap originalImage, int boxSide)
        {
            int x = (originalImage.Width - boxSide) / 2;
            int y = 0;

            Rectangle cropRect = new Rectangle(x, y, boxSide, boxSide);
            Bitmap croppedImage = new Bitmap(boxSide, boxSide);

            using (Graphics g = Graphics.FromImage(croppedImage))
            {
                g.DrawImage(originalImage, new Rectangle(0, 0, boxSide, boxSide),
                    cropRect, GraphicsUnit.Pixel);
            }

            return croppedImage;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureFolderPath = folderBrowserDialog1.SelectedPath;
                folderPathBox.Text = ShortenFolderPath(pictureFolderPath);
            }
        }

        private string ShortenFolderPath(string fullPath)
        {
            string[] parts = fullPath.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 3)
            {
                return fullPath;
            }
            return $"...\\{parts[parts.Length - 2]}\\{parts[parts.Length - 1]}";
        }

        private void ComboBoxDevices_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (videoCaptureDevice != null && videoCaptureDevice.IsRunning)
            {
                videoCaptureDevice.SignalToStop();
                videoCaptureDevice.WaitForStop();
            }
            videoBox.Image = null;

            btnCapture.Enabled = false;

            btnStart.Enabled = true;
            btnStart.Focus();
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            if(pictureFolderPath == "")
            {
                MessageBox.Show(".לא נבחרה תיקייה לשמירת התמונה", "לא נבחרה תיקייה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string fileName = textBoxFileName.Text.Trim();           
            string pattern = @"^[^\\/:*?""<>|.]+$";
            Regex regex = new Regex(pattern);
            if (!regex.IsMatch(fileName)) {
                MessageBox.Show(".שם הקובץ לא חוקי, שים לב לא להכליל את סיומת סוג הקובץ", "שם קובץ לא חוקי",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }          
            
            if (videoBox.Image != null) {
                fileName = $"{pictureFolderPath}\\{fileName}.jpeg";
                videoBox.Image.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg);
               
                MessageBox.Show(".תמונה נשמרה", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                saveFileName = fileName;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void FormCaptureSelfie_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (videoCaptureDevice != null && videoCaptureDevice.IsRunning)
            {
                videoCaptureDevice.SignalToStop();
                videoCaptureDevice.WaitForStop();
            }
        }
    }
}
