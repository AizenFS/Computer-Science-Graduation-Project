﻿namespace Submarines
{
    partial class FormGameSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gameIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameBoardRowsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameBoardColsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gamePlayer1IDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameType1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gamePlayer2IDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameType2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameMinutesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameMovesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameColor1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gameColor2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblGamesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetGames = new Submarines.DataSetGames();
            this.tblGamesTableAdapter = new Submarines.DataSetGamesTableAdapters.tblGamesTableAdapter();
            this.playerNameAndPic2 = new Submarines.playerNameAndPic();
            this.playerNameAndPic1 = new Submarines.playerNameAndPic();
            this.panel1 = new System.Windows.Forms.Panel();
            this.helpButton = new System.Windows.Forms.Button();
            this.labelP2 = new System.Windows.Forms.Label();
            this.labelP1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblGamesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetGames)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(796, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(263, 52);
            this.label2.TabIndex = 66;
            this.label2.Text = "בחירת משחק";
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.btnStart.Location = new System.Drawing.Point(840, 903);
            this.btnStart.Name = "btnStart";
            this.btnStart.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnStart.Size = new System.Drawing.Size(236, 94);
            this.btnStart.TabIndex = 103;
            this.btnStart.Text = "המשך אל\r\n המשחק!\r\n";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(787, 399);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(305, 32);
            this.label11.TabIndex = 101;
            this.label11.Text = "משחקים שאפשר לבחור:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeight = 34;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gameIDDataGridViewTextBoxColumn,
            this.gameBoardRowsDataGridViewTextBoxColumn,
            this.gameBoardColsDataGridViewTextBoxColumn,
            this.gamePlayer1IDDataGridViewTextBoxColumn,
            this.gameType1DataGridViewTextBoxColumn,
            this.gamePlayer2IDDataGridViewTextBoxColumn,
            this.gameType2DataGridViewTextBoxColumn,
            this.gameDateDataGridViewTextBoxColumn,
            this.gameTimeDataGridViewTextBoxColumn,
            this.gameMinutesDataGridViewTextBoxColumn,
            this.gameMovesDataGridViewTextBoxColumn,
            this.gameColor1DataGridViewTextBoxColumn,
            this.gameColor2DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblGamesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(49, 485);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1730, 395);
            this.dataGridView1.TabIndex = 104;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // gameIDDataGridViewTextBoxColumn
            // 
            this.gameIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameIDDataGridViewTextBoxColumn.DataPropertyName = "gameID";
            this.gameIDDataGridViewTextBoxColumn.HeaderText = "מספר משחק";
            this.gameIDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameIDDataGridViewTextBoxColumn.Name = "gameIDDataGridViewTextBoxColumn";
            this.gameIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // gameBoardRowsDataGridViewTextBoxColumn
            // 
            this.gameBoardRowsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameBoardRowsDataGridViewTextBoxColumn.DataPropertyName = "gameBoardRows";
            this.gameBoardRowsDataGridViewTextBoxColumn.HeaderText = "שורות לוח";
            this.gameBoardRowsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameBoardRowsDataGridViewTextBoxColumn.Name = "gameBoardRowsDataGridViewTextBoxColumn";
            this.gameBoardRowsDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameBoardRowsDataGridViewTextBoxColumn.Width = 113;
            // 
            // gameBoardColsDataGridViewTextBoxColumn
            // 
            this.gameBoardColsDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameBoardColsDataGridViewTextBoxColumn.DataPropertyName = "gameBoardCols";
            this.gameBoardColsDataGridViewTextBoxColumn.HeaderText = "עמודות לוח";
            this.gameBoardColsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameBoardColsDataGridViewTextBoxColumn.Name = "gameBoardColsDataGridViewTextBoxColumn";
            this.gameBoardColsDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameBoardColsDataGridViewTextBoxColumn.Width = 122;
            // 
            // gamePlayer1IDDataGridViewTextBoxColumn
            // 
            this.gamePlayer1IDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gamePlayer1IDDataGridViewTextBoxColumn.DataPropertyName = "gamePlayer1ID";
            this.gamePlayer1IDDataGridViewTextBoxColumn.HeaderText = "תז שחקן 1";
            this.gamePlayer1IDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gamePlayer1IDDataGridViewTextBoxColumn.Name = "gamePlayer1IDDataGridViewTextBoxColumn";
            this.gamePlayer1IDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gamePlayer1IDDataGridViewTextBoxColumn.Width = 115;
            // 
            // gameType1DataGridViewTextBoxColumn
            // 
            this.gameType1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameType1DataGridViewTextBoxColumn.DataPropertyName = "gameType1";
            this.gameType1DataGridViewTextBoxColumn.HeaderText = "סוג שחקן 1";
            this.gameType1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameType1DataGridViewTextBoxColumn.Name = "gameType1DataGridViewTextBoxColumn";
            this.gameType1DataGridViewTextBoxColumn.ReadOnly = true;
            this.gameType1DataGridViewTextBoxColumn.Width = 120;
            // 
            // gamePlayer2IDDataGridViewTextBoxColumn
            // 
            this.gamePlayer2IDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gamePlayer2IDDataGridViewTextBoxColumn.DataPropertyName = "gamePlayer2ID";
            this.gamePlayer2IDDataGridViewTextBoxColumn.HeaderText = "תז שחקן 2";
            this.gamePlayer2IDDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gamePlayer2IDDataGridViewTextBoxColumn.Name = "gamePlayer2IDDataGridViewTextBoxColumn";
            this.gamePlayer2IDDataGridViewTextBoxColumn.ReadOnly = true;
            this.gamePlayer2IDDataGridViewTextBoxColumn.Width = 115;
            // 
            // gameType2DataGridViewTextBoxColumn
            // 
            this.gameType2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameType2DataGridViewTextBoxColumn.DataPropertyName = "gameType2";
            this.gameType2DataGridViewTextBoxColumn.HeaderText = "סוג שחקן 2";
            this.gameType2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameType2DataGridViewTextBoxColumn.Name = "gameType2DataGridViewTextBoxColumn";
            this.gameType2DataGridViewTextBoxColumn.ReadOnly = true;
            this.gameType2DataGridViewTextBoxColumn.Width = 120;
            // 
            // gameDateDataGridViewTextBoxColumn
            // 
            this.gameDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameDateDataGridViewTextBoxColumn.DataPropertyName = "gameDate";
            this.gameDateDataGridViewTextBoxColumn.HeaderText = "תאריך משחק";
            this.gameDateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameDateDataGridViewTextBoxColumn.Name = "gameDateDataGridViewTextBoxColumn";
            this.gameDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameDateDataGridViewTextBoxColumn.Width = 132;
            // 
            // gameTimeDataGridViewTextBoxColumn
            // 
            this.gameTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameTimeDataGridViewTextBoxColumn.DataPropertyName = "gameTime";
            this.gameTimeDataGridViewTextBoxColumn.HeaderText = "זמן תחילת משחק";
            this.gameTimeDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameTimeDataGridViewTextBoxColumn.Name = "gameTimeDataGridViewTextBoxColumn";
            this.gameTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameTimeDataGridViewTextBoxColumn.Width = 160;
            // 
            // gameMinutesDataGridViewTextBoxColumn
            // 
            this.gameMinutesDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameMinutesDataGridViewTextBoxColumn.DataPropertyName = "gameMinutes";
            this.gameMinutesDataGridViewTextBoxColumn.HeaderText = "דקות משחק";
            this.gameMinutesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameMinutesDataGridViewTextBoxColumn.Name = "gameMinutesDataGridViewTextBoxColumn";
            this.gameMinutesDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameMinutesDataGridViewTextBoxColumn.Width = 122;
            // 
            // gameMovesDataGridViewTextBoxColumn
            // 
            this.gameMovesDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameMovesDataGridViewTextBoxColumn.DataPropertyName = "gameMoves";
            this.gameMovesDataGridViewTextBoxColumn.HeaderText = "מספר מהלכים";
            this.gameMovesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameMovesDataGridViewTextBoxColumn.Name = "gameMovesDataGridViewTextBoxColumn";
            this.gameMovesDataGridViewTextBoxColumn.ReadOnly = true;
            this.gameMovesDataGridViewTextBoxColumn.Width = 135;
            // 
            // gameColor1DataGridViewTextBoxColumn
            // 
            this.gameColor1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gameColor1DataGridViewTextBoxColumn.DataPropertyName = "gameColor1";
            this.gameColor1DataGridViewTextBoxColumn.HeaderText = "צבע שחקן 1";
            this.gameColor1DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameColor1DataGridViewTextBoxColumn.Name = "gameColor1DataGridViewTextBoxColumn";
            this.gameColor1DataGridViewTextBoxColumn.ReadOnly = true;
            this.gameColor1DataGridViewTextBoxColumn.Width = 127;
            // 
            // gameColor2DataGridViewTextBoxColumn
            // 
            this.gameColor2DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gameColor2DataGridViewTextBoxColumn.DataPropertyName = "gameColor2";
            this.gameColor2DataGridViewTextBoxColumn.HeaderText = "צבע שחקן 2";
            this.gameColor2DataGridViewTextBoxColumn.MinimumWidth = 8;
            this.gameColor2DataGridViewTextBoxColumn.Name = "gameColor2DataGridViewTextBoxColumn";
            this.gameColor2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblGamesBindingSource
            // 
            this.tblGamesBindingSource.DataMember = "tblGames";
            this.tblGamesBindingSource.DataSource = this.dataSetGames;
            // 
            // dataSetGames
            // 
            this.dataSetGames.DataSetName = "DataSetGames";
            this.dataSetGames.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblGamesTableAdapter
            // 
            this.tblGamesTableAdapter.ClearBeforeFill = true;
            // 
            // playerNameAndPic2
            // 
            this.playerNameAndPic2.firstName = "";
            this.playerNameAndPic2.id = "";
            this.playerNameAndPic2.lastName = "";
            this.playerNameAndPic2.Location = new System.Drawing.Point(308, 133);
            this.playerNameAndPic2.Name = "playerNameAndPic2";
            this.playerNameAndPic2.picLocation = null;
            this.playerNameAndPic2.Size = new System.Drawing.Size(217, 331);
            this.playerNameAndPic2.TabIndex = 105;
            // 
            // playerNameAndPic1
            // 
            this.playerNameAndPic1.firstName = "";
            this.playerNameAndPic1.id = "";
            this.playerNameAndPic1.lastName = "";
            this.playerNameAndPic1.Location = new System.Drawing.Point(1345, 133);
            this.playerNameAndPic1.Name = "playerNameAndPic1";
            this.playerNameAndPic1.picLocation = null;
            this.playerNameAndPic1.Size = new System.Drawing.Size(227, 331);
            this.playerNameAndPic1.TabIndex = 106;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.helpButton);
            this.panel1.Controls.Add(this.labelP2);
            this.panel1.Controls.Add(this.labelP1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.playerNameAndPic2);
            this.panel1.Controls.Add(this.btnStart);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.playerNameAndPic1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1889, 1013);
            this.panel1.TabIndex = 107;
            // 
            // helpButton
            // 
            this.helpButton.BackColor = System.Drawing.SystemColors.Control;
            this.helpButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpButton.Location = new System.Drawing.Point(1762, 34);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(81, 34);
            this.helpButton.TabIndex = 109;
            this.helpButton.Text = "עזרה";
            this.helpButton.UseVisualStyleBackColor = false;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // labelP2
            // 
            this.labelP2.AutoSize = true;
            this.labelP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP2.Location = new System.Drawing.Point(368, 96);
            this.labelP2.Name = "labelP2";
            this.labelP2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelP2.Size = new System.Drawing.Size(70, 25);
            this.labelP2.TabIndex = 108;
            this.labelP2.Text = "שחקן 2";
            // 
            // labelP1
            // 
            this.labelP1.AutoSize = true;
            this.labelP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelP1.Location = new System.Drawing.Point(1409, 96);
            this.labelP1.Name = "labelP1";
            this.labelP1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelP1.Size = new System.Drawing.Size(70, 25);
            this.labelP1.TabIndex = 107;
            this.labelP1.Text = "שחקן 1";
            // 
            // FormGameSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.panel1);
            this.Name = "FormGameSelect";
            this.Text = "FormGameSelect";
            this.Load += new System.EventHandler(this.FormGameSelect_Load);
            this.SizeChanged += new System.EventHandler(this.FormGameContinue_SizeChanged);
            this.Controls.SetChildIndex(this.panel1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblGamesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetGames)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DataSetGames dataSetGames;
        private System.Windows.Forms.BindingSource tblGamesBindingSource;
        private DataSetGamesTableAdapters.tblGamesTableAdapter tblGamesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameBoardRowsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameBoardColsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gamePlayer1IDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameType1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gamePlayer2IDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameType2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameMinutesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameMovesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameColor1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gameColor2DataGridViewTextBoxColumn;
        private playerNameAndPic playerNameAndPic2;
        private playerNameAndPic playerNameAndPic1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelP2;
        private System.Windows.Forms.Label labelP1;
        private System.Windows.Forms.Button helpButton;
    }
}
